package com.moneycoming.slot.database

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "spins")
data class SpinRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val game: String,
    val time: Long,
    val bet: Long,
    val win: Long,
    val multiplier: Double,
    val result: String,
    val balanceAfter: Long,
    val free: Boolean
)

@Entity(tableName = "transactions")
data class TxRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val time: Long,
    val type: String,
    val amount: Long,
    val balanceAfter: Long,
    val note: String
)

@Dao
interface SpinDao {
    @Insert suspend fun insert(r: SpinRecord)
    @Query("SELECT * FROM spins ORDER BY id DESC LIMIT 300") fun recent(): Flow<List<SpinRecord>>
    @Query("SELECT * FROM spins WHERE win > 0 ORDER BY id DESC LIMIT 300") fun wins(): Flow<List<SpinRecord>>
    @Query("DELETE FROM spins WHERE id NOT IN (SELECT id FROM spins ORDER BY id DESC LIMIT 2000)") suspend fun prune()
    @Query("DELETE FROM spins") suspend fun clear()
}

@Dao
interface TxDao {
    @Insert suspend fun insert(r: TxRecord)
    @Query("SELECT * FROM transactions ORDER BY id DESC LIMIT 300") fun recent(): Flow<List<TxRecord>>
    @Query("DELETE FROM transactions WHERE id NOT IN (SELECT id FROM transactions ORDER BY id DESC LIMIT 2000)") suspend fun prune()
    @Query("DELETE FROM transactions") suspend fun clear()
}

@Database(entities = [SpinRecord::class, TxRecord::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun spinDao(): SpinDao
    abstract fun txDao(): TxDao
}
