package com.moneycoming.slot

import android.app.Application
import com.moneycoming.slot.repository.GameRepository

class MoneyComingApp : Application() {
    lateinit var repo: GameRepository
        private set

    override fun onCreate() {
        super.onCreate()
        repo = GameRepository(this)
    }
}
