package com.moneycoming.slot.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.moneycoming.slot.profile.AVATARS
import com.moneycoming.slot.profile.Vip
import com.moneycoming.slot.ui.components.GlassCard
import com.moneycoming.slot.ui.components.GoldButton
import com.moneycoming.slot.ui.components.SectionTitle
import com.moneycoming.slot.ui.theme.*
import com.moneycoming.slot.util.compact
import com.moneycoming.slot.util.fmt
import com.moneycoming.slot.viewmodel.MainViewModel

@Composable
fun VipScreen(vm: MainViewModel) {
    val p by vm.profile.collectAsState()
    val rw by vm.rewards.collectAsState()
    val cur = p.vip
    val next = p.nextVip
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("👑 VIP Club", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
        GlassCard(Modifier.fillMaxWidth(), colors = listOf(Color(cur.colorHex).copy(alpha = 0.35f), CardBg), border = Color(cur.colorHex)) {
            Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(cur.badge, fontSize = 56.sp)
                Text("VIP ${cur.idx + 1} • ${cur.name}", color = Color(cur.colorHex), fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                if (next != null) {
                    val span = (next.minWager - cur.minWager).toFloat()
                    LinearProgressIndicator(
                        progress = { ((p.totalWagered - cur.minWager) / span).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(50)),
                        color = Color(cur.colorHex), trackColor = Color(0x33FFFFFF)
                    )
                    Text("${p.totalWagered.compact()} / ${next.minWager.compact()} coins played to reach ${next.badge} ${next.name}", color = TextDim, fontSize = 12.sp)
                } else Text("Maximum VIP level reached! 🎉", color = Good, fontWeight = FontWeight.Bold)
                if (rw.vipClaimable.isNotEmpty()) GoldButton("CLAIM VIP REWARD +${rw.vipClaimable.sumOf { Vip.LEVELS[it].reward }.fmt()}", { vm.claimVip() }, Modifier.fillMaxWidth())
            }
        }
        SectionTitle("All VIP levels")
        Vip.LEVELS.forEach { l ->
            val reached = p.vip.idx >= l.idx
            GlassCard(Modifier.fillMaxWidth(), colors = listOf(Color(l.colorHex).copy(alpha = if (reached) 0.28f else 0.10f), CardBg), border = Color(l.colorHex).copy(alpha = if (reached) 1f else 0.4f)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(l.badge, fontSize = 36.sp)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text("VIP ${l.idx + 1} • ${l.name}", color = Color(l.colorHex), fontWeight = FontWeight.ExtraBold)
                        Text(l.perks, color = Color.White, fontSize = 12.sp)
                        Text("Play ${l.minWager.compact()} coins • Reward +${l.reward.compact()}", color = TextDim, fontSize = 11.sp)
                    }
                    Text(if (reached) "✅" else "🔒", fontSize = 20.sp)
                }
            }
        }
        Text("VIP progress is based on virtual coins played. Rewards are virtual coins with no cash value.", color = TextDim, fontSize = 11.sp)
    }
}

@Composable
fun ProfileScreen(vm: MainViewModel, onHistory: () -> Unit, onSettings: () -> Unit) {
    val p by vm.profile.collectAsState()
    val rw by vm.rewards.collectAsState()
    var name by remember(p.name) { mutableStateOf(p.name) }
    var error by remember { mutableStateOf<String?>(null) }
    var saved by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        AvatarCircle(p, 96)
        Text("${p.vip.badge} VIP ${p.vip.name}", color = Color(p.vip.colorHex), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        Text("Player ID: ${p.playerId}", color = TextDim, fontSize = 12.sp)

        Text("Choose avatar", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(AVATARS) { i, a ->
                Box(
                    Modifier.size(48.dp).clip(CircleShape).background(Color(0xFF2B1650))
                        .border(2.dp, if (i == p.avatar) Gold else Color.Transparent, CircleShape).clickable { vm.click(); vm.setAvatar(i) },
                    contentAlignment = Alignment.Center
                ) { Text(a, fontSize = 24.sp) }
            }
        }

        OutlinedTextField(
            value = name, onValueChange = { name = it.take(16); error = null; saved = false },
            label = { Text("Username (3-16 letters/numbers)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            isError = error != null, supportingText = { val e = error; if (e != null) Text(e) else if (saved) Text("Saved ✅") }
        )
        GoldButton("SAVE USERNAME", {
            if (vm.setName(name)) { saved = true; error = null } else error = "Use 3-16 letters, numbers, spaces or _"
        }, Modifier.fillMaxWidth())

        SectionTitle("📊 Game statistics", Modifier.fillMaxWidth())
        val rows = listOf(
            "Player level" to "${p.level}", "Total virtual spins" to p.totalSpins.fmt(), "Total virtual wins" to p.totalWins.fmt(),
            "Virtual coins played" to p.totalWagered.fmt(), "Virtual credits earned" to p.totalEarned.fmt(),
            "Biggest win" to p.biggestWin.fmt(), "Big wins" to "${p.bigWins}", "Free spin rounds" to "${p.freeSpinsTriggered}",
            "Jackpots" to "${p.jackpots}", "Daily streak" to "${rw.streak} day(s)",
            "Achievements" to "${rw.achievements.count { it.unlocked }}/${rw.achievements.size}"
        )
        GlassCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                rows.forEach { (k, v) ->
                    Row { Text(k, color = TextDim, modifier = Modifier.weight(1f), fontSize = 13.sp); Text(v, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GoldButton("📜 HISTORY", onHistory, Modifier.weight(1f))
            GoldButton("⚙️ SETTINGS", onSettings, Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
    }
}
