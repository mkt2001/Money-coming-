package com.moneycoming.slot.repository

import com.moneycoming.slot.security.SecureStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class Settings(
    val sound: Boolean = true, val volume: Float = 0.8f, val animations: Boolean = true,
    val quickSpin: Boolean = false, val particles: Boolean = true
)

class SettingsManager(private val store: SecureStore) {
    private val _state = MutableStateFlow(
        Settings(
            store.bool("s_sound", true), store.float("s_volume", 0.8f), store.bool("s_anim", true),
            store.bool("s_quick", false), store.bool("s_particles", true)
        )
    )
    val state: StateFlow<Settings> = _state

    fun update(f: (Settings) -> Settings) {
        val s = f(_state.value)
        store.put("s_sound" to s.sound, "s_volume" to s.volume, "s_anim" to s.animations,
            "s_quick" to s.quickSpin, "s_particles" to s.particles)
        _state.value = s
    }
}
