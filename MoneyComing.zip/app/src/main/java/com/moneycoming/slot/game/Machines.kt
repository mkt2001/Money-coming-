package com.moneycoming.slot.game

data class Machine(
    val id: String, val name: String, val tagline: String, val category: String,
    val emoji: String, val c1: Long, val c2: Long, val isNew: Boolean, val popular: Boolean
)

/** Different themes of the same audited engine (same probabilities, see Paytable). */
object Machines {
    val ALL = listOf(
        Machine("money", "Money Coming", "The golden classic", "Classic", "💰", 0xFFFFB300, 0xFF4A148C, false, true),
        Machine("dragon", "Neon Dragon", "Free spins & sticky wilds", "Bonus", "🐲", 0xFFFF2BD6, 0xFF0E3A5C, true, true),
        Machine("gems", "Cosmic Gems", "Chase the jackpot", "Jackpot", "💎", 0xFF22D3EE, 0xFF3B1C8C, false, false),
        Machine("fortune", "Lucky Fortune", "Red & gold luck", "Classic", "🧧", 0xFFFF5252, 0xFF5D1049, true, false),
        Machine("rush", "Diamond Rush", "Big multipliers", "Jackpot", "👑", 0xFF7C4DFF, 0xFF0B3D2E, false, true)
    )
    val CATEGORIES = listOf("All", "Classic", "Bonus", "Jackpot")
    fun byId(id: String?) = ALL.firstOrNull { it.id == id } ?: ALL[0]
}
