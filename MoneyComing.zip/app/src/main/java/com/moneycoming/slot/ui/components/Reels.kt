package com.moneycoming.slot.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.moneycoming.slot.game.Cell
import com.moneycoming.slot.game.GameConfig
import com.moneycoming.slot.game.Sym

private const val RANDOM_CELLS = 11

@Composable
fun ReelsView(
    grid: List<List<Sym>>, prev: List<List<Sym>>, spinId: Int, baseMs: Int, stepMs: Int,
    highlight: Set<Cell>, accent: Color, onReelStop: (Int) -> Unit, modifier: Modifier = Modifier
) {
    Row(
        modifier.clip(RoundedCornerShape(16.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF0E0820), Color(0xFF05020D))))
            .border(3.dp, Brush.verticalGradient(listOf(Color(0xFFFFE27A), accent)), RoundedCornerShape(16.dp))
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        for (reel in 0 until GameConfig.REELS) {
            Reel(
                reel = reel,
                fin = grid.map { it[reel] },
                previous = prev.map { it[reel] },
                spinId = spinId,
                durationMs = baseMs + stepMs * reel,
                glowRows = highlight.filter { it.second == reel }.map { it.first }.toSet(),
                onStop = onReelStop
            )
        }
    }
}

@Composable
private fun RowScope.Reel(
    reel: Int, fin: List<Sym>, previous: List<Sym>, spinId: Int, durationMs: Int,
    glowRows: Set<Int>, onStop: (Int) -> Unit
) {
    // Strip, top to bottom: final 3 | random filler | previous 3. It slides down from the bottom to the top.
    val filler = remember(spinId) { List(RANDOM_CELLS) { Sym.values().random() } }
    val strip = fin + filler + previous
    val progress = remember(spinId) { Animatable(if (spinId > 0) 0f else 1f) }
    LaunchedEffect(spinId) {
        if (spinId > 0) {
            progress.animateTo(1f, tween(durationMs, easing = CubicBezierEasing(0.15f, 0.85f, 0.2f, 1f)))
            onStop(reel)
        }
    }
    BoxWithConstraints(
        Modifier.weight(1f).aspectRatio(1f / 3f).clip(RoundedCornerShape(10.dp))
            .background(Color(0x22FFFFFF))
    ) {
        val cellH = maxHeight / 3
        val cellPx = with(LocalDensity.current) { cellH.toPx() }
        val fontSp = maxWidth.value * 0.52f
        val shift = (strip.size - 3) * cellPx
        Column(
            Modifier.fillMaxWidth().wrapContentHeight(Alignment.Top, unbounded = true)
                .graphicsLayer { translationY = -shift * (1f - progress.value) }
        ) {
            strip.forEachIndexed { i, s ->
                SymbolTile(
                    s, fontSp, glow = progress.value >= 1f && i < 3 && i in glowRows,
                    modifier = Modifier.fillMaxWidth().height(cellH)
                )
            }
        }
    }
}
