package com.moneycoming.slot.wallet

import com.moneycoming.slot.database.TxDao
import com.moneycoming.slot.database.TxRecord
import com.moneycoming.slot.game.GameConfig
import com.moneycoming.slot.security.SecureStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.max
import kotlin.math.min

/** Virtual-coin wallet. Coins have no cash value and can never be withdrawn or converted. */
class WalletEngine(private val store: SecureStore, private val tx: TxDao) {
    private val mutex = Mutex()
    private val _balance = MutableStateFlow(store.long("balance", GameConfig.START_BALANCE))
    val balance: StateFlow<Long> = _balance

    var maxBalance: Long
        get() = store.long("max_balance", GameConfig.DEFAULT_MAX_BALANCE)
        set(v) { store.put("max_balance" to v) }

    private suspend fun log(type: String, amount: Long, after: Long, note: String) {
        tx.insert(TxRecord(time = System.currentTimeMillis(), type = type, amount = amount, balanceAfter = after, note = note))
        tx.prune()
    }

    /** Adds [amount] (> 0) coins; the balance is clamped to the configured maximum. */
    suspend fun credit(amount: Long, type: String, note: String): Long = mutex.withLock {
        require(amount >= 0)
        val before = _balance.value
        val after = min(maxBalance, before + amount)
        persist(after)
        log(type, after - before, after, note)
        after
    }

    /**
     * Settles one spin atomically: pays [stake] and credits [win]. Returns the new balance,
     * or -1 when the balance is too low (nothing is changed in that case).
     */
    suspend fun settleSpin(stake: Long, win: Long, free: Boolean, note: String): Long = mutex.withLock {
        val cur = _balance.value
        if (stake > cur || stake < 0 || win < 0) return@withLock -1L
        val after = min(maxBalance, cur - stake + win)
        persist(after)
        log(if (free) "FREE_SPIN" else "SPIN", after - cur, after, note)
        after
    }

    suspend fun reset() = mutex.withLock {
        persist(GameConfig.START_BALANCE)
        tx.clear()
    }

    private fun persist(v: Long) {
        val safe = max(0L, v)
        store.put("balance" to safe)
        _balance.value = safe
    }
}
