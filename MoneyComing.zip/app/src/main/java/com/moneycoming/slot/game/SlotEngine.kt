package com.moneycoming.slot.game

import java.util.Random
import kotlin.math.min
import kotlin.math.roundToLong

typealias Cell = Pair<Int, Int> // (row, reel)

enum class WinTier(val label: String) {
    NONE("No win"), SMALL("Small Win"), NORMAL("Normal Win"), BIG("BIG WIN"),
    MEGA("MEGA WIN"), SUPER("SUPER WIN"), JACKPOT("JACKPOT!")
}

data class LineWin(val line: Int, val sym: Sym, val count: Int, val cells: List<Cell>, val amount: Long)
data class FreeSpinAward(val spins: Int, val mult: Int)

sealed class Bonus {
    abstract val prize: Long
    /** segments are multipliers shown on the wheel; [target] is the index it stops on. */
    data class Wheel(val segments: List<Int>, val target: Int, override val prize: Long, val premium: Boolean) : Bonus()
    /** values[0..2] are what the 1st, 2nd and 3rd picks reveal; the rest are decoys. */
    data class Pick(val values: List<Long>, override val prize: Long) : Bonus()
    data class Mystery(val mult: Int, override val prize: Long) : Bonus()
}

data class SpinResult(
    val grid: List<List<Sym>>,            // [row][reel]
    val lineWins: List<LineWin>,
    val lineTotal: Long,
    val spinMult: Int,
    val scatterPay: Long,
    val bonuses: List<Bonus>,
    val totalWin: Long,
    val freeSpins: FreeSpinAward?,
    val jackpot: Boolean,
    val nearMiss: Boolean,
    val counts: Map<Sym, Int>,
    val highlight: Set<Cell>,
    val wildCells: Set<Cell>
)

data class SimReport(
    val spins: Int, val rtp: Double, val hitRate: Double, val freeSpinRate: Double,
    val bigWinRate: Double, val jackpotRate: Double, val biggestMult: Double
)

class SlotEngine(private val rng: Random) {

    private fun <T> pick(items: List<Pair<T, Int>>): T {
        var r = rng.nextInt(items.sumOf { it.second })
        for ((k, w) in items) { r -= w; if (r < 0) return k }
        return items.last().first
    }

    private val cellTable = GameConfig.WEIGHTS.toList()
    private val cellTableNoWild = cellTable.filter { it.first != Sym.WILD }

    private fun randomCell(reel: Int): Sym =
        pick(if (reel in 1..3) cellTable else cellTableNoWild)

    /**
     * One spin. Pass [sticky] (a mutable set) when playing a free spin: wilds that land are kept
     * for the remaining free spins. In the base game a wild on reel 3 expands over the reel.
     */
    fun spin(bet: Long, freeMult: Int = 1, sticky: MutableSet<Cell>? = null): SpinResult {
        val free = sticky != null
        val g = Array(GameConfig.ROWS) { Array(GameConfig.REELS) { reel -> randomCell(reel) } }
        if (free) {
            sticky!!.forEach { (row, reel) -> g[row][reel] = Sym.WILD }
            for (row in 0 until GameConfig.ROWS) for (reel in 0 until GameConfig.REELS)
                if (g[row][reel] == Sym.WILD) sticky.add(row to reel)
        } else if ((0 until GameConfig.ROWS).any { g[it][2] == Sym.WILD }) {
            for (row in 0 until GameConfig.ROWS) g[row][2] = Sym.WILD
        }

        val counts = Sym.values().associateWith { s -> g.sumOf { row -> row.count { it == s } } }
        val multCount = counts[Sym.MULT] ?: 0
        val spinMult = min(GameConfig.MAX_SPIN_MULT, 1 + multCount) * freeMult

        val lineWins = ArrayList<LineWin>()
        val highlight = HashSet<Cell>()
        var jackpot = false
        GameConfig.LINES.forEachIndexed { idx, rows ->
            val line = rows.mapIndexed { reel, row -> g[row][reel] }
            val base = line.firstOrNull { it != Sym.WILD } ?: Sym.CROWN
            val pays = GameConfig.PAYS[base] ?: return@forEachIndexed
            var cnt = 0
            var wild = false
            for (s in line) {
                if (s == base || (s == Sym.WILD && base != Sym.JACKPOT)) { cnt++; wild = wild || s == Sym.WILD } else break
            }
            if (cnt >= 3) {
                val units = pays[cnt - 3] * (if (wild) GameConfig.WILD_LINE_MULT else 1)
                val amt = (bet * units * GameConfig.LINE_SCALE / GameConfig.PAYLINES * spinMult).roundToLong()
                val cells = (0 until cnt).map { rows[it] to it }
                lineWins.add(LineWin(idx, base, cnt, cells, amt))
                highlight.addAll(cells)
                if (base == Sym.JACKPOT && cnt == 5) jackpot = true
            }
        }
        val lineTotal = lineWins.sumOf { it.amount }

        fun cap(n: Int) = min(5, n)
        val sc = cap(counts[Sym.SCATTER] ?: 0)
        val bo = cap(counts[Sym.BONUS] ?: 0)
        val fr = cap(counts[Sym.FREE] ?: 0)
        fun cellsOf(s: Sym): List<Cell> = buildList {
            for (row in 0 until GameConfig.ROWS) for (reel in 0 until GameConfig.REELS) if (g[row][reel] == s) add(row to reel)
        }

        val bonuses = ArrayList<Bonus>()
        var scatterPay = 0L
        if (sc >= 3) {
            scatterPay = bet * GameConfig.SCATTER_PAY[sc - 3]
            highlight.addAll(cellsOf(Sym.SCATTER))
            when (sc) {
                3 -> {
                    val segs = GameConfig.WHEEL.map { it.first }
                    val m = pick(GameConfig.WHEEL)
                    bonuses.add(Bonus.Wheel(segs, segs.indexOf(m), bet * m, false))
                }
                4 -> {
                    val picks = List(3) { pick(GameConfig.PICK).toLong() * bet }
                    val decoys = List(9) { pick(GameConfig.PICK).toLong() * bet }
                    bonuses.add(Bonus.Pick(picks + decoys, picks.sum()))
                }
                else -> {
                    val segs = GameConfig.PREMIUM_WHEEL.map { it.first }
                    val m = pick(GameConfig.PREMIUM_WHEEL)
                    if (m == GameConfig.PREMIUM_JACKPOT_MULT) jackpot = true
                    bonuses.add(Bonus.Wheel(segs, segs.indexOf(m), bet * m, true))
                }
            }
        }
        if (bo >= 3) {
            highlight.addAll(cellsOf(Sym.BONUS))
            val k = when (bo) { 3 -> 1; 4 -> 2; else -> 5 }
            val m = pick(GameConfig.MYSTERY)
            bonuses.add(Bonus.Mystery(m * k, bet * m * k))
        }
        var award: FreeSpinAward? = null
        if (fr >= 3 && !free) {
            highlight.addAll(cellsOf(Sym.FREE))
            val (n, m) = GameConfig.FREE_SPINS[fr - 3]
            award = FreeSpinAward(n, m)
        }
        val wildCells = cellsOf(Sym.WILD).toSet()
        val total = lineTotal + scatterPay + bonuses.sumOf { it.prize }
        val near = total == 0L && ((counts[Sym.SCATTER] ?: 0) == 2 || (!free && (counts[Sym.FREE] ?: 0) == 2))
        return SpinResult(
            g.map { it.toList() }, lineWins, lineTotal, spinMult, scatterPay, bonuses, total,
            award, jackpot, near, counts, highlight, wildCells
        )
    }

    fun tier(win: Long, bet: Long, jackpot: Boolean): WinTier {
        if (jackpot) return WinTier.JACKPOT
        if (win <= 0 || bet <= 0) return WinTier.NONE
        val m = win.toDouble() / bet
        return when {
            m < 5 -> WinTier.SMALL
            m < 20 -> WinTier.NORMAL
            m < 50 -> WinTier.BIG
            m < 100 -> WinTier.MEGA
            else -> WinTier.SUPER
        }
    }

    /** Plays [spins] full rounds (including free spins) and reports the observed statistics. */
    fun simulate(spins: Int, bet: Long = 1000, progress: (Int) -> Unit = {}): SimReport {
        var wagered = 0.0; var won = 0.0; var hits = 0; var frees = 0; var bigs = 0; var jps = 0; var best = 0.0
        for (i in 0 until spins) {
            val r = spin(bet)
            wagered += bet; won += r.totalWin
            if (r.totalWin > 0) hits++
            if (r.jackpot) jps++
            if (tier(r.totalWin, bet, r.jackpot) >= WinTier.BIG) bigs++
            best = maxOf(best, r.totalWin.toDouble() / bet)
            r.freeSpins?.let { aw ->
                frees++
                val sticky = HashSet<Cell>()
                repeat(aw.spins) {
                    val f = spin(bet, aw.mult, sticky)
                    won += f.totalWin
                    if (f.jackpot) jps++
                }
            }
            if (i % 5000 == 0) progress(i)
        }
        return SimReport(spins, won / wagered, hits.toDouble() / spins, frees.toDouble() / spins,
            bigs.toDouble() / spins, jps.toDouble() / spins, best)
    }
}
