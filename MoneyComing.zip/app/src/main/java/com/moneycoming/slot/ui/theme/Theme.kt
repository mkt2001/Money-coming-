package com.moneycoming.slot.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val Gold = Color(0xFFFFD54A)
val GoldDeep = Color(0xFFFFA000)
val Bg = Color(0xFF0B0614)
val CardBg = Color(0xFF1A0F2E)
val Purple = Color(0xFF7C3AED)
val PurpleDeep = Color(0xFF2A0B4F)
val Neon = Color(0xFFFF2BD6)
val Cyan = Color(0xFF22D3EE)
val Good = Color(0xFF34D399)
val Danger = Color(0xFFFF5470)
val TextDim = Color(0xFFB9A9D9)

val BgBrush = Brush.verticalGradient(listOf(Color(0xFF1B0B3A), Bg, Color(0xFF06030C)))
val GoldBrush = Brush.verticalGradient(listOf(Color(0xFFFFE27A), GoldDeep))

@Composable
fun MoneyComingTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold, onPrimary = Color.Black, secondary = Purple, background = Bg,
            surface = CardBg, onSurface = Color.White, onBackground = Color.White
        ),
        typography = Typography(),
        content = content
    )
}
