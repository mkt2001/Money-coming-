package com.moneycoming.slot.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.moneycoming.slot.game.Machine
import com.moneycoming.slot.game.Machines
import com.moneycoming.slot.profile.AVATARS
import com.moneycoming.slot.profile.Profile
import com.moneycoming.slot.ui.components.BalancePill
import com.moneycoming.slot.ui.components.Chip
import com.moneycoming.slot.ui.components.GlassCard
import com.moneycoming.slot.ui.components.GoldButton
import com.moneycoming.slot.ui.components.SectionTitle
import com.moneycoming.slot.ui.theme.*
import com.moneycoming.slot.util.compact
import com.moneycoming.slot.util.dateTime
import com.moneycoming.slot.util.fmt
import com.moneycoming.slot.viewmodel.MainViewModel

@Composable
fun AvatarCircle(p: Profile, size: Int = 48, onClick: (() -> Unit)? = null) {
    val c = Color(p.vip.colorHex)
    val m = Modifier.size(size.dp).clip(CircleShape).background(Brush.verticalGradient(listOf(Color(0xFF4A1F90), Color(0xFF1A0F2E)))).border(2.5.dp, c, CircleShape)
    Box(if (onClick != null) m.clickable(onClick = onClick) else m, contentAlignment = Alignment.Center) {
        Text(AVATARS[p.avatar.coerceIn(0, AVATARS.lastIndex)], fontSize = (size * 0.5f).sp)
    }
}

@Composable
fun HomeScreen(vm: MainViewModel, onOpenSlot: (String) -> Unit, onNav: (String) -> Unit) {
    val balance by vm.balance.collectAsState()
    val p by vm.profile.collectAsState()
    val rw by vm.rewards.collectAsState()
    val spins by vm.spins.collectAsState(initial = emptyList())
    var cat by remember { mutableStateOf("All") }
    LaunchedEffect(Unit) { vm.refreshRewards() }
    val machines = Machines.ALL.filter { cat == "All" || it.category == cat }

    LazyColumn(Modifier.fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // premium top navigation
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AvatarCircle(p, 50) { onNav("profile") }
                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                    Text(p.name, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, maxLines = 1)
                    Text("${p.vip.badge} VIP ${p.vip.name} • Lv ${p.level}", color = Color(p.vip.colorHex), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                IconBtn("🔔") { vm.showNotifications() }
                Spacer(Modifier.width(8.dp))
                IconBtn("⚙️") { onNav("settings") }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BalancePill(balance, Modifier.weight(1f))
                GoldButton(if (rw.canDaily) "🎁 DAILY REWARD" else "🎁 REWARDS", { onNav("rewards") }, height = 38.dp, fontSize = 13.sp)
            }
        }
        // reward banners
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (rw.welcome) item { Banner("🎁 Welcome Reward", "+1,00,000 coins — tap to claim", listOf(Color(0xFF7C3AED), Color(0xFFEC4899))) { vm.claimWelcome() } }
                if (rw.canEvent) item { Banner("🔥 Bonus Event", "Today's event: +${rw.eventReward.compact()} coins", listOf(Color(0xFFFF6D00), Color(0xFFD50000))) { vm.claimEvent() } }
                if (rw.canSpin) item { Banner("🎡 Free Daily Spin", "Spin the wheel for up to 10 lakh", listOf(Color(0xFF00BFA5), Color(0xFF1565C0))) { onNav("rewards") } }
                item { Banner("👑 VIP Club", "Wager more to climb Bronze → Elite", listOf(Color(0xFF3949AB), Color(0xFF8E24AA))) { onNav("vip") } }
            }
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Machines.CATEGORIES) { c -> Chip(c, c == cat) { vm.click(); cat = c } }
            }
        }
        item { SectionTitle("🎰 Featured Slot Machines") }
        item {
            if (machines.isEmpty()) Text("No games in this category", color = TextDim)
            else LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(machines) { m -> MachineCard(m) { vm.click(); onOpenSlot(m.id) } }
            }
        }
        item { SectionTitle("🔥 Popular Games") }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(Machines.ALL.filter { it.popular }) { m -> MachineCard(m, small = true) { vm.click(); onOpenSlot(m.id) } }
            }
        }
        item { SectionTitle("✨ New Games") }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(Machines.ALL.filter { it.isNew }) { m -> MachineCard(m, small = true) { vm.click(); onOpenSlot(m.id) } }
            }
        }
        item { SectionTitle("🏆 Recent Winners (simulated)") }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    vm.winners.forEach { w ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🏅", fontSize = 16.sp)
                            Text("  ${w.name} won on ${w.game}", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f), maxLines = 1)
                            Text(w.amount.compact(), color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                        }
                    }
                    Text("Demo names for display only — not real players.", color = TextDim, fontSize = 10.sp)
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionTitle("📜 Game History", Modifier.weight(1f))
                Text("View all ›", color = Gold, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onNav("history") })
            }
        }
        if (spins.isEmpty()) item { Text("No games played yet — pick a machine and spin!", color = TextDim, fontSize = 13.sp) }
        else items(spins.take(3)) { s ->
            GlassCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(s.game + if (s.free) " (free spin)" else "", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(s.time.dateTime(), color = TextDim, fontSize = 11.sp)
                    }
                    Text(if (s.win > 0) "+${s.win.fmt()}" else "-${s.bet.fmt()}", color = if (s.win > 0) Good else Danger, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
        item { Text("Virtual coins only. No real-money deposits, withdrawals or prizes. Game results are simulated.", color = TextDim.copy(alpha = 0.7f), fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
    }
}

@Composable
private fun IconBtn(text: String, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape).background(Color(0xFF2B1650)).border(1.dp, Color(0x55B388FF), CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, fontSize = 18.sp) }
}

@Composable
private fun Banner(title: String, sub: String, colors: List<Color>, onClick: () -> Unit) {
    Box(
        Modifier.width(250.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(colors)).clickable(onClick = onClick).padding(14.dp)
    ) {
        Column {
            Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            Text(sub, color = Color(0xE6FFFFFF), fontSize = 12.sp)
        }
    }
}

@Composable
fun MachineCard(m: Machine, small: Boolean = false, onClick: () -> Unit) {
    val w = if (small) 130.dp else 170.dp
    val h = if (small) 150.dp else 200.dp
    Box(
        Modifier.width(w).height(h).clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(Color(m.c2), Color(m.c1).copy(alpha = 0.55f), Bg)))
            .border(1.5.dp, Color(m.c1).copy(alpha = 0.8f), RoundedCornerShape(20.dp)).clickable(onClick = onClick)
    ) {
        if (m.isNew) Text("NEW", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 10.sp,
            modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).clip(RoundedCornerShape(50)).background(Neon).padding(horizontal = 8.dp, vertical = 2.dp))
        Column(Modifier.align(Alignment.Center).padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(m.emoji, fontSize = if (small) 40.sp else 58.sp)
            Text(m.name, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = if (small) 13.sp else 16.sp, textAlign = TextAlign.Center, maxLines = 1)
            if (!small) Text(m.tagline, color = Color(0xCCFFFFFF), fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 2)
            Spacer(Modifier.height(8.dp))
            Text("PLAY", color = Color(0xFF3B2300), fontWeight = FontWeight.ExtraBold, fontSize = 13.sp,
                modifier = Modifier.clip(RoundedCornerShape(50)).background(GoldBrush).padding(horizontal = 18.dp, vertical = 6.dp))
        }
    }
}
