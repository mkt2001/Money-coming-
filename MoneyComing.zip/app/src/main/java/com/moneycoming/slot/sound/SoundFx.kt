package com.moneycoming.slot.sound

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import com.moneycoming.slot.repository.SettingsManager
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.PI
import kotlin.math.sin

enum class Fx { CLICK, SPIN, REEL_STOP, SCATTER, WILD, BONUS, WIN_SMALL, WIN_BIG, JACKPOT, COIN }

/** All sounds are synthesised at start-up (no audio assets needed) and played through SoundPool. */
class SoundFx(private val ctx: Context, private val settings: SettingsManager) {
    private val rate = 22050
    private val pool = SoundPool.Builder().setMaxStreams(6).setAudioAttributes(
        AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
    ).build()
    private val ids = HashMap<Fx, Int>()
    private val loaded = HashSet<Int>()

    init {
        pool.setOnLoadCompleteListener { _, id, status -> if (status == 0) synchronized(loaded) { loaded.add(id) } }
        Thread {
            try {
                for (fx in Fx.values()) {
                    val f = File(ctx.cacheDir, "fx_${fx.name}.wav")
                    f.writeBytes(wav(synth(fx)))
                    ids[fx] = pool.load(f.absolutePath, 1)
                }
            } catch (_: Exception) { /* sound is optional */ }
        }.start()
    }

    fun play(fx: Fx) {
        val s = settings.state.value
        if (!s.sound) return
        val id = ids[fx] ?: return
        val ok = synchronized(loaded) { id in loaded }
        if (ok) pool.play(id, s.volume, s.volume, 1, 0, 1f)
    }

    private fun notes(vararg n: Pair<Double, Int>, decay: Double = 5.0, gap: Int = 0): ShortArray {
        val out = ArrayList<Short>()
        for ((f, ms) in n) {
            val len = rate * ms / 1000
            for (i in 0 until len) {
                val t = i.toDouble() / rate
                val env = minOf(1.0, i / 120.0) * Math.exp(-decay * i / len)
                val v = (sin(2 * PI * f * t) * 0.6 + sin(4 * PI * f * t) * 0.2) * env
                out.add((v * 22000).toInt().toShort())
            }
            repeat(rate * gap / 1000) { out.add(0.toShort()) }
        }
        return out.toShortArray()
    }

    private fun sweep(f0: Double, f1: Double, ms: Int): ShortArray {
        val len = rate * ms / 1000
        var phase = 0.0
        return ShortArray(len) { i ->
            val f = f0 + (f1 - f0) * i / len
            phase += 2 * PI * f / rate
            val env = minOf(1.0, i / 200.0) * (1.0 - i.toDouble() / len)
            (sin(phase) * env * 14000).toInt().toShort()
        }
    }

    private fun synth(fx: Fx): ShortArray = when (fx) {
        Fx.CLICK -> notes(900.0 to 45, decay = 7.0)
        Fx.SPIN -> sweep(180.0, 520.0, 450)
        Fx.REEL_STOP -> notes(150.0 to 110, decay = 6.0)
        Fx.SCATTER -> notes(784.0 to 90, 988.0 to 90, 1319.0 to 220, decay = 3.0)
        Fx.WILD -> notes(660.0 to 70, 880.0 to 70, 660.0 to 70, 990.0 to 180, decay = 3.0)
        Fx.BONUS -> notes(523.0 to 110, 659.0 to 110, 784.0 to 110, 1046.0 to 320, decay = 2.5)
        Fx.WIN_SMALL -> notes(880.0 to 90, 1175.0 to 200, decay = 3.5)
        Fx.WIN_BIG -> notes(523.0 to 100, 659.0 to 100, 784.0 to 100, 1046.0 to 100, 784.0 to 100, 1046.0 to 100, 1318.0 to 420, decay = 2.5)
        Fx.JACKPOT -> notes(523.0 to 90, 659.0 to 90, 784.0 to 90, 1046.0 to 90, 1318.0 to 90, 1568.0 to 90,
            1046.0 to 90, 1318.0 to 90, 1568.0 to 90, 2093.0 to 600, decay = 2.0)
        Fx.COIN -> notes(1568.0 to 55, 2093.0 to 160, decay = 4.0)
    }

    private fun wav(pcm: ShortArray): ByteArray {
        val data = pcm.size * 2
        val o = ByteArrayOutputStream()
        fun i32(v: Int) { o.write(v and 255); o.write(v shr 8 and 255); o.write(v shr 16 and 255); o.write(v shr 24 and 255) }
        fun i16(v: Int) { o.write(v and 255); o.write(v shr 8 and 255) }
        o.write("RIFF".toByteArray()); i32(36 + data); o.write("WAVE".toByteArray())
        o.write("fmt ".toByteArray()); i32(16); i16(1); i16(1); i32(rate); i32(rate * 2); i16(2); i16(16)
        o.write("data".toByteArray()); i32(data)
        for (s in pcm) i16(s.toInt())
        return o.toByteArray()
    }
}
