package com.moneycoming.slot.ui.components

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.moneycoming.slot.game.Kind
import com.moneycoming.slot.game.Sym
import com.moneycoming.slot.ui.theme.*
import com.moneycoming.slot.util.fmt
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun GoldButton(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true,
    height: Dp = 48.dp, colors: List<Color> = listOf(Color(0xFFFFE27A), GoldDeep),
    textColor: Color = Color(0xFF3B2300), fontSize: TextUnit = 16.sp
) {
    val shape = RoundedCornerShape(height / 2)
    Box(
        modifier
            .height(height)
            .shadow(if (enabled) 10.dp else 0.dp, shape, ambientColor = colors.last(), spotColor = colors.last())
            .clip(shape)
            .background(Brush.verticalGradient(if (enabled) colors else listOf(Color(0xFF666666), Color(0xFF333333))))
            .border(1.dp, Color(0x66FFFFFF), shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (enabled) textColor else Color.Gray, fontWeight = FontWeight.ExtraBold, fontSize = fontSize, maxLines = 1)
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier, colors: List<Color> = listOf(Color(0xFF2B1650), CardBg),
    border: Color = Color(0x55B388FF), onClick: (() -> Unit)? = null, content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    val m = modifier.clip(shape).background(Brush.linearGradient(colors)).border(BorderStroke(1.dp, border), shape)
    Box(if (onClick != null) m.clickable(onClick = onClick) else m, content = content)
}

@Composable
fun BalancePill(balance: Long, modifier: Modifier = Modifier) {
    Row(
        modifier.clip(RoundedCornerShape(50)).background(Color(0xFF120A24))
            .border(1.dp, Gold.copy(alpha = 0.7f), RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("🪙", fontSize = 16.sp)
        Text(" " + balance.fmt(), color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, maxLines = 1)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = modifier.padding(vertical = 6.dp))
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape).background(if (selected) Brush.verticalGradient(listOf(Color(0xFFFFE27A), GoldDeep)) else Brush.verticalGradient(listOf(Color(0xFF2B1650), Color(0xFF1A0F2E))))
            .border(1.dp, if (selected) Gold else Color(0x44B388FF), shape).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 7.dp)
    ) { Text(text, color = if (selected) Color(0xFF3B2300) else Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
}

@Composable
fun BoxScope.GlowOverlay() {
    val t = rememberInfiniteTransition(label = "glow")
    val a by t.animateFloat(0.3f, 1f, infiniteRepeatable(tween(550), RepeatMode.Reverse), label = "a")
    Box(Modifier.matchParentSize().border(2.dp, Gold.copy(alpha = a), RoundedCornerShape(10.dp)))
}

@Composable
fun SymbolTile(sym: Sym, fontSp: Float, glow: Boolean, modifier: Modifier = Modifier) {
    val (c1, c2) = when (sym.kind) {
        Kind.WILD -> Color(0xFF00E676) to Color(0xFF003D2B)
        Kind.SCATTER -> Color(0xFFFF1744) to Color(0xFF4A0010)
        Kind.BONUS -> Color(0xFFFFAB00) to Color(0xFF4A2C00)
        Kind.JACKPOT -> Color(0xFFFFD54A) to Color(0xFF5A3A00)
        Kind.FREE -> Color(0xFF22D3EE) to Color(0xFF00394A)
        Kind.MULT -> Color(0xFFB388FF) to Color(0xFF2A0B4F)
        Kind.REGULAR -> Color(0xFF6D3FD0) to Color(0xFF1A0F2E)
    }
    Box(
        modifier.padding(2.dp).clip(RoundedCornerShape(10.dp))
            .background(Brush.verticalGradient(listOf(c1.copy(alpha = 0.40f), c2)))
    ) {
        if (glow) GlowOverlay()
        Text(sym.emoji, fontSize = fontSp.sp, modifier = Modifier.align(Alignment.Center), textAlign = TextAlign.Center)
    }
}

/** Counts a number up from 0 to [target] (virtual coins). */
@Composable
fun countUp(target: Long, ms: Int = 1600): Long {
    val a = remember(target) { Animatable(0f) }
    LaunchedEffect(target) { a.animateTo(1f, tween(ms, easing = FastOutSlowInEasing)) }
    return if (a.value >= 1f) target else (target * a.value.toDouble()).toLong()
}

private class P(val x: Float, val speed: Float, val size: Float, val phase: Float, val wob: Float, val kind: Int, val color: Color)

/** Falling coins (kind 0) and confetti (kind 1) drawn on one canvas. */
@Composable
fun Particles(active: Boolean, modifier: Modifier = Modifier.fillMaxSize(), count: Int = 70) {
    if (!active) return
    val palette = listOf(Gold, Neon, Cyan, Good, Color.White, Color(0xFFFF9100))
    val parts = remember { List(count) { P(Random.nextFloat(), 0.25f + Random.nextFloat() * 0.5f, 6f + Random.nextFloat() * 10f, Random.nextFloat(), 1f + Random.nextFloat() * 3f, Random.nextInt(2), palette[Random.nextInt(palette.size)]) } }
    var t by remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) {
        val start = androidx.compose.runtime.withFrameNanos { it }
        while (true) { t = (androidx.compose.runtime.withFrameNanos { it } - start) / 1_000_000_000f }
    }
    Canvas(modifier) {
        parts.forEach { p ->
            val y = (((t * p.speed + p.phase) % 1.15f) - 0.08f) * size.height
            val x = p.x * size.width + sin(t * p.wob + p.phase * 6f) * 24f
            if (p.kind == 0) {
                drawCircle(Color(0xFFFFC107), p.size * 1.3f, Offset(x, y))
                drawCircle(Color(0xFFFFE082), p.size * 0.8f, Offset(x, y))
            } else {
                withTransform({ rotate(t * 180f * p.wob + p.phase * 360f, Offset(x, y)) }) {
                    drawRect(p.color, Offset(x - p.size / 2, y - p.size / 3), Size(p.size, p.size * 0.6f))
                }
            }
        }
    }
}

/** Prize wheel: set [trigger] > 0 to spin it so that segment [target] stops under the pointer. */
@Composable
fun PrizeWheel(labels: List<String>, target: Int, trigger: Int, size: Dp, onDone: () -> Unit) {
    val rot = remember { Animatable(0f) }
    val colors = listOf(Color(0xFF7C3AED), Color(0xFFFFB300), Color(0xFFEC4899), Color(0xFF06B6D4), Color(0xFF22C55E), Color(0xFFEF4444), Color(0xFF3B82F6), Color(0xFFF59E0B))
    LaunchedEffect(trigger) {
        if (trigger > 0 && labels.isNotEmpty()) {
            val seg = 360f / labels.size
            rot.snapTo(0f)
            rot.animateTo(360f * 6 - (target * seg + seg / 2f), tween(4200, easing = FastOutSlowInEasing))
            onDone()
        }
    }
    val paint = remember {
        Paint().apply { isAntiAlias = true; color = android.graphics.Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("▼", color = Gold, fontSize = 30.sp)
        Canvas(Modifier.size(size)) {
            val d = this.size.minDimension
            val r = d / 2
            val c = Offset(this.size.width / 2, this.size.height / 2)
            val seg = 360f / labels.size
            rotate(rot.value, c) {
                labels.forEachIndexed { i, l ->
                    drawArc(colors[i % colors.size], -90f + i * seg, seg, true, Offset(c.x - r, c.y - r), Size(d, d))
                    val nc = drawContext.canvas.nativeCanvas
                    nc.save()
                    nc.rotate(-90f + i * seg + seg / 2f, c.x, c.y)
                    paint.textSize = r * 0.15f
                    nc.drawText(l, c.x + r * 0.62f, c.y + paint.textSize / 3f, paint)
                    nc.restore()
                }
            }
            drawCircle(Color(0xFF1A0F2E), r * 0.16f, c)
            drawCircle(Gold, r * 0.11f, c)
        }
    }
}

@Composable
fun BackBar(title: String, onBack: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(38.dp).clip(CircleShape).background(Color(0xFF2B1650)).border(1.dp, Color(0x55B388FF), CircleShape).clickable(onClick = onBack),
            contentAlignment = Alignment.Center
        ) { Text("←", color = Color.White, fontSize = 20.sp) }
        Text(title, color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, modifier = Modifier.padding(start = 12.dp).weight(1f))
        trailing()
    }
}

