package com.moneycoming.slot.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.moneycoming.slot.MoneyComingApp
import com.moneycoming.slot.game.SimReport
import com.moneycoming.slot.game.SlotEngine
import com.moneycoming.slot.rewards.RewardEngine
import com.moneycoming.slot.sound.Fx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random

data class RewardPopup(val title: String, val amount: Long)
data class Winner(val name: String, val game: String, val amount: Long)
data class SimUi(val running: Boolean = false, val report: SimReport? = null)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val repo = (app as MoneyComingApp).repo
    val balance = repo.wallet.balance
    val profile = repo.profile.state
    val rewards = repo.rewards.state
    val settings = repo.settings.state
    val spins = repo.db.spinDao().recent()
    val wins = repo.db.spinDao().wins()
    val txs = repo.db.txDao().recent()

    private val _popup = MutableStateFlow<RewardPopup?>(null)
    val popup: StateFlow<RewardPopup?> = _popup.asStateFlow()
    private val _dailySpin = MutableStateFlow<Int?>(null)
    val dailySpin: StateFlow<Int?> = _dailySpin.asStateFlow()
    private val _sim = MutableStateFlow(SimUi())
    val sim: StateFlow<SimUi> = _sim.asStateFlow()
    private val _notes = MutableStateFlow<List<String>?>(null)
    val notes: StateFlow<List<String>?> = _notes.asStateFlow()

    /** Simulated "recent winners" ticker. These are NOT real players. */
    val winners: List<Winner> = run {
        val names = listOf("Aarav", "Diya", "Kabir", "Meera", "Rohan", "Isha", "Vihaan", "Anaya", "Arjun", "Kiara")
        val games = com.moneycoming.slot.game.Machines.ALL.map { it.name }
        List(6) { Winner(names.random() + (10..99).random(), games.random(), listOf(25_000L, 80_000L, 2_50_000L, 12_00_000L, 40_00_000L).random() + Random.nextLong(0, 9_999)) }
    }

    init {
        viewModelScope.launch {
            combine(repo.wallet.balance, repo.profile.state) { a, b -> a to b }.collect { repo.rewards.refresh() }
        }
    }

    fun click() = repo.sound.play(Fx.CLICK)
    fun refreshRewards() = repo.rewards.refresh()

    private fun pop(title: String, amount: Long) {
        if (amount > 0) { repo.sound.play(Fx.COIN); _popup.value = RewardPopup(title, amount) }
    }
    fun dismissPopup() { _popup.value = null }

    fun claimDaily() = viewModelScope.launch { pop("Daily Bonus", repo.rewards.claimDaily()) }
    fun claimEvent() = viewModelScope.launch { pop("Event Bonus", repo.rewards.claimEvent()) }
    fun claimWelcome() = viewModelScope.launch { pop("Welcome Reward", repo.rewards.claimWelcome()) }
    fun claimRefill() = viewModelScope.launch { pop("Free Coins", repo.rewards.claimRefill()) }
    fun claimVip() = viewModelScope.launch { pop("VIP Reward", repo.rewards.claimVip()) }
    fun claimMission(id: String) = viewModelScope.launch { pop("Mission Complete", repo.rewards.claimMission(id)) }
    fun claimAchievement(id: String) = viewModelScope.launch { pop("Achievement", repo.rewards.claimAchievement(id)) }

    fun startDailySpin() = viewModelScope.launch {
        val i = repo.rewards.claimDailySpin()
        if (i >= 0) _dailySpin.value = i
    }
    fun finishDailySpin() {
        val i = _dailySpin.value ?: return
        _dailySpin.value = null
        pop("Daily Spin", RewardEngine.SPIN_PRIZES[i])
    }

    fun showNotifications() { _notes.value = repo.rewards.notifications() }
    fun hideNotifications() { _notes.value = null }

    fun setName(n: String) = repo.profile.setName(n)
    fun setAvatar(i: Int) = repo.profile.setAvatar(i)
    fun updateSettings(f: (com.moneycoming.slot.repository.Settings) -> com.moneycoming.slot.repository.Settings) = repo.settings.update(f)
    var maxBalance: Long
        get() = repo.wallet.maxBalance
        set(v) { repo.wallet.maxBalance = v }

    fun runSimulation() {
        if (_sim.value.running) return
        _sim.value = SimUi(true, null)
        viewModelScope.launch {
            val r = withContext(Dispatchers.Default) { SlotEngine(java.util.Random()).simulate(100_000, 1000) }
            _sim.value = SimUi(false, r)
        }
    }

    fun resetAll(onDone: () -> Unit) = viewModelScope.launch { repo.resetEverything(); onDone() }
}
