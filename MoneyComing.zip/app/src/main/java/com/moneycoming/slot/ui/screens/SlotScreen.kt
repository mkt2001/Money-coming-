package com.moneycoming.slot.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.moneycoming.slot.game.WinTier
import com.moneycoming.slot.ui.components.BalancePill
import com.moneycoming.slot.ui.components.GoldButton
import com.moneycoming.slot.ui.components.Particles
import com.moneycoming.slot.ui.components.ReelsView
import com.moneycoming.slot.ui.components.countUp
import com.moneycoming.slot.ui.theme.*
import com.moneycoming.slot.util.fmt
import com.moneycoming.slot.viewmodel.SlotViewModel
import androidx.compose.foundation.layout.RowScope

@Composable
fun SlotScreen(vm: SlotViewModel, onBack: () -> Unit) {
    val ui by vm.ui.collectAsState()
    val settings by vm.settings.collectAsState()
    val m = ui.machine
    val c1 = Color(m.c1)
    val c2 = Color(m.c2)
    val busy = ui.spinning || ui.autoLeft > 0

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(c2, Bg, Color(0xFF06030C))))) {
        Column(Modifier.fillMaxSize().padding(horizontal = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            // top bar
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                RoundBtn("←") { vm.click(); onBack() }
                Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                    Text(m.name, color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, maxLines = 1)
                    Text("${m.emoji} 5 reels • 20 lines • virtual coins", color = TextDim, fontSize = 11.sp, maxLines = 1)
                }
                BalancePill(ui.shownBalance)
            }

            if (ui.inFree) {
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .background(Brush.horizontalGradient(listOf(Color(0xFF00BFA5), Color(0xFF6200EA)))).padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🎡 FREE SPINS: ${ui.freeLeft} left • x${ui.freeMult} • won ${ui.freeTotal.fmt()}", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, maxLines = 1)
                }
                Spacer(Modifier.height(6.dp))
            }

            ReelsView(
                grid = ui.grid, prev = ui.prevGrid, spinId = ui.spinId, baseMs = ui.baseMs, stepMs = ui.stepMs,
                highlight = ui.highlight, accent = c1, onReelStop = { vm.reelStopped(it) },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(10.dp))
            // result strip
            val shownWin = countUp(ui.lastWin, 900)
            Column(Modifier.fillMaxWidth().height(70.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                if (ui.lastWin > 0 && !ui.spinning) {
                    Text("WIN  +${shownWin.fmt()}", color = Good, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp, maxLines = 1)
                    val best = ui.lines.maxByOrNull { it.amount }
                    Text(
                        (if (best != null) "${ui.lines.size} line(s) • best: ${best.count}x ${best.sym.label}" else "Bonus win") + (if (ui.lastWin > 0) "  •  ${"%.1f".format(ui.lastWin.toDouble() / ui.bet)}x bet" else ""),
                        color = TextDim, fontSize = 12.sp, maxLines = 1
                    )
                } else {
                    Text(
                        ui.message, color = if (ui.nearMiss) Neon else if (ui.message.startsWith("⚠")) Danger else TextDim,
                        fontWeight = FontWeight.Bold, fontSize = 15.sp, textAlign = TextAlign.Center, maxLines = 3
                    )
                }
            }

            Spacer(Modifier.weight(1f))

            // bet row
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                RoundBtn("−", 46) { vm.changeBet(-1) }
                Column(
                    Modifier.weight(1f).padding(horizontal = 10.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF120A24))
                        .border(1.dp, Gold.copy(alpha = 0.6f), RoundedCornerShape(14.dp)).padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("TOTAL BET", color = TextDim, fontSize = 10.sp)
                    Text(ui.bet.fmt(), color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                }
                RoundBtn("+", 46) { vm.changeBet(1) }
            }
            Spacer(Modifier.height(10.dp))

            // control row
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
                SmallBtn("AUTO", if (ui.autoLeft > 0) "${ui.autoLeft}" else "") { if (ui.autoLeft > 0) vm.stopAuto() else vm.showAutoPicker() }
                SmallBtn("MAX BET", "") { vm.maxBet() }
                SpinButton(
                    label = when {
                        ui.autoLeft > 0 -> "STOP"
                        ui.inFree -> "FREE"
                        else -> "SPIN"
                    },
                    enabled = !ui.spinning || ui.autoLeft > 0,
                    onClick = { if (ui.autoLeft > 0) vm.stopAuto() else vm.spinClicked() }
                )
                SmallBtn("INFO", "") { vm.showPaytable() }
                SmallBtn(if (settings.sound) "🔊" else "🔇", "") { vm.toggleSound() }
            }
            Spacer(Modifier.height(6.dp))
            Text("Virtual coins only • no real money • simulated results", color = TextDim.copy(alpha = 0.7f), fontSize = 10.sp)
            Spacer(Modifier.height(4.dp))
        }

        Particles(settings.particles && ui.lastWin > 0 && !ui.spinning && ui.overlay == null && ui.lastWin >= ui.bet * 5, Modifier.fillMaxSize(), 36)

        ui.overlay?.let { WinOverlayView(it.tier, it.amount, settings.particles) { vm.dismissOverlay() } }
        ui.dialog?.let { DialogHost(it, vm) }
    }
}

@Composable
private fun RoundBtn(text: String, size: Int = 38, onClick: () -> Unit) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(Brush.verticalGradient(listOf(Color(0xFF3A1F70), Color(0xFF1A0F2E))))
            .border(1.5.dp, Gold.copy(alpha = 0.7f), CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = (size / 2).sp) }
}

@Composable
private fun SmallBtn(title: String, sub: String, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).background(Color(0xFF1F1238)).border(1.dp, Color(0x55B388FF), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, maxLines = 1)
        if (sub.isNotEmpty()) Text(sub, color = Gold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
    }
}

@Composable
private fun SpinButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "spin")
    val pulse by t.animateFloat(1f, 1.06f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "p")
    Box(
        Modifier.size(86.dp).scale(if (enabled) pulse else 1f)
            .shadow(14.dp, CircleShape, ambientColor = Gold, spotColor = Gold)
            .clip(CircleShape)
            .background(Brush.verticalGradient(if (enabled) listOf(Color(0xFFFFE27A), GoldDeep) else listOf(Color(0xFF666666), Color(0xFF333333))))
            .border(3.dp, Color(0x99FFFFFF), CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color(0xFF3B2300), fontWeight = FontWeight.ExtraBold, fontSize = 20.sp) }
}

@Composable
fun WinOverlayView(tier: WinTier, amount: Long, particles: Boolean, onDismiss: () -> Unit) {
    val v = countUp(amount, 2400)
    val t = rememberInfiniteTransition(label = "win")
    val s by t.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(500), RepeatMode.Reverse), label = "s")
    val color = when (tier) {
        WinTier.JACKPOT -> Neon
        WinTier.SUPER -> Color(0xFFFF6D00)
        WinTier.MEGA -> Cyan
        else -> Gold
    }
    Box(Modifier.fillMaxSize().background(Color(0xCC000000)).clickable(onClick = onDismiss), contentAlignment = Alignment.Center) {
        Particles(particles, Modifier.fillMaxSize(), if (tier >= WinTier.SUPER) 110 else 80)
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (tier == WinTier.JACKPOT) "💰" else "🎉", fontSize = 64.sp)
            Text(tier.label, color = color, fontWeight = FontWeight.ExtraBold, fontSize = 44.sp, modifier = Modifier.scale(s), textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Text(v.fmt(), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 38.sp)
            Text("virtual coins", color = TextDim, fontSize = 13.sp)
            Spacer(Modifier.height(18.dp))
            Text("tap to continue", color = TextDim.copy(alpha = 0.7f), fontSize = 12.sp)
        }
    }
}
