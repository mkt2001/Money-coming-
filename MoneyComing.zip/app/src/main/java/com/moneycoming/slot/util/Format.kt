package com.moneycoming.slot.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/** Indian digit grouping: 1,00,00,000 */
fun Long.fmt(): String {
    val sign = if (this < 0) "-" else ""
    val s = abs(this).toString()
    if (s.length <= 3) return sign + s
    var rest = s.dropLast(3)
    val parts = ArrayList<String>()
    while (rest.length > 2) { parts.add(0, rest.takeLast(2)); rest = rest.dropLast(2) }
    if (rest.isNotEmpty()) parts.add(0, rest)
    return sign + parts.joinToString(",") + "," + s.takeLast(3)
}

fun Long.compact(): String = when {
    this >= 10_000_000_000L -> String.format(Locale.US, "%.1fK Cr", this / 10_000_000_000.0)
    this >= 10_000_000L -> String.format(Locale.US, "%.2f Cr", this / 10_000_000.0)
    this >= 100_000L -> String.format(Locale.US, "%.2f L", this / 100_000.0)
    this >= 1_000L -> String.format(Locale.US, "%.1fK", this / 1_000.0)
    else -> this.toString()
}

fun Long.dateTime(): String = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(this))
