package com.moneycoming.slot.game

/**
 * Every probability and payout of the game lives here, in plain sight.
 * Weights are relative: chance of a symbol on one cell = weight / sum(weights).
 * (WILD can only land on reels 2-4, so its weight is ignored on reels 1 and 5.)
 */
object GameConfig {
    const val REELS = 5
    const val ROWS = 3
    const val PAYLINES = 20

    val BETS = longArrayOf(100, 200, 500, 1_000, 2_000, 5_000, 10_000, 25_000, 50_000, 100_000)
    const val START_BALANCE = 10_000_000L              // 1 crore virtual coins
    const val DEFAULT_MAX_BALANCE = 100_00_00_00_000L  // configurable in Settings
    val MAX_BALANCE_OPTIONS = longArrayOf(10_00_00_00_000L, 100_00_00_00_000L, 1000_00_00_00_000L)

    /** Overall scale of line wins, used to tune the return-to-player (about 95%). */
    const val LINE_SCALE = 0.72
    const val WILD_LINE_MULT = 2
    const val MAX_SPIN_MULT = 10

    val WEIGHTS: Map<Sym, Int> = linkedMapOf(
        Sym.CHERRY to 200, Sym.LEMON to 190, Sym.GRAPE to 160, Sym.BELL to 130,
        Sym.STAR to 100, Sym.SEVEN to 70, Sym.DIAMOND to 50, Sym.CROWN to 35,
        Sym.JACKPOT to 8, Sym.WILD to 30, Sym.SCATTER to 25, Sym.BONUS to 20,
        Sym.FREE to 20, Sym.MULT to 25
    )

    /** Line pay in units of (total bet / 20) for 3, 4 and 5 of a kind. */
    val PAYS: Map<Sym, IntArray> = linkedMapOf(
        Sym.CHERRY to intArrayOf(5, 15, 50), Sym.LEMON to intArrayOf(5, 20, 60),
        Sym.GRAPE to intArrayOf(8, 30, 100), Sym.BELL to intArrayOf(10, 50, 150),
        Sym.STAR to intArrayOf(15, 75, 250), Sym.SEVEN to intArrayOf(25, 125, 500),
        Sym.DIAMOND to intArrayOf(40, 200, 1000), Sym.CROWN to intArrayOf(75, 400, 2000),
        Sym.JACKPOT to intArrayOf(100, 500, 20000)
    )

    /** Rows (0 = top) hit on each of the 5 reels, one entry per payline. */
    val LINES: List<IntArray> = listOf(
        intArrayOf(1, 1, 1, 1, 1), intArrayOf(0, 0, 0, 0, 0), intArrayOf(2, 2, 2, 2, 2),
        intArrayOf(0, 1, 2, 1, 0), intArrayOf(2, 1, 0, 1, 2), intArrayOf(0, 0, 1, 0, 0),
        intArrayOf(2, 2, 1, 2, 2), intArrayOf(1, 2, 2, 2, 1), intArrayOf(1, 0, 0, 0, 1),
        intArrayOf(1, 2, 1, 0, 1), intArrayOf(1, 0, 1, 2, 1), intArrayOf(0, 1, 1, 1, 0),
        intArrayOf(2, 1, 1, 1, 2), intArrayOf(0, 1, 0, 1, 0), intArrayOf(2, 1, 2, 1, 2),
        intArrayOf(1, 1, 0, 1, 1), intArrayOf(1, 1, 2, 1, 1), intArrayOf(0, 0, 2, 0, 0),
        intArrayOf(2, 2, 0, 2, 2), intArrayOf(0, 2, 0, 2, 0)
    )

    /** Scatter anywhere: pay in multiples of the total bet for 3, 4, 5. */
    val SCATTER_PAY = intArrayOf(2, 10, 50)
    /** 3 scatter = bonus wheel, 4 = pick-and-win, 5 = premium jackpot wheel. */
    val WHEEL = listOf(2 to 30, 3 to 25, 5 to 20, 10 to 14, 20 to 8, 50 to 3, 100 to 1)
    val PICK = listOf(2 to 30, 3 to 25, 5 to 20, 10 to 14, 25 to 8, 50 to 3)
    val PREMIUM_WHEEL = listOf(25 to 35, 50 to 30, 100 to 20, 250 to 10, 500 to 4, 1000 to 1)
    const val PREMIUM_JACKPOT_MULT = 1000
    /** SUPER SCATTER meter: every scatter that lands is collected; at the threshold a Super Wheel pays and gives 1 respin token. */
    const val SUPER_THRESHOLD = 20
    val SUPER_WHEEL = listOf(1 to 40, 2 to 30, 3 to 15, 5 to 10, 10 to 4, 20 to 1)
    /** 3+ BONUS symbols: mystery reward (x1 for 3, x2 for 4, x5 for 5). */
    val MYSTERY = listOf(5 to 40, 10 to 30, 25 to 20, 50 to 8, 200 to 2)
    /** 3/4/5 FREE symbols: (spins, multiplier). */
    val FREE_SPINS = listOf(8 to 2, 12 to 3, 20 to 5)

    val TIERS = "Small <5x, Normal 5-20x, Big 20-50x, Mega 50-100x, Super 100x+, Jackpot = jackpot hit"
}
