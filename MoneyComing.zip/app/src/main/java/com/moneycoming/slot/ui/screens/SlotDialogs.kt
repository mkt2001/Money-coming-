package com.moneycoming.slot.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.moneycoming.slot.game.Bonus
import com.moneycoming.slot.game.FreeSpinAward
import com.moneycoming.slot.game.GameConfig
import com.moneycoming.slot.ui.components.GlassCard
import com.moneycoming.slot.ui.components.GoldButton
import com.moneycoming.slot.ui.components.Particles
import com.moneycoming.slot.ui.components.PrizeWheel
import com.moneycoming.slot.ui.components.SymbolTile
import com.moneycoming.slot.ui.components.countUp
import com.moneycoming.slot.ui.theme.*
import com.moneycoming.slot.util.fmt
import com.moneycoming.slot.viewmodel.GameDialog
import com.moneycoming.slot.viewmodel.SlotViewModel
import kotlinx.coroutines.delay

@Composable
private fun ModalCard(content: @Composable androidx.compose.foundation.layout.BoxScope.() -> Unit) {
    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false, usePlatformDefaultWidth = false)
    ) {
        GlassCard(Modifier.fillMaxWidth(0.92f), border = Gold.copy(alpha = 0.7f), content = content)
    }
}

@Composable
fun DialogHost(d: GameDialog, vm: SlotViewModel) {
    when (d) {
        is GameDialog.WheelBonus -> WheelDialog(d.b, vm)
        is GameDialog.PickBonus -> PickDialog(d.b, vm)
        is GameDialog.MysteryBonus -> MysteryDialog(d.b, vm)
        is GameDialog.FreeStart -> FreeStartDialog(d.award, vm)
        is GameDialog.FreeEnd -> FreeEndDialog(d.total, vm)
        GameDialog.Paytable -> PaytableDialog(vm)
        GameDialog.AutoPicker -> AutoDialog(vm)
    }
}

@Composable
private fun Title(t: String) =
    Text(t, color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())

@Composable
private fun WheelDialog(b: Bonus.Wheel, vm: SlotViewModel) {
    var trigger by remember { mutableStateOf(0) }
    var done by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(500); trigger = 1 }
    ModalCard {
        Particles(done, Modifier.matchParentSize(), 50)
        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Title(if (b.premium) "👑 PREMIUM JACKPOT WHEEL 👑" else "🎡 BONUS WHEEL")
            PrizeWheel(b.segments.map { "x$it" }, b.target, trigger, 250.dp) { done = true; vm.coinSound() }
            if (done) {
                Text("You won ${b.prize.fmt()} coins!", color = Good, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                GoldButton("COLLECT", { vm.closeDialog() }, Modifier.fillMaxWidth())
            } else Text("Spinning...", color = TextDim)
        }
    }
}

@Composable
private fun PickDialog(b: Bonus.Pick, vm: SlotViewModel) {
    var picked by remember { mutableStateOf(listOf<Int>()) }
    val finished = picked.size == 3
    val decoys = b.values.drop(3)
    val unpicked = (0 until 12).filter { it !in picked }
    ModalCard {
        Particles(finished, Modifier.matchParentSize(), 50)
        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Title("🃏 PICK & WIN")
            Text(if (finished) "All picks revealed!" else "Pick 3 cards (${picked.size}/3)", color = TextDim)
            for (r in 0 until 3) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (c in 0 until 4) {
                        val i = r * 4 + c
                        val isPicked = i in picked
                        val label = when {
                            isPicked -> b.values[picked.indexOf(i)].fmt()
                            finished -> decoys[unpicked.indexOf(i)].fmt()
                            else -> "🎁"
                        }
                        Box(
                            Modifier.weight(1f).aspectRatio(0.8f).clip(RoundedCornerShape(10.dp))
                                .background(if (isPicked) Gold.copy(alpha = 0.9f) else if (finished) Color(0x33FFFFFF) else Purple.copy(alpha = 0.7f))
                                .clickable(enabled = !finished && !isPicked) {
                                    picked = picked + i; vm.coinSound()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(label, color = if (isPicked) Color(0xFF3B2300) else Color.White, fontWeight = FontWeight.Bold,
                                fontSize = if (label == "🎁") 26.sp else 11.sp, textAlign = TextAlign.Center)
                        }
                    }
                }
            }
            if (finished) {
                Text("You won ${b.prize.fmt()} coins!", color = Good, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                GoldButton("COLLECT", { vm.closeDialog() }, Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun MysteryDialog(b: Bonus.Mystery, vm: SlotViewModel) {
    var opened by remember { mutableStateOf(false) }
    ModalCard {
        Particles(opened, Modifier.matchParentSize(), 50)
        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Title("🎁 MYSTERY REWARD")
            Box(Modifier.clickable(enabled = !opened) { opened = true; vm.coinSound() }) {
                Text(if (opened) "💰" else "🎁", fontSize = 90.sp)
            }
            if (!opened) Text("Tap the gift to open it!", color = TextDim)
            else {
                val v = countUp(b.prize, 1200)
                Text("x${b.mult} bet  =  ${v.fmt()} coins", color = Good, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, textAlign = TextAlign.Center)
                GoldButton("COLLECT", { vm.closeDialog() }, Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun FreeStartDialog(a: FreeSpinAward, vm: SlotViewModel) {
    ModalCard {
        Particles(true, Modifier.matchParentSize(), 40)
        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Title("🎡 FREE SPINS!")
            Text("${a.spins}", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 64.sp)
            Text("FREE SPINS  •  x${a.mult} win multiplier", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Wilds that land become STICKY until the free spins end.", color = TextDim, textAlign = TextAlign.Center, fontSize = 13.sp)
            GoldButton("START", { vm.closeDialog() }, Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun FreeEndDialog(total: Long, vm: SlotViewModel) {
    ModalCard {
        Particles(total > 0, Modifier.matchParentSize(), 50)
        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Title("FREE SPINS COMPLETE")
            val v = countUp(total, 1400)
            Text(v.fmt(), color = Good, fontWeight = FontWeight.ExtraBold, fontSize = 36.sp)
            Text("total coins won in free spins", color = TextDim)
            GoldButton("CONTINUE", { vm.closeDialog() }, Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun AutoDialog(vm: SlotViewModel) {
    ModalCard {
        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Title("AUTO SPIN")
            Text("Uses virtual coins only. Stops automatically if your balance is too low.", color = TextDim, textAlign = TextAlign.Center, fontSize = 13.sp)
            for (n in listOf(10, 25, 50, 100)) GoldButton("$n spins", { vm.startAuto(n) }, Modifier.fillMaxWidth())
            GoldButton("Cancel", { vm.closeDialog() }, Modifier.fillMaxWidth(), colors = listOf(Color(0xFF4A3A70), Color(0xFF2B1650)), textColor = Color.White)
        }
    }
}

@Composable
private fun PaytableDialog(vm: SlotViewModel) {
    ModalCard {
        Column(Modifier.padding(16.dp).heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Title("PAYTABLE & ODDS")
            Text("All coins are VIRTUAL. Results are simulated by a secure random number generator.", color = TextDim, fontSize = 12.sp, textAlign = TextAlign.Center)
            Text("Symbol  •  chance per cell  •  pays for 3 / 4 / 5 on a line (x bet ÷ 20)", color = Gold, fontSize = 12.sp)
            vm.paytableText.forEach { (s, pays, chance) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SymbolTile(s, 22f, false, Modifier.width(44.dp).height(44.dp))
                    Column(Modifier.padding(start = 8.dp)) {
                        Text("${s.label}  •  ${"%.1f".format(chance)}%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(if (pays == "-") specialText(s.label) else pays, color = TextDim, fontSize = 11.sp)
                    }
                }
            }
            Text("Features", color = Gold, fontWeight = FontWeight.Bold)
            Text("• ${GameConfig.PAYLINES} paylines, wins pay left to right (3+ symbols).\n" +
                "• WILD (reels 2-4) substitutes for fruit/gem symbols and doubles that line. A wild on reel 3 expands over the whole reel.\n" +
                "• SCATTER anywhere: 3 = Bonus Wheel, 4 = Pick & Win, 5 = Premium Jackpot Wheel (plus scatter pay).\n" +
                "• BONUS 3+ = Mystery Reward. FREE 3+ = 8 / 12 / 20 free spins at x2 / x3 / x5 with sticky wilds.\n" +
                "• MULTIPLIER symbols add +1x to the wins of that spin (max x${GameConfig.MAX_SPIN_MULT}).\n" +
                "• Tiers: ${GameConfig.TIERS}.", color = TextDim, fontSize = 12.sp)
            GoldButton("CLOSE", { vm.closeDialog() }, Modifier.fillMaxWidth())
        }
    }
}

private fun specialText(label: String) = when (label) {
    "Wild" -> "Substitutes, x2 line, expands on reel 3"
    "Scatter" -> "3/4/5 anywhere: wheel / pick & win / jackpot wheel"
    "Bonus" -> "3+ anywhere: mystery reward"
    "Free Spins" -> "3+ anywhere: 8/12/20 free spins"
    else -> "+1x multiplier to the spin's wins"
}
