package com.moneycoming.slot.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.moneycoming.slot.game.GameConfig
import com.moneycoming.slot.ui.components.BackBar
import com.moneycoming.slot.ui.components.Chip
import com.moneycoming.slot.ui.components.GlassCard
import com.moneycoming.slot.ui.components.GoldButton
import com.moneycoming.slot.ui.components.SectionTitle
import com.moneycoming.slot.ui.theme.*
import com.moneycoming.slot.util.compact
import com.moneycoming.slot.util.dateTime
import com.moneycoming.slot.util.fmt
import com.moneycoming.slot.viewmodel.MainViewModel

@Composable
fun HistoryScreen(vm: MainViewModel, onBack: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    val spins by vm.spins.collectAsState(initial = emptyList())
    val wins by vm.wins.collectAsState(initial = emptyList())
    val txs by vm.txs.collectAsState(initial = emptyList())
    Column(Modifier.fillMaxWidth()) {
        BackBar("📜 History", onBack)
        Row(Modifier.padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Games", tab == 0) { tab = 0 }
            Chip("Wins", tab == 1) { tab = 1 }
            Chip("Wallet", tab == 2) { tab = 2 }
        }
        val empty = (tab == 0 && spins.isEmpty()) || (tab == 1 && wins.isEmpty()) || (tab == 2 && txs.isEmpty())
        if (empty) Text("Nothing here yet.", color = TextDim, modifier = Modifier.padding(20.dp))
        LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (tab < 2) {
                items(if (tab == 0) spins else wins) { s ->
                    GlassCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Row {
                                Text(s.game + if (s.free) " • FREE SPIN" else "", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), fontSize = 14.sp)
                                Text(if (s.win > 0) "+${s.win.fmt()}" else "0", color = if (s.win > 0) Good else Danger, fontWeight = FontWeight.ExtraBold)
                            }
                            Text(s.time.dateTime(), color = TextDim, fontSize = 11.sp)
                            Text("Bet ${s.bet.fmt()} • ${"%.2f".format(s.multiplier)}x • ${s.result}", color = Color.White, fontSize = 12.sp)
                            Text("Balance after: ${s.balanceAfter.fmt()} (simulated result)", color = TextDim, fontSize = 11.sp)
                        }
                    }
                }
            } else {
                items(txs) { t ->
                    GlassCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Row {
                                Text(t.type.replace('_', ' '), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), fontSize = 14.sp)
                                Text((if (t.amount >= 0) "+" else "") + t.amount.fmt(), color = if (t.amount >= 0) Good else Danger, fontWeight = FontWeight.ExtraBold)
                            }
                            Text(t.note, color = Color.White, fontSize = 12.sp)
                            Text("${t.time.dateTime()} • balance ${t.balanceAfter.fmt()}", color = TextDim, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit, onReset: () -> Unit) {
    val s by vm.settings.collectAsState()
    val sim by vm.sim.collectAsState()
    var cap by remember { mutableStateOf(vm.maxBalance) }
    var confirm by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
        BackBar("⚙️ Settings", onBack)
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitle("Sound & animation")
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    SwitchRow("Sound effects", s.sound) { v -> vm.updateSettings { it.copy(sound = v) } }
                    Text("Volume", color = TextDim, fontSize = 12.sp)
                    Slider(value = s.volume, onValueChange = { v -> vm.updateSettings { it.copy(volume = v) } }, enabled = s.sound)
                    SwitchRow("Reel & screen animations", s.animations) { v -> vm.updateSettings { it.copy(animations = v) } }
                    SwitchRow("Quick spin (faster reels)", s.quickSpin) { v -> vm.updateSettings { it.copy(quickSpin = v) } }
                    SwitchRow("Particles (coins & confetti)", s.particles) { v -> vm.updateSettings { it.copy(particles = v) } }
                }
            }

            SectionTitle("Maximum virtual wallet balance")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GameConfig.MAX_BALANCE_OPTIONS.forEach { o ->
                    Chip(o.compact(), cap == o) { cap = o; vm.maxBalance = o }
                }
            }
            Text("Winnings that would push the wallet above this cap are trimmed to the cap.", color = TextDim, fontSize = 11.sp)

            SectionTitle("Fairness check")
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Every probability and payout is listed in the INFO (paytable) screen of each game. Run the simulator to play 1,00,000 test rounds (including free spins) on this device and see the real return-to-player.", color = TextDim, fontSize = 12.sp)
                    GoldButton(if (sim.running) "Simulating…" else "RUN 1,00,000-SPIN SIMULATION", { vm.runSimulation() }, Modifier.fillMaxWidth(), enabled = !sim.running)
                    sim.report?.let { r ->
                        Text("Return to player (RTP): ${"%.2f".format(r.rtp * 100)}%", color = Good, fontWeight = FontWeight.Bold)
                        Text("Hit frequency: ${"%.1f".format(r.hitRate * 100)}%", color = Color.White, fontSize = 13.sp)
                        Text("Free spins trigger: 1 in ${if (r.freeSpinRate > 0) (1 / r.freeSpinRate).toInt() else 0} spins", color = Color.White, fontSize = 13.sp)
                        Text("Big wins (20x+): ${"%.2f".format(r.bigWinRate * 100)}% • Jackpots: ${"%.3f".format(r.jackpotRate * 100)}%", color = Color.White, fontSize = 13.sp)
                        Text("Biggest win in test: ${"%.0f".format(r.biggestMult)}x bet", color = Color.White, fontSize = 13.sp)
                        Text("Short-run results vary a lot; RTP is a long-run average of simulated virtual coins.", color = TextDim, fontSize = 10.sp)
                    }
                }
            }

            SectionTitle("About")
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Money Coming is an entertainment game played ONLY with virtual coins. There are no deposits, withdrawals, cash prizes or conversion of coins into money. All results are simulated with a secure random number generator and stored encrypted on your device. Works fully offline.",
                    color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(14.dp))
            }
            GoldButton("RESET ALL PROGRESS", { confirm = true }, Modifier.fillMaxWidth(), colors = listOf(Color(0xFFFF5470), Color(0xFFB00020)), textColor = Color.White)
            Spacer(Modifier.height(20.dp))
        }
    }
    if (confirm) {
        Dialog(onDismissRequest = { confirm = false }) {
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Reset everything?", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    Text("Your wallet, history, VIP level, rewards and settings return to the start (1 crore virtual coins).", color = TextDim, fontSize = 13.sp)
                    GoldButton("YES, RESET", { confirm = false; vm.resetAll(onReset) }, Modifier.fillMaxWidth(), colors = listOf(Color(0xFFFF5470), Color(0xFFB00020)), textColor = Color.White)
                    GoldButton("Cancel", { confirm = false }, Modifier.fillMaxWidth(), colors = listOf(Color(0xFF4A3A70), Color(0xFF2B1650)), textColor = Color.White)
                }
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f), fontSize = 14.sp)
        Switch(checked = value, onCheckedChange = onChange)
    }
}
