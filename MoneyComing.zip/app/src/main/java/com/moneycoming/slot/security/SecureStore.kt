package com.moneycoming.slot.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Encrypted key-value storage (AES-256, Android Keystore backed).
 * If the Keystore is unavailable on a device the game falls back to private plain preferences
 * so it never crashes; nothing sensitive (no real money, no secrets) is stored here.
 */
class SecureStore(context: Context) {
    private val prefs: SharedPreferences = try {
        val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context, "moneycoming_secure", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        context.getSharedPreferences("moneycoming_fallback", Context.MODE_PRIVATE)
    }

    fun long(k: String, d: Long = 0L): Long = try { prefs.getLong(k, d) } catch (e: Exception) { d }
    fun int(k: String, d: Int = 0): Int = try { prefs.getInt(k, d) } catch (e: Exception) { d }
    fun str(k: String, d: String = ""): String = try { prefs.getString(k, d) ?: d } catch (e: Exception) { d }
    fun bool(k: String, d: Boolean = false): Boolean = try { prefs.getBoolean(k, d) } catch (e: Exception) { d }
    fun float(k: String, d: Float = 0f): Float = try { prefs.getFloat(k, d) } catch (e: Exception) { d }
    fun has(k: String) = prefs.contains(k)

    fun put(vararg kv: Pair<String, Any>) {
        val e = prefs.edit()
        for ((k, v) in kv) when (v) {
            is Long -> e.putLong(k, v)
            is Int -> e.putInt(k, v)
            is String -> e.putString(k, v)
            is Boolean -> e.putBoolean(k, v)
            is Float -> e.putFloat(k, v)
        }
        e.apply()
    }

    fun clear() { prefs.edit().clear().apply() }
}
