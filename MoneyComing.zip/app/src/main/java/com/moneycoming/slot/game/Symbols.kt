package com.moneycoming.slot.game

enum class Kind { REGULAR, WILD, SCATTER, BONUS, JACKPOT, FREE, MULT }

enum class Sym(val emoji: String, val kind: Kind, val label: String) {
    CHERRY("🍒", Kind.REGULAR, "Cherry"),
    LEMON("🍋", Kind.REGULAR, "Lemon"),
    GRAPE("🍇", Kind.REGULAR, "Grape"),
    BELL("🔔", Kind.REGULAR, "Bell"),
    STAR("⭐", Kind.REGULAR, "Star"),
    SEVEN("7️⃣", Kind.REGULAR, "Seven"),
    DIAMOND("💎", Kind.REGULAR, "Diamond"),
    CROWN("👑", Kind.REGULAR, "Crown"),
    JACKPOT("💰", Kind.JACKPOT, "Jackpot"),
    WILD("🃏", Kind.WILD, "Wild"),
    SCATTER("🎰", Kind.SCATTER, "Scatter"),
    BONUS("🎁", Kind.BONUS, "Bonus"),
    FREE("🎡", Kind.FREE, "Free Spins"),
    MULT("⚡", Kind.MULT, "Multiplier");
}
