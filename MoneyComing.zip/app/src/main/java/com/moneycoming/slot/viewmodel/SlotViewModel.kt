package com.moneycoming.slot.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.moneycoming.slot.MoneyComingApp
import com.moneycoming.slot.game.*
import com.moneycoming.slot.sound.Fx
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed class GameDialog {
    data class WheelBonus(val b: Bonus.Wheel) : GameDialog()
    data class PickBonus(val b: Bonus.Pick) : GameDialog()
    data class MysteryBonus(val b: Bonus.Mystery) : GameDialog()
    data class FreeStart(val award: FreeSpinAward) : GameDialog()
    data class FreeEnd(val total: Long, val spins: Int) : GameDialog()
    object Paytable : GameDialog()
    object AutoPicker : GameDialog()
}

data class WinOverlay(val tier: WinTier, val amount: Long)

data class SlotUi(
    val machine: Machine,
    val bet: Long = GameConfig.BETS[0],
    val grid: List<List<Sym>> = initialGrid(),
    val prevGrid: List<List<Sym>> = initialGrid(),
    val spinId: Int = 0,
    val spinning: Boolean = false,
    val shownBalance: Long = 0,
    val lastWin: Long = 0,
    val highlight: Set<Cell> = emptySet(),
    val message: String = "Place your bet and SPIN!",
    val autoLeft: Int = 0,
    val freeLeft: Int = 0,
    val freeMult: Int = 1,
    val freeTotal: Long = 0,
    val overlay: WinOverlay? = null,
    val dialog: GameDialog? = null,
    val nearMiss: Boolean = false,
    val baseMs: Int = 850,
    val stepMs: Int = 260,
    val lines: List<LineWin> = emptyList()
) {
    val inFree get() = freeLeft > 0
}

fun initialGrid(): List<List<Sym>> = listOf(
    listOf(Sym.CHERRY, Sym.BELL, Sym.SEVEN, Sym.BELL, Sym.CHERRY),
    listOf(Sym.GRAPE, Sym.STAR, Sym.WILD, Sym.STAR, Sym.GRAPE),
    listOf(Sym.LEMON, Sym.DIAMOND, Sym.CROWN, Sym.DIAMOND, Sym.LEMON)
)

class SlotViewModel(app: Application, handle: SavedStateHandle) : AndroidViewModel(app) {
    private val repo = (app as MoneyComingApp).repo
    private val machine = Machines.byId(handle.get<String>("id"))
    private val _ui = MutableStateFlow(SlotUi(machine, shownBalance = repo.wallet.balance.value))
    val ui: StateFlow<SlotUi> = _ui.asStateFlow()
    val balance get() = repo.wallet.balance
    val settings get() = repo.settings.state

    private var job: Job? = null
    private val sticky = HashSet<Cell>()
    private var autoStopped = false

    init {
        // Resume pending free spins that were won in an earlier session.
        val left = repo.store.int("free_left", 0)
        if (left > 0) {
            val bet = repo.store.long("free_bet", GameConfig.BETS[0])
            _ui.update {
                it.copy(bet = bet, freeLeft = left, freeMult = repo.store.int("free_mult", 2),
                    freeTotal = repo.store.long("free_total", 0), message = "Free spins pending - tap SPIN!")
            }
        }
    }

    private fun timing(): Triple<Int, Int, Int> {
        val s = repo.settings.state.value
        val (base, step) = when {
            !s.animations -> 120 to 30
            s.quickSpin -> 350 to 90
            else -> 850 to 260
        }
        return Triple(base, step, base + step * 4 + 250)
    }

    // ---------- bet controls ----------
    fun click() = repo.sound.play(Fx.CLICK)

    fun changeBet(delta: Int) {
        if (job?.isActive == true || _ui.value.inFree) return
        click()
        val i = GameConfig.BETS.indexOf(_ui.value.bet)
        val n = (i + delta).coerceIn(0, GameConfig.BETS.size - 1)
        val msg = when {
            i + delta < 0 -> "Minimum bet is ${GameConfig.BETS.first()}"
            i + delta >= GameConfig.BETS.size -> "Maximum bet is 1,00,000"
            else -> _ui.value.message
        }
        _ui.update { it.copy(bet = GameConfig.BETS[n], message = msg) }
    }

    fun maxBet() {
        if (job?.isActive == true || _ui.value.inFree) return
        click()
        val bal = repo.wallet.balance.value
        val b = GameConfig.BETS.lastOrNull { it <= bal } ?: GameConfig.BETS.first()
        _ui.update { it.copy(bet = b, message = "Max bet for your balance") }
    }

    fun setBet(b: Long) { if (job?.isActive != true && !_ui.value.inFree) _ui.update { it.copy(bet = b) } }

    // ---------- spin loop ----------
    fun spinClicked() {
        if (job?.isActive == true) return
        click()
        autoStopped = false
        job = viewModelScope.launch { session() }
    }

    fun startAuto(n: Int) {
        if (job?.isActive == true) return
        autoStopped = false
        _ui.update { it.copy(autoLeft = n, dialog = null) }
        job = viewModelScope.launch { session() }
    }

    fun stopAuto() { autoStopped = true; _ui.update { it.copy(autoLeft = 0) } }

    private suspend fun session() {
        try {
            do {
                if (!spinOnce()) break
                while (_ui.value.freeLeft > 0 && !autoStopped) {
                    delay(500)
                    if (!spinOnce()) break
                }
                val left = _ui.value.autoLeft
                if (left > 0) _ui.update { it.copy(autoLeft = left - 1) }
                if (_ui.value.autoLeft > 0) delay(450)
            } while (_ui.value.autoLeft > 0 && !autoStopped)
        } finally {
            _ui.update { it.copy(autoLeft = 0, spinning = false) }
        }
    }

    private suspend fun waitFor(cond: () -> Boolean) { while (cond()) delay(70) }

    private suspend fun spinOnce(): Boolean {
        val free = _ui.value.freeLeft > 0
        val bet = _ui.value.bet
        val before = repo.wallet.balance.value
        if (!free && before < bet) {
            _ui.update { it.copy(message = "⚠️ Insufficient balance for this bet. Lower your bet or claim free coins in Rewards.", autoLeft = 0) }
            return false
        }
        val res = repo.engine.spin(bet, if (free) _ui.value.freeMult else 1, if (free) sticky else null)
        val commit = repo.commitSpin(machine.name, bet, res, free)
        if (commit == null) {
            _ui.update { it.copy(message = "⚠️ Insufficient balance", autoLeft = 0) }
            return false
        }
        // Persist free-spin progress immediately so a spin can never be replayed after leaving the app.
        var freeAfter = _ui.value.freeLeft
        var freeTotalAfter = _ui.value.freeTotal
        if (free) {
            freeAfter -= 1
            freeTotalAfter += res.totalWin
            saveFree(freeAfter, _ui.value.freeMult, bet, freeTotalAfter)
        } else res.freeSpins?.let { saveFree(it.spins, it.mult, bet, 0) }
        val (base, step, total) = timing()
        repo.sound.play(Fx.SPIN)
        _ui.update {
            it.copy(
                prevGrid = it.grid, grid = res.grid, spinId = it.spinId + 1, spinning = true,
                shownBalance = before - (if (free) 0 else bet), lastWin = 0, highlight = emptySet(),
                overlay = null, nearMiss = false, lines = emptyList(), baseMs = base, stepMs = step,
                message = if (free) "FREE SPIN x${it.freeMult}  (${it.freeLeft} left)" else "Good luck!"
            )
        }
        delay(total.toLong())

        _ui.update {
            it.copy(
                spinning = false, shownBalance = commit.balanceAfter, lastWin = res.totalWin,
                highlight = res.highlight + res.wildCells, nearMiss = res.nearMiss, lines = res.lineWins,
                message = when {
                    res.totalWin > 0 -> "WIN ${commit.tier.label}"
                    res.nearMiss -> "So close! Near miss..."
                    else -> "No win this time"
                }
            )
        }
        if (commit.messages.isNotEmpty()) _ui.update { it.copy(message = commit.messages.joinToString("  ")) }
        // sounds
        if (res.wildCells.isNotEmpty()) repo.sound.play(Fx.WILD)
        if ((res.counts[Sym.SCATTER] ?: 0) >= 3 || (res.counts[Sym.FREE] ?: 0) >= 3) repo.sound.play(Fx.SCATTER)
        when (commit.tier) {
            WinTier.NONE -> {}
            WinTier.SMALL, WinTier.NORMAL -> repo.sound.play(Fx.WIN_SMALL)
            WinTier.BIG, WinTier.MEGA, WinTier.SUPER -> repo.sound.play(Fx.WIN_BIG)
            WinTier.JACKPOT -> repo.sound.play(Fx.JACKPOT)
        }

        // big win celebration
        if (commit.tier >= WinTier.BIG) {
            val dur = if (commit.tier >= WinTier.SUPER) 5200L else 3600L
            _ui.update { it.copy(overlay = WinOverlay(commit.tier, res.totalWin)) }
            var t = 0L
            while (_ui.value.overlay != null && t < dur) { delay(70); t += 70 }
            _ui.update { it.copy(overlay = null) }
        } else if (res.totalWin > 0) delay(450)

        // bonus games
        for (b in res.bonuses) {
            repo.sound.play(Fx.BONUS)
            delay(400)
            _ui.update {
                it.copy(dialog = when (b) {
                    is Bonus.Wheel -> GameDialog.WheelBonus(b)
                    is Bonus.Pick -> GameDialog.PickBonus(b)
                    is Bonus.Mystery -> GameDialog.MysteryBonus(b)
                })
            }
            waitFor { _ui.value.dialog != null }
        }

        // free spins bookkeeping
        if (free) {
            _ui.update { it.copy(freeLeft = freeAfter, freeTotal = freeTotalAfter) }
            if (freeAfter == 0) {
                sticky.clear()
                repo.sound.play(Fx.WIN_BIG)
                _ui.update { it.copy(dialog = GameDialog.FreeEnd(freeTotalAfter, 0)) }
                waitFor { _ui.value.dialog != null }
                _ui.update { it.copy(freeTotal = 0, freeMult = 1) }
            }
        } else res.freeSpins?.let { aw ->
            repo.sound.play(Fx.BONUS)
            _ui.update { it.copy(dialog = GameDialog.FreeStart(aw)) }
            waitFor { _ui.value.dialog != null }
            sticky.clear()
            _ui.update { it.copy(freeLeft = aw.spins, freeMult = aw.mult, freeTotal = 0) }
        }
        return true
    }

    private fun saveFree(left: Int, mult: Int, bet: Long, total: Long) {
        repo.store.put("free_left" to left, "free_mult" to mult, "free_bet" to bet, "free_total" to total)
    }

    // ---------- dialogs / overlay ----------
    fun dismissOverlay() = _ui.update { it.copy(overlay = null) }
    fun closeDialog() = _ui.update { it.copy(dialog = null) }
    fun showPaytable() = _ui.update { it.copy(dialog = GameDialog.Paytable) }
    fun showAutoPicker() { if (job?.isActive != true) _ui.update { it.copy(dialog = GameDialog.AutoPicker) } }
    fun reelStopped(reel: Int) { repo.sound.play(Fx.REEL_STOP) }
    fun coinSound() = repo.sound.play(Fx.COIN)
    fun toggleSound() = repo.settings.update { it.copy(sound = !it.sound) }

    val paytableText: List<Triple<Sym, String, Double>> by lazy {
        val total = GameConfig.WEIGHTS.values.sum().toDouble()
        GameConfig.WEIGHTS.map { (s, w) ->
            val pays = GameConfig.PAYS[s]
            Triple(s, pays?.joinToString(" / ") { "${it}x" } ?: "-", w * 100.0 / total)
        }
    }
}
