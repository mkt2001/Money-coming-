package com.moneycoming.slot.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.moneycoming.slot.rewards.RewardEngine
import com.moneycoming.slot.ui.components.GlassCard
import com.moneycoming.slot.ui.components.GoldButton
import com.moneycoming.slot.ui.components.Particles
import com.moneycoming.slot.ui.components.PrizeWheel
import com.moneycoming.slot.ui.components.countUp
import com.moneycoming.slot.ui.screens.HistoryScreen
import com.moneycoming.slot.ui.screens.HomeScreen
import com.moneycoming.slot.ui.screens.ProfileScreen
import com.moneycoming.slot.ui.screens.RewardsScreen
import com.moneycoming.slot.ui.screens.SettingsScreen
import com.moneycoming.slot.ui.screens.SlotScreen
import com.moneycoming.slot.ui.screens.VipScreen
import com.moneycoming.slot.ui.theme.*
import com.moneycoming.slot.util.compact
import com.moneycoming.slot.util.fmt
import com.moneycoming.slot.viewmodel.MainViewModel
import com.moneycoming.slot.viewmodel.SlotViewModel
import kotlinx.coroutines.delay

private val TABS = listOf("home" to ("🏠" to "Home"), "rewards" to ("🎁" to "Rewards"), "vip" to ("👑" to "VIP"), "profile" to ("👤" to "Profile"))

@Composable
fun AppRoot() {
    val vm: MainViewModel = viewModel()
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val showBar = TABS.any { it.first == route }

    fun go(r: String) {
        if (TABS.any { it.first == r }) {
            nav.navigate(r) { popUpTo("home") { saveState = true }; launchSingleTop = true; restoreState = true }
        } else nav.navigate(r) { launchSingleTop = true }
    }

    Box(Modifier.fillMaxSize().background(BgBrush)) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Box(Modifier.weight(1f)) {
                NavHost(nav, startDestination = "home") {
                    composable("home") { HomeScreen(vm, onOpenSlot = { nav.navigate("slot/$it") }, onNav = { go(it) }) }
                    composable("rewards") { RewardsScreen(vm) }
                    composable("vip") { VipScreen(vm) }
                    composable("profile") { ProfileScreen(vm, onHistory = { go("history") }, onSettings = { go("settings") }) }
                    composable("history") { HistoryScreen(vm) { nav.popBackStack() } }
                    composable("settings") {
                        SettingsScreen(vm, onBack = { nav.popBackStack() }, onReset = {
                            nav.navigate("home") { popUpTo("home") { inclusive = true } }
                        })
                    }
                    composable("slot/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) {
                        val svm: SlotViewModel = viewModel()
                        SlotScreen(svm) { nav.popBackStack() }
                    }
                }
            }
            if (showBar) {
                Row(Modifier.fillMaxWidth().background(Color(0xFF0E0820)).padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceAround) {
                    TABS.forEach { (r, ie) ->
                        val sel = route == r
                        Column(
                            Modifier.clickable { vm.click(); go(r) }.padding(horizontal = 14.dp, vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(ie.first, fontSize = 22.sp)
                            Text(ie.second, color = if (sel) Gold else TextDim, fontWeight = if (sel) FontWeight.ExtraBold else FontWeight.Normal, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
        GlobalDialogs(vm)
    }
}

@Composable
private fun GlobalDialogs(vm: MainViewModel) {
    val popup by vm.popup.collectAsState()
    val spin by vm.dailySpin.collectAsState()
    val notes by vm.notes.collectAsState()
    val settings by vm.settings.collectAsState()

    notes?.let { list ->
        Dialog(onDismissRequest = { vm.hideNotifications() }) {
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🔔 Notifications", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    list.forEach { Text(it, color = Color.White, fontSize = 13.sp) }
                    GoldButton("CLOSE", { vm.hideNotifications() }, Modifier.fillMaxWidth())
                }
            }
        }
    }

    spin?.let { idx ->
        var trigger by remember { mutableStateOf(0) }
        var done by remember { mutableStateOf(false) }
        LaunchedEffect(idx) { delay(400); trigger = 1 }
        Dialog(onDismissRequest = {}, properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)) {
            GlassCard(Modifier.fillMaxWidth(), border = Gold) {
                Particles(done && settings.particles, Modifier.matchParentSize(), 50)
                Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("🎡 DAILY SPIN", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                    PrizeWheel(RewardEngine.SPIN_PRIZES.map { it.compact() }, idx, trigger, 240.dp) { done = true }
                    if (done) {
                        Text("You won ${RewardEngine.SPIN_PRIZES[idx].fmt()} coins!", color = Good, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, textAlign = TextAlign.Center)
                        GoldButton("COLLECT", { vm.finishDailySpin() }, Modifier.fillMaxWidth())
                    } else Text("Spinning...", color = TextDim)
                }
            }
        }
    }

    popup?.let { p ->
        Dialog(onDismissRequest = { vm.dismissPopup() }) {
            GlassCard(Modifier.fillMaxWidth(), border = Gold) {
                Particles(settings.particles, Modifier.matchParentSize(), 45)
                Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🎉", fontSize = 56.sp)
                    Text(p.title, color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    val v = countUp(p.amount, 1300)
                    Text("+${v.fmt()}", color = Good, fontWeight = FontWeight.ExtraBold, fontSize = 34.sp)
                    Text("virtual coins added to your wallet", color = TextDim, fontSize = 12.sp)
                    GoldButton("AWESOME!", { vm.dismissPopup() }, Modifier.fillMaxWidth())
                }
            }
        }
    }
}
