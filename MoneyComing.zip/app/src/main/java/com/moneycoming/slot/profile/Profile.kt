package com.moneycoming.slot.profile

import com.moneycoming.slot.game.WinTier
import com.moneycoming.slot.security.SecureStore
import com.moneycoming.slot.wallet.WalletEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.security.SecureRandom

data class VipLevel(
    val idx: Int, val name: String, val badge: String, val minWager: Long,
    val reward: Long, val colorHex: Long, val perks: String
)

object Vip {
    val LEVELS = listOf(
        VipLevel(0, "Bronze", "🥉", 0L, 10_000L, 0xFFCD7F32, "Welcome crown frame"),
        VipLevel(1, "Silver", "🥈", 2_000_000L, 50_000L, 0xFFC0C8D4, "Silver profile frame + 5% daily bonus"),
        VipLevel(2, "Gold", "🥇", 10_000_000L, 150_000L, 0xFFFFD54A, "Golden frame + 10% daily bonus"),
        VipLevel(3, "Platinum", "🏅", 50_000_000L, 500_000L, 0xFF7DE3F4, "Platinum frame + 15% daily bonus"),
        VipLevel(4, "Diamond", "💎", 250_000_000L, 1_500_000L, 0xFF6EA8FF, "Diamond frame + 20% daily bonus"),
        VipLevel(5, "Elite", "👑", 1_000_000_000L, 5_000_000L, 0xFFFF4FD8, "Elite neon frame + 30% daily bonus")
    )
    fun forWager(w: Long): VipLevel = LEVELS.last { w >= it.minWager }
    fun dailyBonusPercent(idx: Int) = intArrayOf(0, 5, 10, 15, 20, 30)[idx]
}

data class Profile(
    val name: String, val avatar: Int, val playerId: String,
    val totalSpins: Long, val totalWins: Long, val totalWagered: Long, val totalEarned: Long,
    val biggestWin: Long, val bigWins: Int, val freeSpinsTriggered: Int, val jackpots: Int
) {
    val level: Int get() = 1 + (totalSpins / 50).toInt()
    val vip: VipLevel get() = Vip.forWager(totalWagered)
    val nextVip: VipLevel? get() = Vip.LEVELS.getOrNull(vip.idx + 1)
    val levelProgress: Float get() = ((totalSpins % 50) / 50f)
}

val AVATARS = listOf("🦁", "🐯", "🦊", "🐼", "🐲", "🦅", "🐺", "🎩", "🤖", "👸", "🤴", "🧞")

class ProfileManager(private val store: SecureStore, private val wallet: WalletEngine) {
    private val _state = MutableStateFlow(load())
    val state: StateFlow<Profile> = _state

    private fun load(): Profile {
        if (!store.has("player_id")) {
            val n = SecureRandom().nextInt(90_000_000) + 10_000_000
            store.put("player_id" to "MC$n", "name" to "Player$n".take(10))
        }
        return Profile(
            store.str("name", "Player"), store.int("avatar", 0), store.str("player_id"),
            store.long("p_spins"), store.long("p_wins"), store.long("p_wager"), store.long("p_earned"),
            store.long("p_best"), store.int("p_bigs"), store.int("p_free"), store.int("p_jp")
        )
    }

    fun reload() { _state.value = load() }

    fun setName(n: String): Boolean {
        val t = n.trim()
        if (!Regex("^[A-Za-z0-9_ ]{3,16}$").matches(t)) return false
        store.put("name" to t); _state.value = _state.value.copy(name = t); return true
    }

    fun setAvatar(i: Int) {
        if (i !in AVATARS.indices) return
        store.put("avatar" to i); _state.value = _state.value.copy(avatar = i)
    }

    /** Updates statistics after a spin and returns messages about level-ups (rewards are credited). */
    suspend fun onSpin(wager: Long, win: Long, tier: WinTier, freeTriggered: Boolean, jackpot: Boolean): List<String> {
        val old = _state.value
        val p = old.copy(
            totalSpins = old.totalSpins + 1,
            totalWins = old.totalWins + if (win > 0) 1 else 0,
            totalWagered = old.totalWagered + wager,
            totalEarned = old.totalEarned + win,
            biggestWin = maxOf(old.biggestWin, win),
            bigWins = old.bigWins + if (tier >= WinTier.BIG) 1 else 0,
            freeSpinsTriggered = old.freeSpinsTriggered + if (freeTriggered) 1 else 0,
            jackpots = old.jackpots + if (jackpot) 1 else 0
        )
        store.put("p_spins" to p.totalSpins, "p_wins" to p.totalWins, "p_wager" to p.totalWagered,
            "p_earned" to p.totalEarned, "p_best" to p.biggestWin, "p_bigs" to p.bigWins,
            "p_free" to p.freeSpinsTriggered, "p_jp" to p.jackpots)
        _state.value = p
        val msgs = ArrayList<String>()
        if (p.level > old.level) {
            val reward = 10_000L * p.level
            wallet.credit(reward, "LEVEL_UP", "Reached player level ${p.level}")
            msgs.add("⬆️ Level ${p.level}! +$reward coins")
        }
        if (p.vip.idx > old.vip.idx) msgs.add("${p.vip.badge} VIP ${p.vip.name} unlocked! Claim your reward in Rewards")
        return msgs
    }
}
