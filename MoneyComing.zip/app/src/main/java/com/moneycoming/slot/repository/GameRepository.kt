package com.moneycoming.slot.repository

import android.content.Context
import androidx.room.Room
import com.moneycoming.slot.database.AppDatabase
import com.moneycoming.slot.database.SpinRecord
import com.moneycoming.slot.game.Bonus
import com.moneycoming.slot.game.GameConfig
import com.moneycoming.slot.game.Sym
import com.moneycoming.slot.game.SlotEngine
import com.moneycoming.slot.game.SpinResult
import com.moneycoming.slot.game.WinTier
import com.moneycoming.slot.profile.ProfileManager
import com.moneycoming.slot.rewards.RewardEngine
import com.moneycoming.slot.security.SecureStore
import com.moneycoming.slot.sound.SoundFx
import com.moneycoming.slot.util.fmt
import com.moneycoming.slot.wallet.WalletEngine
import java.security.SecureRandom

data class SpinCommit(
    val balanceAfter: Long, val tier: WinTier, val messages: List<String>,
    val extraBonuses: List<Bonus> = emptyList(), val ssCollected: Int = 0, val ssTokens: Int = 0
)

/** Single entry point that ties the wallet, game engine, profile, rewards and history together. */
class GameRepository(ctx: Context) {
    val store = SecureStore(ctx)
    val db: AppDatabase = Room.databaseBuilder(ctx, AppDatabase::class.java, "moneycoming.db")
        .fallbackToDestructiveMigration().build()
    val wallet = WalletEngine(store, db.txDao())
    val profile = ProfileManager(store, wallet)
    val rewards = RewardEngine(store, wallet, profile)
    val settings = SettingsManager(store)
    val sound = SoundFx(ctx, settings)
    /** Gameplay RNG: cryptographically secure. */
    val engine = SlotEngine(SecureRandom())

    suspend fun commitSpin(game: String, bet: Long, r: SpinResult, free: Boolean): SpinCommit? {
        val stake = if (free) 0L else bet
        val note = "$game • bet ${bet.fmt()} • win ${r.totalWin.fmt()}"
        val after = wallet.settleSpin(stake, r.totalWin, free, note)
        if (after < 0) return null
        val tier = engine.tier(r.totalWin, bet, r.jackpot)
        db.spinDao().insert(
            SpinRecord(
                game = game, time = System.currentTimeMillis(), bet = bet, win = r.totalWin,
                multiplier = if (bet > 0) r.totalWin.toDouble() / bet else 0.0,
                result = describe(r, free, tier), balanceAfter = after, free = free
            )
        )
        db.spinDao().prune()
        val msgs = profile.onSpin(stake, r.totalWin, tier, r.freeSpins != null, r.jackpot)
        rewards.onSpin(stake, r.totalWin, tier)

        // SUPER SCATTER meter: collect scatters, pay a Super Wheel every SUPER_THRESHOLD and earn a respin token.
        val extra = ArrayList<Bonus>()
        var col = store.int("ss_col") + (r.counts[Sym.SCATTER] ?: 0)
        var tok = store.int("ss_tok")
        while (col >= GameConfig.SUPER_THRESHOLD) {
            col -= GameConfig.SUPER_THRESHOLD
            tok += 1
            val w = engine.superWheel(bet)
            wallet.credit(w.prize, "SUPER_SCATTER", "Super Scatter wheel • $game")
            extra.add(w)
        }
        store.put("ss_col" to col, "ss_tok" to tok)
        return SpinCommit(wallet.balance.value, tier, msgs, extra, col, tok)
    }

    private fun describe(r: SpinResult, free: Boolean, tier: WinTier): String {
        val parts = ArrayList<String>()
        if (free) parts.add("Free spin")
        if (r.lineWins.isNotEmpty()) parts.add("${r.lineWins.size} line win(s)")
        r.bonuses.forEach {
            parts.add(when (it) { is Bonus.Wheel -> if (it.premium) "Jackpot wheel" else "Bonus wheel"; is Bonus.Pick -> "Pick & Win"; is Bonus.Mystery -> "Mystery reward" })
        }
        if (r.freeSpins != null) parts.add("Free spins x${r.freeSpins.spins}")
        if (r.spinMult > 1) parts.add("x${r.spinMult} multiplier")
        if (parts.isEmpty() || (parts.size == 1 && free)) parts.add(if (r.totalWin > 0) tier.label else "No win")
        return parts.joinToString(" • ")
    }

    fun ssCollected() = store.int("ss_col")
    fun ssTokens() = store.int("ss_tok")

    /** Spends one respin token on a wheel; the extra coins (if the respin is higher) are credited at once. */
    suspend fun useRespin(w: Bonus.Wheel): Boolean {
        val tok = store.int("ss_tok")
        if (tok <= 0) return false
        store.put("ss_tok" to tok - 1)
        val extra = w.respinPrize - w.prize
        if (extra > 0) wallet.credit(extra, "WHEEL_RESPIN", "Wheel respin bonus")
        return true
    }

    suspend fun resetEverything() {
        db.spinDao().clear()
        wallet.reset()
        rewards.resetAll()
        store.put("balance" to GameConfig.START_BALANCE)
    }
}
