package com.moneycoming.slot.repository

import android.content.Context
import androidx.room.Room
import com.moneycoming.slot.database.AppDatabase
import com.moneycoming.slot.database.SpinRecord
import com.moneycoming.slot.game.Bonus
import com.moneycoming.slot.game.SlotEngine
import com.moneycoming.slot.game.SpinResult
import com.moneycoming.slot.game.WinTier
import com.moneycoming.slot.profile.ProfileManager
import com.moneycoming.slot.rewards.RewardEngine
import com.moneycoming.slot.security.SecureStore
import com.moneycoming.slot.sound.SoundFx
import com.moneycoming.slot.util.fmt
import com.moneycoming.slot.wallet.WalletEngine
import java.security.SecureRandom

data class SpinCommit(val balanceAfter: Long, val tier: WinTier, val messages: List<String>)

/** Single entry point that ties the wallet, game engine, profile, rewards and history together. */
class GameRepository(ctx: Context) {
    val store = SecureStore(ctx)
    val db: AppDatabase = Room.databaseBuilder(ctx, AppDatabase::class.java, "moneycoming.db")
        .fallbackToDestructiveMigration().build()
    val wallet = WalletEngine(store, db.txDao())
    val profile = ProfileManager(store, wallet)
    val rewards = RewardEngine(store, wallet, profile)
    val settings = SettingsManager(store)
    val sound = SoundFx(ctx, settings)
    /** Gameplay RNG: cryptographically secure. */
    val engine = SlotEngine(SecureRandom())

    suspend fun commitSpin(game: String, bet: Long, r: SpinResult, free: Boolean): SpinCommit? {
        val stake = if (free) 0L else bet
        val note = "$game • bet ${bet.fmt()} • win ${r.totalWin.fmt()}"
        val after = wallet.settleSpin(stake, r.totalWin, free, note)
        if (after < 0) return null
        val tier = engine.tier(r.totalWin, bet, r.jackpot)
        db.spinDao().insert(
            SpinRecord(
                game = game, time = System.currentTimeMillis(), bet = bet, win = r.totalWin,
                multiplier = if (bet > 0) r.totalWin.toDouble() / bet else 0.0,
                result = describe(r, free, tier), balanceAfter = after, free = free
            )
        )
        db.spinDao().prune()
        val msgs = profile.onSpin(stake, r.totalWin, tier, r.freeSpins != null, r.jackpot)
        rewards.onSpin(stake, r.totalWin, tier)
        return SpinCommit(wallet.balance.value, tier, msgs)
    }

    private fun describe(r: SpinResult, free: Boolean, tier: WinTier): String {
        val parts = ArrayList<String>()
        if (free) parts.add("Free spin")
        if (r.lineWins.isNotEmpty()) parts.add("${r.lineWins.size} line win(s)")
        r.bonuses.forEach {
            parts.add(when (it) { is Bonus.Wheel -> if (it.premium) "Jackpot wheel" else "Bonus wheel"; is Bonus.Pick -> "Pick & Win"; is Bonus.Mystery -> "Mystery reward" })
        }
        if (r.freeSpins != null) parts.add("Free spins x${r.freeSpins.spins}")
        if (r.spinMult > 1) parts.add("x${r.spinMult} multiplier")
        if (parts.isEmpty() || (parts.size == 1 && free)) parts.add(if (r.totalWin > 0) tier.label else "No win")
        return parts.joinToString(" • ")
    }

    suspend fun resetEverything() {
        db.spinDao().clear()
        wallet.reset()
        rewards.resetAll()
        store.put("balance" to com.moneycoming.slot.game.GameConfig.START_BALANCE)
    }
}
