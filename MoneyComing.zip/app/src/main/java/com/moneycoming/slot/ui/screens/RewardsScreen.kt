package com.moneycoming.slot.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.moneycoming.slot.profile.Vip
import com.moneycoming.slot.rewards.RewardEngine
import com.moneycoming.slot.ui.components.BalancePill
import com.moneycoming.slot.ui.components.GlassCard
import com.moneycoming.slot.ui.components.GoldButton
import com.moneycoming.slot.ui.components.SectionTitle
import com.moneycoming.slot.ui.theme.*
import com.moneycoming.slot.util.compact
import com.moneycoming.slot.util.fmt
import com.moneycoming.slot.viewmodel.MainViewModel

@Composable
fun RewardsScreen(vm: MainViewModel) {
    val rw by vm.rewards.collectAsState()
    val balance by vm.balance.collectAsState()
    LaunchedEffect(Unit) { vm.refreshRewards() }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🎁 Rewards Center", color = Gold, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, modifier = Modifier.weight(1f))
            BalancePill(balance)
        }

        if (rw.welcome) ActionCard("🎁 Welcome Reward", "One-time gift: +${RewardEngine.WELCOME.fmt()} coins", "CLAIM") { vm.claimWelcome() }

        // 7-day login streak
        GlassCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("📅 Daily Login Bonus • 7-day streak", color = Color.White, fontWeight = FontWeight.ExtraBold)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (d in 1..7) {
                        val claimed = if (rw.canDaily) d < rw.nextDay else d <= rw.streak
                        val current = rw.canDaily && d == rw.nextDay
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                                .background(if (claimed) Good.copy(alpha = 0.25f) else if (current) Gold.copy(alpha = 0.25f) else Color(0x22FFFFFF))
                                .border(1.dp, if (current) Gold else if (claimed) Good else Color.Transparent, RoundedCornerShape(10.dp)).padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("D$d", color = TextDim, fontSize = 10.sp)
                            Text(if (claimed) "✅" else if (d == 7) "🎁" else "🪙", fontSize = 16.sp)
                            Text(RewardEngine.DAILY[d - 1].compact(), color = Color.White, fontSize = 9.sp, maxLines = 1)
                        }
                    }
                }
                if (rw.canDaily) GoldButton("CLAIM DAY ${rw.nextDay}: +${rw.dailyAmount.fmt()}", { vm.claimDaily() }, Modifier.fillMaxWidth())
                else Text("✅ Claimed today — come back tomorrow! Streak: ${rw.streak} day(s)", color = Good, fontSize = 13.sp)
                Text("Miss a day and the streak restarts. VIP levels add up to +30% to this bonus.", color = TextDim, fontSize = 11.sp)
            }
        }

        ActionCard("🎡 Daily Spin", if (rw.canSpin) "Spin the reward wheel — up to 10,00,000 coins!" else "Already spun today", if (rw.canSpin) "SPIN" else null) { vm.startDailySpin() }
        ActionCard("🔥 Event Bonus", "Today's event reward: +${rw.eventReward.fmt()} coins" + if (rw.eventReward > 25_000) "  (Weekend special!)" else "", if (rw.canEvent) "CLAIM" else null) { vm.claimEvent() }
        if (rw.canRefill) ActionCard("🪙 Free Coins", "Your balance is low — get +${RewardEngine.REFILL.fmt()} free coins", "CLAIM") { vm.claimRefill() }
        if (rw.vipClaimable.isNotEmpty()) {
            val tot = rw.vipClaimable.sumOf { Vip.LEVELS[it].reward }
            ActionCard("👑 VIP Reward", "Level-up gift: +${tot.fmt()} coins", "CLAIM") { vm.claimVip() }
        }

        SectionTitle("🎯 Daily Missions")
        rw.missions.filter { !it.weekly }.forEach { m ->
            MissionRow(m.title, m.progress, m.target, m.reward, m.claimed) { vm.claimMission(m.id) }
        }
        SectionTitle("📆 Weekly Missions")
        rw.missions.filter { it.weekly }.forEach { m ->
            MissionRow(m.title, m.progress, m.target, m.reward, m.claimed) { vm.claimMission(m.id) }
        }
        SectionTitle("🏆 Achievements")
        rw.achievements.forEach { a ->
            GlassCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (a.claimed) "✅" else if (a.unlocked) "🏆" else "🔒", fontSize = 24.sp)
                    Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                        Text(a.title, color = Color.White, fontWeight = FontWeight.Bold)
                        Text("${a.desc} • +${a.reward.compact()}", color = TextDim, fontSize = 11.sp)
                    }
                    if (a.unlocked && !a.claimed) GoldButton("CLAIM", { vm.claimAchievement(a.id) }, height = 34.dp, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ActionCard(title: String, sub: String, button: String?, onClick: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                Text(sub, color = TextDim, fontSize = 12.sp)
            }
            if (button != null) GoldButton(button, onClick, height = 38.dp, fontSize = 13.sp)
            else Text("✅", fontSize = 22.sp)
        }
    }
}

@Composable
private fun MissionRow(title: String, progress: Long, target: Long, reward: Long, claimed: Boolean, onClaim: () -> Unit) {
    val done = progress >= target
    GlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Reward: +${reward.fmt()} coins", color = Gold, fontSize = 11.sp)
                }
                when {
                    claimed -> Text("✅", fontSize = 22.sp)
                    done -> GoldButton("CLAIM", onClaim, height = 34.dp, fontSize = 12.sp)
                    else -> Text("${minOf(progress, target).compact()}/${target.compact()}", color = TextDim, fontSize = 12.sp)
                }
            }
            LinearProgressIndicator(
                progress = { (progress.toFloat() / target).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)),
                color = if (done) Good else Gold, trackColor = Color(0x33FFFFFF)
            )
        }
    }
}
