package com.moneycoming.slot.rewards

import com.moneycoming.slot.game.WinTier
import com.moneycoming.slot.profile.Profile
import com.moneycoming.slot.profile.ProfileManager
import com.moneycoming.slot.profile.Vip
import com.moneycoming.slot.security.SecureStore
import com.moneycoming.slot.wallet.WalletEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.security.SecureRandom
import java.time.DayOfWeek
import java.time.LocalDate

data class Mission(val id: String, val title: String, val weekly: Boolean, val progress: Long, val target: Long, val reward: Long, val claimed: Boolean) {
    val done: Boolean get() = progress >= target
}

data class Achievement(val id: String, val title: String, val desc: String, val reward: Long, val unlocked: Boolean, val claimed: Boolean)

data class RewardState(
    val streak: Int, val nextDay: Int, val canDaily: Boolean, val dailyAmount: Long,
    val canSpin: Boolean, val canEvent: Boolean, val eventReward: Long, val welcome: Boolean,
    val canRefill: Boolean, val missions: List<Mission>, val achievements: List<Achievement>,
    val vipClaimable: List<Int>
)

class RewardEngine(private val store: SecureStore, private val wallet: WalletEngine, private val profile: ProfileManager) {
    companion object {
        val DAILY = longArrayOf(10_000, 20_000, 30_000, 50_000, 75_000, 100_000, 250_000)
        val SPIN_PRIZES = listOf(5_000L, 10_000L, 25_000L, 50_000L, 100_000L, 250_000L, 500_000L, 1_000_000L)
        private val SPIN_WEIGHTS = listOf(30, 25, 18, 12, 8, 4, 2, 1)
        const val WELCOME = 100_000L
        const val REFILL = 100_000L
        const val REFILL_BELOW = 1_000L
        private data class M(val id: String, val title: String, val weekly: Boolean, val target: Long, val reward: Long, val key: String)
        private val MISSIONS = listOf(
            M("d_spins", "Spin 20 times", false, 20, 20_000, "d_spins"),
            M("d_wins", "Win 5 spins", false, 5, 30_000, "d_wins"),
            M("d_wager", "Play 1,00,000 coins in total", false, 100_000, 25_000, "d_wager"),
            M("w_spins", "Spin 200 times this week", true, 200, 200_000, "w_spins"),
            M("w_wins", "Win 50 spins this week", true, 50, 250_000, "w_wins"),
            M("w_big", "Hit a BIG WIN this week", true, 1, 300_000, "w_big")
        )
        private data class A(val id: String, val title: String, val desc: String, val reward: Long, val test: (Profile, Int) -> Boolean)
        private val ACHS = listOf(
            A("first_spin", "First Spin", "Play your first spin", 5_000) { p, _ -> p.totalSpins >= 1 },
            A("spins_100", "Warming Up", "Play 100 spins", 50_000) { p, _ -> p.totalSpins >= 100 },
            A("spins_1000", "Slot Veteran", "Play 1,000 spins", 500_000) { p, _ -> p.totalSpins >= 1000 },
            A("first_big", "Big Moment", "Hit a Big Win or better", 25_000) { p, _ -> p.bigWins >= 1 },
            A("free_spins", "Free For All", "Trigger Free Spins", 50_000) { p, _ -> p.freeSpinsTriggered >= 1 },
            A("jackpot", "Jackpot!", "Hit a Jackpot", 500_000) { p, _ -> p.jackpots >= 1 },
            A("gold", "Going Gold", "Reach VIP Gold", 100_000) { p, _ -> p.vip.idx >= 2 },
            A("streak7", "Seven Days Strong", "Reach a 7-day login streak", 200_000) { _, s -> s >= 7 },
            A("earner", "Coin Magnet", "Earn 1 crore coins in total winnings", 250_000) { p, _ -> p.totalEarned >= 10_000_000 }
        )
    }

    private val rng = SecureRandom()
    private fun today() = LocalDate.now().toEpochDay()
    private fun week() = today() / 7

    private val _state = MutableStateFlow(compute())
    val state: StateFlow<RewardState> = _state
    fun refresh() { _state.value = compute() }

    private fun rollover() {
        if (store.long("mday", -1) != today()) {
            store.put("mday" to today(), "d_spins" to 0L, "d_wins" to 0L, "d_wager" to 0L,
                "claim_d_spins" to false, "claim_d_wins" to false, "claim_d_wager" to false)
        }
        if (store.long("mweek", -1) != week()) {
            store.put("mweek" to week(), "w_spins" to 0L, "w_wins" to 0L, "w_big" to 0L,
                "claim_w_spins" to false, "claim_w_wins" to false, "claim_w_big" to false)
        }
    }

    private fun currentStreak(): Int {
        val last = store.long("last_daily", -1)
        return if (last == today() || last == today() - 1) store.int("streak", 0) else 0
    }

    private fun isWeekend() = LocalDate.now().dayOfWeek.let { it == DayOfWeek.SATURDAY || it == DayOfWeek.SUNDAY }

    private fun compute(): RewardState {
        rollover()
        val p = profile.state.value
        val last = store.long("last_daily", -1)
        val streak = currentStreak()
        val canDaily = last != today()
        val next = if (!canDaily) streak else if (streak == 0) 1 else streak % 7 + 1
        val base = DAILY[(if (canDaily) next else streak.coerceAtLeast(1)) - 1]
        val amount = base * (100 + Vip.dailyBonusPercent(p.vip.idx)) / 100
        val missions = MISSIONS.map { Mission(it.id, it.title, it.weekly, store.long(it.key), it.target, it.reward, store.bool("claim_${it.key}")) }
        val achs = ACHS.map { Achievement(it.id, it.title, it.desc, it.reward, it.test(p, store.int("best_streak", streak)), store.bool("ach_${it.id}")) }
        val claimedVip = store.int("vip_claimed", -1)
        return RewardState(
            streak, next, canDaily, amount,
            store.long("last_spin", -1) != today(),
            store.long("last_event", -1) != today(), if (isWeekend()) 100_000L else 25_000L,
            !store.bool("welcome_claimed"),
            wallet.balance.value < REFILL_BELOW, missions, achs,
            ((claimedVip + 1)..p.vip.idx).toList()
        )
    }

    /** Called after every spin to advance missions. */
    fun onSpin(wager: Long, win: Long, tier: WinTier) {
        rollover()
        store.put(
            "d_spins" to store.long("d_spins") + 1, "w_spins" to store.long("w_spins") + 1,
            "d_wager" to store.long("d_wager") + wager
        )
        if (win > 0) store.put("d_wins" to store.long("d_wins") + 1, "w_wins" to store.long("w_wins") + 1)
        if (tier >= WinTier.BIG) store.put("w_big" to store.long("w_big") + 1)
        refresh()
    }

    /** Each claim returns the coins credited (0 when it was not claimable). */
    suspend fun claimDaily(): Long {
        val s = compute()
        if (!s.canDaily) return 0
        val best = maxOf(store.int("best_streak", 0), s.nextDay)
        store.put("last_daily" to today(), "streak" to s.nextDay, "best_streak" to best)
        wallet.credit(s.dailyAmount, "DAILY_BONUS", "Day ${s.nextDay} login streak reward")
        refresh(); return s.dailyAmount
    }

    /** Daily spin wheel: returns the index of the prize (already credited), or -1. */
    suspend fun claimDailySpin(): Int {
        if (store.long("last_spin", -1) == today()) return -1
        var r = rng.nextInt(SPIN_WEIGHTS.sum()); var idx = 0
        for (i in SPIN_WEIGHTS.indices) { r -= SPIN_WEIGHTS[i]; if (r < 0) { idx = i; break } }
        store.put("last_spin" to today())
        wallet.credit(SPIN_PRIZES[idx], "DAILY_SPIN", "Daily spin reward")
        refresh(); return idx
    }

    suspend fun claimEvent(): Long {
        if (store.long("last_event", -1) == today()) return 0
        val amt = if (isWeekend()) 100_000L else 25_000L
        store.put("last_event" to today())
        wallet.credit(amt, "EVENT", if (isWeekend()) "Weekend Jackpot Fever event" else "Lucky Hour event")
        refresh(); return amt
    }

    suspend fun claimWelcome(): Long {
        if (store.bool("welcome_claimed")) return 0
        store.put("welcome_claimed" to true)
        wallet.credit(WELCOME, "WELCOME", "Welcome reward"); refresh(); return WELCOME
    }

    suspend fun claimRefill(): Long {
        if (wallet.balance.value >= REFILL_BELOW) return 0
        wallet.credit(REFILL, "FREE_COINS", "Free coins refill"); refresh(); return REFILL
    }

    suspend fun claimMission(id: String): Long {
        val m = compute().missions.firstOrNull { it.id == id } ?: return 0
        if (!m.done || m.claimed) return 0
        store.put("claim_$id" to true)
        wallet.credit(m.reward, "MISSION", m.title); refresh(); return m.reward
    }

    suspend fun claimAchievement(id: String): Long {
        val a = compute().achievements.firstOrNull { it.id == id } ?: return 0
        if (!a.unlocked || a.claimed) return 0
        store.put("ach_$id" to true)
        wallet.credit(a.reward, "ACHIEVEMENT", a.title); refresh(); return a.reward
    }

    suspend fun claimVip(): Long {
        val s = compute()
        if (s.vipClaimable.isEmpty()) return 0
        val total = s.vipClaimable.sumOf { Vip.LEVELS[it].reward }
        store.put("vip_claimed" to s.vipClaimable.last())
        wallet.credit(total, "VIP_REWARD", "VIP reward"); refresh(); return total
    }

    fun notifications(): List<String> {
        val s = _state.value
        val out = ArrayList<String>()
        if (s.welcome) out.add("🎁 Your welcome reward of ${WELCOME} coins is waiting")
        if (s.canDaily) out.add("📅 Daily login bonus is ready (day ${s.nextDay})")
        if (s.canSpin) out.add("🎡 Free daily spin available")
        if (s.canEvent) out.add("🔥 Today's event bonus is ready")
        if (s.vipClaimable.isNotEmpty()) out.add("👑 VIP reward ready to claim")
        val m = s.missions.count { it.done && !it.claimed }
        if (m > 0) out.add("🎯 $m mission reward(s) ready")
        val a = s.achievements.count { it.unlocked && !it.claimed }
        if (a > 0) out.add("🏆 $a achievement reward(s) ready")
        if (out.isEmpty()) out.add("✅ You're all caught up. New rewards unlock tomorrow!")
        return out
    }

    fun resetAll() { store.clear(); profile.reload(); refresh() }
}
