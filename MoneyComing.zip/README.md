# 💰 Money Coming – Premium Slot Casino Game (Android)

A complete offline slot game for Android written in **Kotlin + Jetpack Compose**.
Everything uses **virtual coins only** – no deposits, withdrawals, cash prizes or conversion to money.
All results are simulated with `java.security.SecureRandom` and are labelled as simulated in the app.

## Quick start: get the APK from GitHub Releases (no PC needed)

1. Create a new GitHub repository.
2. Upload the **contents** of this project (this folder: `app/`, `.github/`, `build.gradle.kts`, ...) to the repo root
   (GitHub website → *Add file → Upload files*; make sure the hidden `.github` folder is included - if your phone
   file manager hides it, upload the zip with a GitHub app/desktop site, or create `.github/workflows/android-build.yml` by hand and paste the file).
3. Commit to the `main` branch. The workflow **Android Build & Release** starts automatically (tab *Actions*).
4. After ~5-10 minutes open **Releases** (right side of the repo). The release contains:
   * `MoneyComing-v1.0.N-release.apk`  ← install this one
   * `MoneyComing-v1.0.N-debug.apk`
5. Open the release page on your phone, download the release APK and install it.

The APK is also available as workflow artifact (*Actions → run → MoneyComing-APKs*).
If a build fails, download the `build-reports` artifact and send me the log.

### Optional: sign with your own key (so updates install over old versions)
Without secrets, each build is signed with a temporary key (fine for installing, but a new build
cannot be installed *over* an older one - uninstall first). To keep one key, add these repository secrets
(*Settings → Secrets and variables → Actions*):

| Secret | Value |
|---|---|
| `KEYSTORE_BASE64` | `base64 -w0 my-release.jks` |
| `KEYSTORE_PASSWORD` | keystore password |
| `KEY_ALIAS` | key alias |
| `KEY_PASSWORD` | key password |

## Features
* 5 reels × 3 rows, **20 paylines**, animated sliding reels, near-miss message, auto spin (10/25/50/100), max bet.
* Symbols: Wild (expands on reel 3, sticky in free spins, x2 line), Scatter (3/4/5 → Bonus Wheel / Pick & Win / Premium Jackpot Wheel),
  Bonus (Mystery reward), Free Spins (8/12/20 spins at x2/x3/x5), Multiplier (+1x per symbol), Jackpot symbol.
* **Money Coming Wheel**: big casino prize wheel with coin amounts; **SUPER SCATTER** meter (collect 20 scatters → Super Wheel + 1 **Wheel Respin** token; respin keeps the higher result).
* Win tiers: Small, Normal, Big, Mega, Super, Jackpot with count-up amount, coin shower and confetti.
* Wallet: starts with **1 crore** coins, bets 100 … 1,00,000, live balance, validation, insufficient-balance warning,
  configurable maximum balance, transaction history.
* Rewards Center: welcome reward, 7-day login streak, daily spin wheel, event bonus, free-coins refill, daily & weekly missions,
  achievements, level-up rewards, VIP rewards.
* VIP: Bronze, Silver, Gold, Platinum, Diamond, Elite with badges, themes, progress bar and perks.
* Profile (username/avatar/stats), full history (games, wins, wallet) stored in a **Room** database.
* Sounds are synthesised in code (SoundPool), sound/animation/particle settings, quick spin.
* Settings → **Fairness check** simulates 1,00,000 rounds on the device and prints the real RTP (about 95%).
* Every probability and payout is in `game/GameConfig.kt` and shown in the in-game INFO/paytable.

## Tech / architecture
Kotlin, Jetpack Compose (Material 3, custom premium styling), Navigation Compose, Room, Coroutines/Flow, ViewModel (MVVM),
EncryptedSharedPreferences (AES-256) for wallet/profile/settings, SoundPool.

```
app/src/main/java/com/moneycoming/slot/
  game/        SlotEngine, GameConfig, Symbols, Machines   (game engine)
  wallet/      WalletEngine                                  (wallet engine)
  rewards/     RewardEngine                                  (reward engine)
  profile/     Profile, VIP levels
  database/    Room entities + DAOs
  repository/  GameRepository, Settings
  security/    SecureStore (encrypted prefs)
  sound/       SoundFx
  viewmodel/   MainViewModel, SlotViewModel
  ui/          theme, components (reels, wheel, particles), screens, navigation
```

## Build locally
Open the folder in Android Studio (Koala or newer, JDK 17) and press Run, or with Gradle 8.9+ installed:
`gradle assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
* minSdk 26 (Android 8.0), target/compile SDK 35 (Android 15).
* No internet permission and no other permissions are requested. Works fully offline.
* This is an entertainment simulation with virtual coins. It must not be used for real-money gambling.
