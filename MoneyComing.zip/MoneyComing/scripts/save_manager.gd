extends Node
# Versioned, checksummed local save (autoload: SaveManager)

const SAVE_PATH := "user://money_coming_save.dat"
const BACKUP_PATH := "user://money_coming_save.bak"
const SAVE_VERSION := 1
const SALT := "mc_v1_local_salt"

var data: Dictionary = {}


func _init() -> void:
    data = defaults()


func _ready() -> void:
    load_game()


func defaults() -> Dictionary:
    return {
        "version": SAVE_VERSION,
        "balance": 10000000,
        "bet": 100,
        "total_bets": 0,
        "total_wins": 0,
        "win_count": 0,
        "highest_win": 0,
        "total_spins": 0,
        "settings": {
            "sound": true,
            "music": true,
            "vibration": true,
            "anim_quality": 2,
            "gfx_quality": 1,
            "fast": false,
            "auto_count": 10,
            "language": "en",
        },
        "profile": {"name": "Player", "xp": 0, "level": 1, "avatar": 0},
        "history": [],
        "wallet_history": [],
        "daily": {"last_day": -1, "streak": 0},
        "missions": {},
        "achievements": {},
        "state": {"scatter": 0, "super": 0, "free_spins": 0, "free_total": 0},
    }


func _read_file(path: String):
    if not FileAccess.file_exists(path):
        return null
    var f := FileAccess.open(path, FileAccess.READ)
    if f == null:
        return null
    var txt: String = f.get_as_text()
    f.close()
    var outer = JSON.parse_string(txt)
    if not (outer is Dictionary):
        return null
    if not outer.has("payload") or not outer.has("sig"):
        return null
    var payload: String = str(outer["payload"])
    if (payload + SALT).sha256_text() != str(outer["sig"]):
        return null
    var inner = JSON.parse_string(payload)
    if inner is Dictionary:
        return inner
    return null


func _merge(base: Dictionary, over: Dictionary) -> void:
    for k in over.keys():
        if base.has(k) and base[k] is Dictionary and over[k] is Dictionary:
            _merge(base[k], over[k])
        else:
            base[k] = over[k]


func load_game() -> void:
    data = defaults()
    var loaded = _read_file(SAVE_PATH)
    if loaded == null:
        loaded = _read_file(BACKUP_PATH)
    if loaded is Dictionary:
        _merge(data, loaded)
    _normalize()


func _normalize() -> void:
    for k in ["balance", "bet", "total_bets", "total_wins", "win_count", "highest_win", "total_spins"]:
        data[k] = int(data[k])
    if int(data["balance"]) < 0:
        data["balance"] = 0
    var st: Dictionary = data["state"]
    for k in ["scatter", "super", "free_spins", "free_total"]:
        st[k] = int(st[k])
    var s: Dictionary = data["settings"]
    s["anim_quality"] = int(s["anim_quality"])
    s["gfx_quality"] = int(s["gfx_quality"])
    s["auto_count"] = int(s["auto_count"])
    var p: Dictionary = data["profile"]
    p["xp"] = int(p["xp"])
    p["level"] = maxi(1, int(p["level"]))
    var d: Dictionary = data["daily"]
    d["last_day"] = int(d["last_day"])
    d["streak"] = int(d["streak"])


func save_game() -> void:
    data["version"] = SAVE_VERSION
    var payload: String = JSON.stringify(data)
    var wrap: Dictionary = {"payload": payload, "sig": (payload + SALT).sha256_text()}
    var txt: String = JSON.stringify(wrap)
    if FileAccess.file_exists(SAVE_PATH):
        DirAccess.copy_absolute(ProjectSettings.globalize_path(SAVE_PATH), ProjectSettings.globalize_path(BACKUP_PATH))
    var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if f != null:
        f.store_string(txt)
        f.close()


func reset_all() -> void:
    data = defaults()
    save_game()


func get_setting(key: String):
    return data["settings"][key]


func set_setting(key: String, value) -> void:
    data["settings"][key] = value
    save_game()


func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
        save_game()
