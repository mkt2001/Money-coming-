extends Control
# Fortune Wheel: 8 segments, real rotation, labels always come from the scaled reward list.
const UI = preload("res://scripts/ui.gd")

signal spin_finished

const SEG: int = 8
const RED_INDEX: int = 2
const R_SEG: float = 214.0
const R_RIM: float = 236.0
const R_OUT: float = 248.0

var values: Array = []
var rot: float = 0.0
var highlight_idx: int = -1
var spinning: bool = false
var center_pt: Vector2 = Vector2(270, 270)
var _tween: Tween
var _blink: float = 0.0
var _last_phase: int = -1
var _last_idx: int = -1
var _pulse: float = 0.0


func _ready() -> void:
    size = Vector2(540, 540)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    set_process(true)


func set_values(v: Array) -> void:
    values = v.duplicate()
    queue_redraw()


func highlight(idx: int) -> void:
    highlight_idx = idx
    queue_redraw()


func clear_highlight() -> void:
    highlight_idx = -1
    queue_redraw()


func _process(delta: float) -> void:
    _blink += delta
    var phase: int = int(_blink * 3.0) % 2
    if highlight_idx >= 0:
        _pulse += delta
    if phase != _last_phase or spinning or highlight_idx >= 0:
        _last_phase = phase
        queue_redraw()


func _idx_under_pointer() -> int:
    var seg: float = TAU / float(SEG)
    return int(round(fposmod(-rot, TAU) / seg)) % SEG


func _set_rot(v: float) -> void:
    rot = v
    var idx: int = _idx_under_pointer()
    if idx != _last_idx:
        _last_idx = idx
        SoundManager.play("tick")
    queue_redraw()


func spin_to(index: int, duration: float) -> void:
    spinning = true
    highlight_idx = -1
    var seg: float = TAU / float(SEG)
    var desired: float = -float(index) * seg + randf_range(-0.3, 0.3) * seg
    var cur: float = fposmod(rot, TAU)
    var delta: float = fposmod(desired - cur, TAU) + TAU * float(4 + randi() % 3)
    var target: float = rot + delta
    if _tween != null:
        _tween.kill()
    _tween = create_tween()
    _tween.tween_method(_set_rot, rot, target, duration).set_trans(Tween.TRANS_QUART).set_ease(Tween.EASE_OUT)
    await _tween.finished
    spinning = false
    rot = fposmod(target, TAU)
    queue_redraw()
    spin_finished.emit()


func _seg_color(i: int) -> Color:
    if i == RED_INDEX:
        return Color("c8201a")
    if i % 2 == 0:
        return Color("2e9e2a")
    return Color("f5d742")


func _draw() -> void:
    var c: Vector2 = center_pt
    var font: Font = get_theme_default_font()
    draw_circle(c, R_OUT, Color("6e4208"))
    draw_circle(c, R_OUT - 4.0, Color("f2c230"))
    draw_circle(c, R_RIM, Color("b57a12"))
    draw_circle(c, R_SEG + 6.0, Color("ffe27a"))
    var seg: float = TAU / float(SEG)
    for i in SEG:
        var a0: float = rot + float(i) * seg - PI / 2.0 - seg / 2.0
        var pts := PackedVector2Array([c])
        var steps: int = 14
        for s in steps + 1:
            var a: float = a0 + seg * float(s) / float(steps)
            pts.append(c + Vector2.from_angle(a) * R_SEG)
        draw_colored_polygon(pts, _seg_color(i))
        if i == highlight_idx:
            var al: float = 0.35 + 0.35 * sin(_pulse * 10.0)
            draw_colored_polygon(pts, Color(1, 1, 1, al))
        draw_line(c, c + Vector2.from_angle(a0) * R_SEG, Color("c8921a"), 3.0)
    draw_circle(c, 90.0, Color(1, 1, 1, 0.07))
    # labels (always the scaled values)
    for i in SEG:
        if i >= values.size():
            continue
        var txt: String = UI.fmt(int(values[i]))
        var fs: int = 38
        if txt.length() > 5:
            fs = 30
        if txt.length() > 7:
            fs = 24
        if txt.length() > 9:
            fs = 19
        var ang: float = rot + float(i) * seg - PI / 2.0
        var col: Color = Color("fff3b0")
        var oc: Color = Color(0.05, 0.25, 0.05)
        if i == RED_INDEX:
            oc = Color(0.3, 0.02, 0.02)
        elif i % 2 == 1:
            col = Color("6b2300")
            oc = Color(1.0, 0.95, 0.6)
        draw_set_transform(c, ang + PI, Vector2.ONE)
        var tp: Vector2 = Vector2(-(R_SEG - 14.0), float(fs) * 0.35)
        draw_string_outline(font, tp, txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, 5, oc)
        draw_string(font, tp, txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, col)
        draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
    # rim lights
    var phase: int = int(_blink * 3.0) % 2
    for k in 24:
        var a: float = float(k) * TAU / 24.0
        var lit: bool = (k + phase) % 2 == 0
        var lc: Color = Color("fff6c0") if lit else Color("c47a10")
        draw_circle(c + Vector2.from_angle(a) * (R_RIM - 7.0), 5.0, lc)
    # center hub
    draw_circle(c, 62.0, Color("7a4a08"))
    draw_circle(c, 56.0, Color("f2c230"))
    draw_circle(c, 46.0, Color("b57a12"))
    draw_string_outline(font, Vector2(c.x - 50.0, c.y + 26.0), "$", HORIZONTAL_ALIGNMENT_CENTER, 100.0, 76, 6, Color("fff0a0"))
    draw_string(font, Vector2(c.x - 50.0, c.y + 26.0), "$", HORIZONTAL_ALIGNMENT_CENTER, 100.0, 76, Color("7a4a08"))
    # fixed pointer
    var pp := PackedVector2Array([Vector2(c.x - 32.0, 4.0), Vector2(c.x + 32.0, 4.0), Vector2(c.x, 80.0)])
    draw_colored_polygon(pp, Color("f2c230"))
    var pi2 := PackedVector2Array([Vector2(c.x - 22.0, 12.0), Vector2(c.x + 22.0, 12.0), Vector2(c.x, 64.0)])
    draw_colored_polygon(pi2, Color("1fb034"))
    draw_string(font, Vector2(c.x - 20.0, 40.0), "$", HORIZONTAL_ALIGNMENT_CENTER, 40.0, 26, Color("fff0a0"))
