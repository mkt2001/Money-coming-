extends Control
# One vertical reel (digit reel or the special-symbol reel). Real scrolling animation.
const UI = preload("res://scripts/ui.gd")

signal stopped

const KIND_DIGIT: int = 0
const KIND_SPECIAL: int = 1

var kind: int = 0
var strip: Array = []
var pos: float = 0.0
var spinning: bool = false
var speed: float = 22.0
var win_pulse: bool = false
var _t: float = 0.0
var _tween: Tween


func setup(k: int) -> void:
    kind = k
    clip_contents = true
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    if kind == KIND_DIGIT:
        strip = [0, 7, 3, 10, 5, 9, 1, 6, 2, 8, 4]
    else:
        strip = [0, 5, 1, 3, 0, 4, 6, 2, 0, 7, 1, 8]
    set_process(false)
    queue_redraw()


func show_symbol(sym: int) -> void:
    var k: int = strip.find(sym)
    if k < 0:
        k = 0
    pos = float(k)
    queue_redraw()


func start_spin() -> void:
    if _tween != null:
        _tween.kill()
    win_pulse = false
    spinning = true
    set_process(true)


func set_win(on: bool) -> void:
    win_pulse = on
    set_process(spinning or win_pulse)
    queue_redraw()


func stop_at(sym: int) -> void:
    var n: int = strip.size()
    var k: int = strip.find(sym)
    if k < 0:
        k = 0
    spinning = false
    var b: int = int(ceil(pos)) + 2
    var tp: int = b + posmod(k - b, n)
    if _tween != null:
        _tween.kill()
    _tween = create_tween()
    _tween.tween_method(_set_pos, pos, float(tp), 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    _tween.finished.connect(_on_stop_done.bind(k))


func _set_pos(v: float) -> void:
    pos = v
    queue_redraw()


func _on_stop_done(k: int) -> void:
    pos = float(k)
    set_process(win_pulse)
    queue_redraw()
    stopped.emit()


func _process(delta: float) -> void:
    if spinning:
        pos = fposmod(pos + speed * delta, float(strip.size()))
        queue_redraw()
    elif win_pulse:
        _t += delta
        queue_redraw()


func _text(txt: String, c: Vector2, fs: int, col: Color, outline_col: Color, outline: int, w: float) -> void:
    var font: Font = get_theme_default_font()
    var y: float = c.y + float(fs) * 0.36
    draw_string(font, Vector2(3, y + 4), txt, HORIZONTAL_ALIGNMENT_CENTER, w, fs, Color(0, 0, 0, 0.45))
    if outline > 0:
        draw_string_outline(font, Vector2(0, y), txt, HORIZONTAL_ALIGNMENT_CENTER, w, fs, outline, outline_col)
    draw_string(font, Vector2(0, y), txt, HORIZONTAL_ALIGNMENT_CENTER, w, fs, col)


func _draw_bg(w: float, h: float) -> void:
    if kind == KIND_DIGIT:
        var d: Color = Color("0b4f19")
        var m: Color = Color("33c940")
        draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(w * 0.5, 0), Vector2(w * 0.5, h), Vector2(0, h)]), PackedColorArray([d, m, m, d]))
        draw_polygon(PackedVector2Array([Vector2(w * 0.5, 0), Vector2(w, 0), Vector2(w, h), Vector2(w * 0.5, h)]), PackedColorArray([m, d, d, m]))
    else:
        var a: Color = Color("f7d37a")
        var b: Color = Color("d38a2a")
        draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(w, 0), Vector2(w, h), Vector2(0, h)]), PackedColorArray([a, a, b, b]))


func _draw_symbol(sym: int, c: Vector2, w: float) -> void:
    if kind == KIND_DIGIT:
        var sc: float = minf(w / 146.0, 1.0)
        if sym == 10:
            var pts := PackedVector2Array()
            for k in 10:
                var r: float = (68.0 if k % 2 == 0 else 30.0) * sc
                var a: float = -PI / 2.0 + float(k) * PI / 5.0
                pts.append(c + Vector2(cos(a), sin(a)) * r)
            draw_colored_polygon(pts, UI.GOLD)
            pts.append(pts[0])
            draw_polyline(pts, Color("7a4a08"), 4.0)
            _text("WILD", c + Vector2(0, 6), int(34.0 * sc), Color("5a2a00"), UI.GOLD_LIGHT, 4, w)
        else:
            _text(str(sym), c, int(170.0 * sc), UI.GOLD, Color("5a3000"), int(9.0 * sc) + 1, w)
        return
    # special reel symbols
    if sym == 0:
        draw_circle(c, 46, UI.GOLD_DARK)
        draw_circle(c, 40, UI.GOLD)
        _text("$", c, 58, Color("7a4a08"), UI.GOLD_LIGHT, 0, w)
    elif sym == 1:
        draw_circle(c, 66, UI.GOLD_DARK)
        draw_circle(c, 60, UI.GOLD)
        draw_circle(c, 52, Color("1c9a2c"))
        draw_circle(c, 40, Color("39c24a"))
        _text("$", c + Vector2(0, -28), 34, UI.GOLD_LIGHT, Color("0c3a10"), 4, w)
        _text("SCATTER", c + Vector2(0, 14), 21, UI.GOLD_LIGHT, Color("0c3a10"), 5, w)
    elif sym == 2:
        draw_circle(c, 66, UI.GOLD_DARK)
        draw_circle(c, 60, UI.GOLD)
        draw_circle(c, 52, Color("b3201a"))
        draw_circle(c, 40, Color("e04030"))
        _text("SUPER", c + Vector2(0, -12), 26, UI.GOLD_LIGHT, Color("4a0a05"), 5, w)
        _text("SCATTER", c + Vector2(0, 18), 20, UI.GOLD_LIGHT, Color("4a0a05"), 5, w)
    elif sym == 3:
        draw_circle(c, 66, UI.GOLD_DARK)
        draw_circle(c, 60, UI.GOLD)
        draw_circle(c, 50, Color("1c9a2c"))
        draw_arc(c, 32, 0.0, TAU, 32, Color("f5d742"), 10.0)
        _text("WHEEL", c + Vector2(0, -2), 28, UI.GOLD_LIGHT, Color("0c3a10"), 5, w)
    elif sym == 4:
        draw_circle(c, 66, UI.GOLD_DARK)
        draw_circle(c, 60, Color("1f5fc4"))
        draw_circle(c, 50, Color("2f7ae5"))
        _text("ALL", c + Vector2(0, -10), 46, UI.GOLD_LIGHT, Color("0a2a66"), 6, w)
        _text("RESPIN", c + Vector2(0, 26), 22, UI.GOLD_LIGHT, Color("0a2a66"), 5, w)
    else:
        var label_txt: String = "2X"
        if sym == 6:
            label_txt = "3X"
        elif sym == 7:
            label_txt = "5X"
        elif sym == 8:
            label_txt = "10X"
        _text(label_txt, c, 84 if label_txt.length() < 3 else 70, UI.GOLD_LIGHT, Color("6a2a00"), 10, w)


func _draw() -> void:
    var w: float = size.x
    var h: float = size.y
    _draw_bg(w, h)
    var n: int = strip.size()
    if n == 0:
        return
    var base_i: int = int(floor(pos))
    var frac: float = pos - float(base_i)
    for i in range(-2, 3):
        var sym: int = int(strip[posmod(base_i + i, n)])
        var cy: float = h * 0.5 + (frac - float(i)) * h
        if cy < -h * 0.6 or cy > h + h * 0.6:
            continue
        _draw_symbol(sym, Vector2(w * 0.5, cy), w)
    # cylinder shading + gloss
    var dark: Color = Color(0, 0, 0, 0.5)
    var clear: Color = Color(0, 0, 0, 0.0)
    draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(w, 0), Vector2(w, h * 0.2), Vector2(0, h * 0.2)]), PackedColorArray([dark, dark, clear, clear]))
    draw_polygon(PackedVector2Array([Vector2(0, h * 0.8), Vector2(w, h * 0.8), Vector2(w, h), Vector2(0, h)]), PackedColorArray([clear, clear, dark, dark]))
    draw_rect(Rect2(w * 0.08, 0, w * 0.1, h), Color(1, 1, 1, 0.07))
    draw_rect(Rect2(0, 0, w, h), Color("5a3a08"), false, 3.0)
    if win_pulse:
        var a: float = 0.45 + 0.45 * sin(_t * 9.0)
        draw_rect(Rect2(3, 3, w - 6, h - 6), Color(1.0, 0.9, 0.3, a), false, 7.0)
