extends RefCounted
# Free spins + bonus helpers

const FREE_SPINS_AWARD: int = 5

var free_spins: int = 0
var free_total: int = 0


func load_state() -> void:
    var s: Dictionary = SaveManager.data["state"]
    free_spins = int(s["free_spins"])
    free_total = int(s["free_total"])


func save_state() -> void:
    var s: Dictionary = SaveManager.data["state"]
    s["free_spins"] = free_spins
    s["free_total"] = free_total


func add_free_spins(n: int) -> void:
    free_spins += n


func consume_free() -> void:
    if free_spins > 0:
        free_spins -= 1


func jackpot_prize(tier: String, bet: int) -> int:
    var jp: Dictionary = RewardScaling.jackpots_for(bet)
    return int(jp[tier])
