extends RefCounted
# Scatter + Super Scatter counters. COUNTS only; money values come from RewardScaling.

const NEEDED: int = 3

var count: int = 0
var super_count: int = 0


func load_state() -> void:
    var s: Dictionary = SaveManager.data["state"]
    count = int(s["scatter"])
    super_count = int(s["super"])


func save_state() -> void:
    var s: Dictionary = SaveManager.data["state"]
    s["scatter"] = count
    s["super"] = super_count


func add_scatter() -> bool:
    count += 1
    return count >= NEEDED


func add_super() -> bool:
    super_count += 1
    return super_count >= NEEDED


func reset_scatter() -> void:
    count = 0


func reset_super() -> void:
    super_count = 0
