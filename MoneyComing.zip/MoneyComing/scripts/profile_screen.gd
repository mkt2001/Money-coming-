extends Control
# Player profile: avatar, name, level, XP, statistics, achievements
const UI = preload("res://scripts/ui.gd")
const Lang = preload("res://scripts/lang.gd")

signal closed

var name_edit: LineEdit


func _ready() -> void:
    size = Vector2(720, 1280)
    var win: Panel = UI.window(self, Lang.t("profile"))
    var d: Dictionary = SaveManager.data
    var p: Dictionary = d["profile"]
    # avatar
    var av := Control.new()
    av.position = Vector2(40, 100)
    av.size = Vector2(120, 120)
    av.draw.connect(_draw_avatar.bind(av))
    win.add_child(av)
    name_edit = LineEdit.new()
    name_edit.text = str(p["name"])
    name_edit.position = Vector2(180, 110)
    name_edit.size = Vector2(440, 56)
    name_edit.max_length = 14
    name_edit.add_theme_font_size_override("font_size", 28)
    name_edit.text_submitted.connect(_on_name)
    name_edit.focus_exited.connect(_on_name_exit)
    win.add_child(name_edit)
    var lv: int = ProfileManager.level()
    win.add_child(UI.label("Level %d" % lv, Vector2(180, 172), Vector2(200, 44), 30, UI.GOLD, HORIZONTAL_ALIGNMENT_LEFT))
    var bar := ProgressBar.new()
    bar.position = Vector2(180, 222)
    bar.size = Vector2(440, 26)
    bar.min_value = 0
    bar.max_value = ProfileManager.xp_needed(lv)
    bar.value = ProfileManager.xp()
    bar.show_percentage = false
    win.add_child(bar)
    win.add_child(UI.label("XP %d / %d" % [ProfileManager.xp(), ProfileManager.xp_needed(lv)], Vector2(180, 250), Vector2(440, 30), 20, Color(1, 1, 1, 0.75), HORIZONTAL_ALIGNMENT_LEFT))
    var stats: Array = [
        ["Total spins", str(int(d["total_spins"]))],
        ["Total wins (count)", str(int(d["win_count"]))],
        ["Highest win", UI.fmt(int(d["highest_win"]))],
        ["Total bets", UI.fmt(int(d["total_bets"]))],
        ["Total winnings", UI.fmt(int(d["total_wins"]))],
    ]
    for i in stats.size():
        var y: float = 310.0 + float(i) * 52.0
        win.add_child(UI.label(str(stats[i][0]), Vector2(40, y), Vector2(300, 44), 26, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT))
        win.add_child(UI.label(str(stats[i][1]), Vector2(330, y), Vector2(300, 44), 26, UI.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_RIGHT))
    win.add_child(UI.label("ACHIEVEMENTS", Vector2(0, 590), Vector2(660, 50), 34, UI.GOLD, HORIZONTAL_ALIGNMENT_CENTER, 6))
    for i in ProfileManager.ACHIEVEMENTS.size():
        var a: Dictionary = ProfileManager.ACHIEVEMENTS[i]
        var got: bool = ProfileManager.has_achievement(str(a["id"]))
        var y2: float = 650.0 + float(i) * 64.0
        var col: Color = UI.GOLD_LIGHT if got else Color(1, 1, 1, 0.4)
        var mark: String = "[x] " if got else "[ ] "
        win.add_child(UI.label(mark + str(a["title"]), Vector2(40, y2), Vector2(420, 52), 26, col, HORIZONTAL_ALIGNMENT_LEFT))
        win.add_child(UI.label("+" + UI.fmt(int(a["reward"])), Vector2(400, y2), Vector2(230, 52), 24, col, HORIZONTAL_ALIGNMENT_RIGHT))
    var back: Button = UI.button(Lang.t("back"), Vector2(230, 1050), Vector2(200, 64), UI.RED, 28)
    back.pressed.connect(_close)
    win.add_child(back)


func _draw_avatar(av: Control) -> void:
    av.draw_circle(Vector2(60, 60), 58, UI.GOLD)
    av.draw_circle(Vector2(60, 60), 50, Color("1f9d2b"))
    var nm: String = str(SaveManager.data["profile"]["name"])
    var ch: String = nm.substr(0, 1).to_upper() if nm.length() > 0 else "P"
    av.draw_string(av.get_theme_default_font(), Vector2(0, 80), ch, HORIZONTAL_ALIGNMENT_CENTER, 120, 60, UI.GOLD_LIGHT)


func _on_name(t: String) -> void:
    _save_name(t)


func _on_name_exit() -> void:
    _save_name(name_edit.text)


func _save_name(t: String) -> void:
    var n: String = t.strip_edges()
    if n.length() == 0:
        n = "Player"
    SaveManager.data["profile"]["name"] = n
    SaveManager.save_game()


func _close() -> void:
    _save_name(name_edit.text)
    SoundManager.play("click")
    closed.emit()
    queue_free()
