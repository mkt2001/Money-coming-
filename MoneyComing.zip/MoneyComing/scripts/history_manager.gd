extends Node
# Spin history (autoload: HistoryManager)

const MAX_ENTRIES: int = 200


func add_entry(e: Dictionary) -> void:
    var arr: Array = SaveManager.data["history"]
    e["n"] = int(SaveManager.data["total_spins"])
    e["t"] = Time.get_datetime_string_from_system(false, true)
    arr.insert(0, e)
    while arr.size() > MAX_ENTRIES:
        arr.pop_back()


func entries() -> Array:
    return SaveManager.data["history"]
