extends RefCounted
# Slot engine. Outcomes use a weighted pseudo-random generator (RandomNumberGenerator, PCG32),
# seeded randomly each session. Every spin is independent: no adaptive / loss-chasing logic.

const WILD: int = 10
const SP_BLANK: int = 0
const SP_SCATTER: int = 1
const SP_SUPER: int = 2
const SP_WHEEL: int = 3
const SP_ALL: int = 4
const SP_X2: int = 5
const SP_X3: int = 6
const SP_X5: int = 7
const SP_X10: int = 8

# Index = symbol (0-9 digits, 10 = WILD)
const DIGIT_WEIGHTS: Array = [10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 1]
# Index = SP_* (BLANK, SCATTER, SUPER, WHEEL, ALL, X2, X3, X5, X10)
const SPECIAL_WEIGHTS: Array = [815, 80, 10, 25, 25, 25, 12, 6, 2]
# Same order as RewardScaling.BASE_WHEEL
const WHEEL_WEIGHTS: Array = [25, 12, 1, 6, 22, 9, 16, 3]
const JACKPOT_ORDER: Array = ["MINI", "MINOR", "MAJOR", "GRAND"]
const JACKPOT_WEIGHTS: Array = [60, 28, 10, 2]

var rng: RandomNumberGenerator = RandomNumberGenerator.new()


func _init() -> void:
    rng.randomize()


func _pick(weights: Array) -> int:
    var total: int = 0
    for w in weights:
        total += int(w)
    if total <= 0:
        return 0
    var r: int = rng.randi_range(1, total)
    var acc: int = 0
    for i in weights.size():
        acc += int(weights[i])
        if r <= acc:
            return i
    return 0


func spin(restricted: bool = false) -> Dictionary:
    var reels: Array = []
    for i in 3:
        reels.append(_pick(DIGIT_WEIGHTS))
    var w: Array = SPECIAL_WEIGHTS.duplicate()
    if restricted:
        w[SP_SUPER] = 0
        w[SP_WHEEL] = 0
        w[SP_ALL] = 0
    return {"reels": reels, "special": _pick(w)}


func pick_wheel() -> int:
    return _pick(WHEEL_WEIGHTS)


func pick_jackpot() -> String:
    return str(JACKPOT_ORDER[_pick(JACKPOT_WEIGHTS)])
