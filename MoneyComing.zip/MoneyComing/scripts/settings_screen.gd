extends Control
# Settings window
const UI = preload("res://scripts/ui.gd")
const Lang = preload("res://scripts/lang.gd")

signal closed

const AUTO_STEPS: Array = [10, 25, 50, 100]

var rows: Array = []
var _reset_armed: bool = false
var win: Panel


func _ready() -> void:
    size = Vector2(720, 1280)
    _build()


func _build() -> void:
    for c in get_children():
        c.queue_free()
    rows.clear()
    win = UI.window(self, Lang.t("settings"))
    var names: Array = ["sound_on", "music", "vibration", "anim_q", "gfx_q", "spin_speed", "auto_n", "language", "reset", "about", "privacy"]
    for i in names.size():
        var y: float = 100.0 + float(i) * 78.0
        win.add_child(UI.label(Lang.t(str(names[i])), Vector2(30, y), Vector2(380, 60), 28, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT))
        var b: Button = UI.button(_value_text(str(names[i])), Vector2(410, y + 2), Vector2(220, 56), Color("1f6b2a") if _is_on(str(names[i])) else Color("5a2a08"), 24, 14)
        b.pressed.connect(_on_row.bind(str(names[i])))
        win.add_child(b)
        rows.append(b)
    var back: Button = UI.button(Lang.t("back"), Vector2(230, 1050), Vector2(200, 64), UI.RED, 28)
    back.pressed.connect(_close)
    win.add_child(back)


func _is_on(key: String) -> bool:
    var s: Dictionary = SaveManager.data["settings"]
    if key == "sound_on":
        return bool(s["sound"])
    if key == "music":
        return bool(s["music"])
    if key == "vibration":
        return bool(s["vibration"])
    if key == "spin_speed":
        return bool(s["fast"])
    return true


func _onoff(v: bool) -> String:
    return Lang.t("on") if v else Lang.t("off")


func _value_text(key: String) -> String:
    var s: Dictionary = SaveManager.data["settings"]
    if key == "sound_on":
        return _onoff(bool(s["sound"]))
    if key == "music":
        return _onoff(bool(s["music"]))
    if key == "vibration":
        return _onoff(bool(s["vibration"]))
    if key == "anim_q":
        return [Lang.t("low"), Lang.t("medium"), Lang.t("high")][int(s["anim_quality"])]
    if key == "gfx_q":
        return Lang.t("low") if int(s["gfx_quality"]) == 0 else Lang.t("high")
    if key == "spin_speed":
        return Lang.t("fast") if bool(s["fast"]) else Lang.t("normal")
    if key == "auto_n":
        return str(int(s["auto_count"]))
    if key == "language":
        return "हिन्दी" if str(s["language"]) == "hi" else "English"
    if key == "reset":
        return "CONFIRM?" if _reset_armed else "RESET"
    return "VIEW"


func _on_row(key: String) -> void:
    SoundManager.play("click")
    var s: Dictionary = SaveManager.data["settings"]
    if key == "sound_on":
        s["sound"] = not bool(s["sound"])
    elif key == "music":
        s["music"] = not bool(s["music"])
    elif key == "vibration":
        s["vibration"] = not bool(s["vibration"])
    elif key == "anim_q":
        s["anim_quality"] = (int(s["anim_quality"]) + 1) % 3
    elif key == "gfx_q":
        s["gfx_quality"] = 1 - int(s["gfx_quality"])
    elif key == "spin_speed":
        s["fast"] = not bool(s["fast"])
    elif key == "auto_n":
        var i: int = AUTO_STEPS.find(int(s["auto_count"]))
        s["auto_count"] = int(AUTO_STEPS[(i + 1) % AUTO_STEPS.size()])
    elif key == "language":
        s["language"] = "hi" if str(s["language"]) == "en" else "en"
    elif key == "reset":
        if _reset_armed:
            SaveManager.reset_all()
            BetManager.reload()
            SoundManager.apply_settings()
            get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
            return
        _reset_armed = true
    elif key == "about":
        _show_text(Lang.t("about"), "Money Coming - premium classic slot.\nOriginal artwork, sounds and branding.\nVirtual coins only. No real money, no deposits, no cash-out.\nFor entertainment. Recommended for 18+.")
        return
    elif key == "privacy":
        _show_text(Lang.t("privacy"), "This game uses only fictional virtual coins that have no monetary value.\nAll progress is stored locally on your device.\nNo personal data is collected, shared or sold.\nThe game works fully offline.")
        return
    SaveManager.save_game()
    SoundManager.apply_settings()
    _build()


func _show_text(title: String, body: String) -> void:
    var ov := Control.new()
    ov.size = Vector2(720, 1280)
    add_child(ov)
    var p: Panel = UI.panel(Vector2(60, 300), Vector2(600, 560), Color("1a0805"), UI.GOLD, 22)
    ov.add_child(p)
    p.add_child(UI.label(title, Vector2(0, 10), Vector2(600, 60), 36, UI.GOLD, HORIZONTAL_ALIGNMENT_CENTER, 6))
    var l: Label = UI.label(body, Vector2(30, 80), Vector2(540, 380), 26, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    l.vertical_alignment = VERTICAL_ALIGNMENT_TOP
    p.add_child(l)
    var ok: Button = UI.button(Lang.t("close"), Vector2(200, 476), Vector2(200, 56), UI.RED, 26)
    ok.pressed.connect(ov.queue_free)
    p.add_child(ok)


func _close() -> void:
    SoundManager.play("click")
    SaveManager.save_game()
    closed.emit()
    queue_free()
