extends Control
# Spin history + session statistics
const UI = preload("res://scripts/ui.gd")
const Lang = preload("res://scripts/lang.gd")

signal closed


func _ready() -> void:
    size = Vector2(720, 1280)
    var win: Panel = UI.window(self, Lang.t("history"))
    var st: String = "Session: %d spins | Bet %s | Won %s | Best %s" % [Wallet.session_spins, UI.fmt(Wallet.session_bet), UI.fmt(Wallet.session_win), UI.fmt(Wallet.session_best)]
    var sl: Label = UI.label(st, Vector2(20, 86), Vector2(620, 60), 22, UI.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_CENTER)
    sl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    win.add_child(sl)
    var sc := ScrollContainer.new()
    sc.position = Vector2(20, 156)
    sc.size = Vector2(620, 880)
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    win.add_child(sc)
    var vb := VBoxContainer.new()
    vb.custom_minimum_size = Vector2(600, 0)
    sc.add_child(vb)
    var list: Array = HistoryManager.entries()
    if list.is_empty():
        var e: Label = UI.label("No spins yet", Vector2(0, 0), Vector2(600, 60), 28, Color(1, 1, 1, 0.6))
        e.custom_minimum_size = Vector2(600, 60)
        vb.add_child(e)
    for h in list:
        var line1: String = "#%d  %s" % [int(h.get("n", 0)), str(h.get("t", ""))]
        var line2: String = "Bet %s   Win %s   [%s]" % [UI.fmt(int(h.get("bet", 0))), UI.fmt(int(h.get("win", 0))), str(h.get("reels", ""))]
        var extra: Array = []
        for k in ["scatter", "wheel", "bonus", "respin", "jackpot"]:
            if int(h.get(k, 0)) > 0:
                extra.append("%s %s" % [k, UI.fmt(int(h[k]))])
        if bool(h.get("free", false)):
            extra.append("free spin")
        var txt: String = line1 + "\n" + line2
        if not extra.is_empty():
            txt += "\n" + ", ".join(extra)
        var pnl: Panel = UI.panel(Vector2.ZERO, Vector2(600, 100), Color("1a0805"), UI.GOLD_DARK, 10, 2)
        pnl.custom_minimum_size = Vector2(600, 100)
        pnl.mouse_filter = Control.MOUSE_FILTER_PASS
        var l: Label = UI.label(txt, Vector2(10, 4), Vector2(580, 92), 20, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
        pnl.add_child(l)
        vb.add_child(pnl)
    var back: Button = UI.button(Lang.t("back"), Vector2(230, 1050), Vector2(200, 64), UI.RED, 28)
    back.pressed.connect(_close)
    win.add_child(back)


func _close() -> void:
    SoundManager.play("click")
    closed.emit()
    queue_free()
