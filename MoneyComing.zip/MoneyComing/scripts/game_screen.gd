extends Control
# Main game screen: classic Money Coming layout (wheel, scatter panel, 3 number reels + special reel, controls)
const UI = preload("res://scripts/ui.gd")
const Lang = preload("res://scripts/lang.gd")
const SlotEngine = preload("res://scripts/slot_engine.gd")
const WinCalculator = preload("res://scripts/win_calculator.gd")
const ScatterManager = preload("res://scripts/scatter_manager.gd")
const RespinManager = preload("res://scripts/respin_manager.gd")
const BonusManager = preload("res://scripts/bonus_manager.gd")

const CW: float = 720.0
const CH: float = 1280.0
const SPECIAL_NAMES: Array = ["-", "SCATTER", "SUPER", "WHEEL", "ALL RESPIN", "2X", "3X", "5X", "10X"]

var content: Control
var wheel = null
var panel = null
var slot = null
var reels: Array = []

var engine = SlotEngine.new()
var scatter = ScatterManager.new()
var respin = RespinManager.new()
var bonus = BonusManager.new()

var busy: bool = false
var auto_on: bool = false
var auto_left: int = 0
var fast: bool = false
var stop_req: bool = false
var in_free: bool = false
var round_win: int = 0
var detail: Dictionary = {}
var features: int = 0
var jackpot_hit: bool = false
var panel_mode: int = 0
var cycle_t: float = 0.0

var lbl_win: Label
var lbl_win_title: Label
var lbl_bet: Label
var lbl_bet_title: Label
var lbl_bal: Label
var lbl_bal_title: Label
var lbl_vip: Label
var lbl_free: Label
var toast_lbl: Label
var btn_minus: Button
var btn_plus: Button
var btn_spin: Button
var btn_auto: Button
var btn_fast: Button
var btn_stop: Button
var btn_set: Button
var btn_snd: Button
var btn_info: Button
var btn_more: Button


func _ready() -> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)
    var base := ColorRect.new()
    base.color = Color("2b0b07")
    base.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(base)
    var pat := Control.new()
    pat.set_anchors_preset(Control.PRESET_FULL_RECT)
    pat.mouse_filter = Control.MOUSE_FILTER_IGNORE
    pat.draw.connect(_draw_pattern.bind(pat))
    add_child(pat)
    content = Control.new()
    content.size = Vector2(CW, CH)
    content.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(content)
    get_viewport().size_changed.connect(_relayout)
    _relayout()

    scatter.load_state()
    bonus.load_state()
    fast = bool(SaveManager.data["settings"]["fast"])

    _build_ui()

    RewardScaling.rewards_changed.connect(_on_rewards_changed)
    Wallet.balance_changed.connect(_on_balance)
    BetManager.bet_changed.connect(_on_bet_changed)
    ProfileManager.level_up.connect(_on_level_up)
    ProfileManager.achievement_unlocked.connect(_on_achievement)

    _on_rewards_changed()
    _on_bet_changed(BetManager.current_bet)
    _on_balance(Wallet.get_balance())
    _update_free_label()
    _update_auto_label()
    _style_fast()
    SoundManager.apply_settings()
    if bonus.free_spins > 0:
        _resume_free()


func _relayout() -> void:
    var vs: Vector2 = get_viewport_rect().size
    content.position = Vector2((vs.x - CW) / 2.0, (vs.y - CH) / 2.0)


func _draw_pattern(pat: Control) -> void:
    var step: float = 36.0
    var cols: int = int(pat.size.x / step) + 1
    var rows: int = int(pat.size.y / step) + 1
    for y in rows:
        for x in cols:
            if (x + y) % 2 == 0:
                pat.draw_rect(Rect2(float(x) * step + 4.0, float(y) * step + 4.0, step - 8.0, step - 8.0), Color(0.55, 0.12, 0.05, 0.22))


func _draw_arch(arch: Control) -> void:
    var c: Vector2 = Vector2(360, 300)
    arch.draw_circle(c, 296, Color("6e4208"))
    arch.draw_rect(Rect2(64, 300, 592, 450), Color("6e4208"))
    arch.draw_circle(c, 288, UI.GOLD)
    arch.draw_rect(Rect2(72, 300, 576, 450), UI.GOLD)
    arch.draw_circle(c, 270, Color("14702a"))
    arch.draw_rect(Rect2(90, 300, 540, 450), Color("14702a"))
    var dc: Color = Color(0.3, 0.75, 0.3, 0.18)
    for ry in range(560, 720, 52):
        for rx in range(120, 620, 64):
            var cx: float = float(rx) + (32.0 if ((ry - 560) / 52) % 2 == 1 else 0.0)
            var cy: float = float(ry)
            arch.draw_colored_polygon(PackedVector2Array([Vector2(cx, cy - 22), Vector2(cx + 26, cy), Vector2(cx, cy + 22), Vector2(cx - 26, cy)]), dc)


func _build_ui() -> void:
    var arch := Control.new()
    arch.size = Vector2(CW, 780)
    arch.mouse_filter = Control.MOUSE_FILTER_IGNORE
    arch.draw.connect(_draw_arch.bind(arch))
    content.add_child(arch)

    wheel = load("res://scenes/fortune_wheel.tscn").instantiate()
    wheel.position = Vector2(90, 30)
    content.add_child(wheel)

    content.add_child(UI.label("Money Coming", Vector2(60, 598), Vector2(600, 84), 70, Color("e5301f"), HORIZONTAL_ALIGNMENT_CENTER, 12, UI.GOLD_LIGHT))

    panel = load("res://scenes/scatter_panel.tscn").instantiate()
    panel.position = Vector2(40, 690)
    content.add_child(panel)

    slot = load("res://scenes/slot_machine.tscn").instantiate()
    slot.position = Vector2(40, 796)
    content.add_child(slot)
    reels = slot.reels

    # WIN row
    lbl_free = UI.label("", Vector2(16, 1024), Vector2(170, 38), 22, UI.GOLD, HORIZONTAL_ALIGNMENT_LEFT, 4)
    content.add_child(lbl_free)
    lbl_win_title = UI.label(Lang.t("win"), Vector2(200, 1024), Vector2(110, 38), 30, UI.GOLD, HORIZONTAL_ALIGNMENT_CENTER, 4)
    content.add_child(lbl_win_title)
    lbl_win = UI.label("0", Vector2(310, 1024), Vector2(300, 38), 34, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT, 5)
    content.add_child(lbl_win)

    # BET panel
    lbl_bet_title = UI.label(Lang.t("bet"), Vector2(74, 1080), Vector2(122, 24), 18, UI.GOLD, HORIZONTAL_ALIGNMENT_CENTER)
    content.add_child(lbl_bet_title)
    btn_minus = UI.button("-", Vector2(14, 1108), Vector2(58, 58), Color("5a2a08"), 38, 29)
    btn_minus.pressed.connect(_on_bet_minus)
    content.add_child(btn_minus)
    var bet_bg: Panel = UI.panel(Vector2(76, 1108), Vector2(118, 58), Color("3b1a08"), UI.GOLD_DARK, 10, 3)
    content.add_child(bet_bg)
    lbl_bet = UI.label("100", Vector2(76, 1108), Vector2(118, 58), 28, Color.WHITE)
    content.add_child(lbl_bet)
    btn_plus = UI.button("+", Vector2(198, 1108), Vector2(58, 58), Color("5a2a08"), 38, 29)
    btn_plus.pressed.connect(_on_bet_plus)
    content.add_child(btn_plus)

    # SPIN
    btn_spin = UI.button(Lang.t("spin"), Vector2(270, 1068), Vector2(150, 150), Color("22b53a"), 34, 75, UI.GOLD, 8)
    btn_spin.pressed.connect(_on_spin)
    content.add_child(btn_spin)

    # AUTO / FAST / STOP
    btn_auto = UI.button(Lang.t("auto"), Vector2(440, 1100), Vector2(74, 74), Color("5a2a08"), 18, 37)
    btn_auto.pressed.connect(_on_auto)
    content.add_child(btn_auto)
    btn_fast = UI.button(Lang.t("fast"), Vector2(522, 1100), Vector2(74, 74), Color("5a2a08"), 18, 37)
    btn_fast.pressed.connect(_on_fast)
    content.add_child(btn_fast)
    btn_stop = UI.button(Lang.t("stop"), Vector2(604, 1100), Vector2(74, 74), Color("8a1a14"), 18, 37)
    btn_stop.pressed.connect(_on_stop)
    content.add_child(btn_stop)

    # bottom row
    btn_set = UI.button("SET", Vector2(14, 1226), Vector2(92, 44), Color("3b1a08"), 18, 12)
    btn_set.pressed.connect(_open_settings)
    content.add_child(btn_set)
    btn_snd = UI.button("SND", Vector2(112, 1226), Vector2(92, 44), Color("3b1a08"), 18, 12)
    btn_snd.pressed.connect(_on_sound)
    content.add_child(btn_snd)
    btn_info = UI.button("INFO", Vector2(210, 1226), Vector2(92, 44), Color("3b1a08"), 18, 12)
    btn_info.pressed.connect(_open_info)
    content.add_child(btn_info)
    btn_more = UI.button(Lang.t("more"), Vector2(308, 1226), Vector2(92, 44), Color("3b1a08"), 18, 12)
    btn_more.pressed.connect(_open_menu)
    content.add_child(btn_more)

    lbl_vip = UI.label("VIP 1", Vector2(410, 1228), Vector2(70, 40), 20, UI.GOLD, HORIZONTAL_ALIGNMENT_CENTER, 4)
    content.add_child(lbl_vip)
    lbl_bal_title = UI.label(Lang.t("balance"), Vector2(480, 1214), Vector2(226, 22), 16, UI.GOLD, HORIZONTAL_ALIGNMENT_RIGHT)
    content.add_child(lbl_bal_title)
    lbl_bal = UI.label("0", Vector2(450, 1234), Vector2(256, 40), 28, Color.WHITE, HORIZONTAL_ALIGNMENT_RIGHT, 5)
    content.add_child(lbl_bal)

    # toast
    toast_lbl = UI.label("", Vector2(80, 1030), Vector2(560, 46), 24, Color.WHITE)
    toast_lbl.add_theme_stylebox_override("normal", UI.style(Color(0, 0, 0, 0.8), UI.GOLD, 20, 3))
    toast_lbl.modulate.a = 0.0
    content.add_child(toast_lbl)


# ---------------------------------------------------------------- UI refresh
func _on_rewards_changed() -> void:
    if wheel != null:
        wheel.set_values(RewardScaling.wheel_rewards)
    if panel != null:
        _update_panel()


func _digit_count(bet: int) -> int:
    if bet >= 10000:
        return 5
    if bet >= 1000:
        return 4
    return 3


func _sync_reels() -> void:
    if slot != null and not busy:
        slot.set_digit_count(_digit_count(BetManager.current_bet))
        reels = slot.reels


func _on_bet_changed(b: int) -> void:
    _sync_reels()
    lbl_bet.text = UI.fmt(b)
    lbl_bet.add_theme_font_size_override("font_size", UI.fit_size(lbl_bet.text, 28))


func _on_balance(b: int) -> void:
    lbl_bal.text = UI.fmt(b)
    lbl_bal.add_theme_font_size_override("font_size", UI.fit_size(lbl_bal.text, 28))
    lbl_vip.text = "VIP " + str(ProfileManager.level())


func _on_level_up(lv: int) -> void:
    _toast("LEVEL UP!  Level %d" % lv)


func _on_achievement(title: String) -> void:
    _toast("Achievement: " + title)


func _update_panel() -> void:
    var m: int = panel_mode
    if respin.active:
        m = 2
    elif scatter.super_count == 0:
        m = 0
    if m == 0:
        panel.set_state(0, RewardScaling.scatter_reward, scatter.count)
    elif m == 1:
        panel.set_state(1, RewardScaling.super_scatter_reward, scatter.super_count)
    else:
        panel.set_state(2, respin.total_win, respin.left)


func _process(delta: float) -> void:
    if not respin.active and scatter.super_count > 0:
        cycle_t += delta
        if cycle_t > 2.5:
            cycle_t = 0.0
            panel_mode = 1 - panel_mode
            _update_panel()


func _set_win(v: int) -> void:
    var t: String = UI.fmt(v)
    lbl_win.text = t
    lbl_win.add_theme_font_size_override("font_size", UI.fit_size(t, 34))
    if v > 0:
        lbl_win.modulate = Color(1.0, 1.0, 0.4)
        var tw: Tween = create_tween()
        tw.tween_property(lbl_win, "modulate", Color.WHITE, 0.4)


func _update_free_label() -> void:
    if bonus.free_spins > 0:
        lbl_free.text = Lang.t("free") + " " + str(bonus.free_spins)
    else:
        lbl_free.text = ""


func _update_auto_label() -> void:
    if auto_on:
        btn_auto.text = str(auto_left)
        UI.set_button_color(btn_auto, Color("22b53a"), UI.GOLD, 37)
    else:
        btn_auto.text = Lang.t("auto")
        UI.set_button_color(btn_auto, Color("5a2a08"), UI.GOLD, 37)


func _style_fast() -> void:
    if fast:
        UI.set_button_color(btn_fast, Color("d98a10"), UI.GOLD_LIGHT, 37)
    else:
        UI.set_button_color(btn_fast, Color("5a2a08"), UI.GOLD, 37)


func _apply_language() -> void:
    btn_spin.text = Lang.t("spin")
    btn_fast.text = Lang.t("fast")
    btn_stop.text = Lang.t("stop")
    btn_more.text = Lang.t("more")
    lbl_win_title.text = Lang.t("win")
    lbl_bet_title.text = Lang.t("bet")
    lbl_bal_title.text = Lang.t("balance")
    _update_auto_label()
    _update_free_label()
    _update_panel()


func _toast(msg: String) -> void:
    toast_lbl.text = msg
    toast_lbl.modulate.a = 1.0
    var tw: Tween = create_tween()
    tw.tween_interval(1.6)
    tw.tween_property(toast_lbl, "modulate:a", 0.0, 0.4)


func _set_busy_ui(b: bool) -> void:
    btn_minus.disabled = b
    btn_plus.disabled = b
    btn_spin.disabled = b
    btn_more.disabled = b
    btn_set.disabled = b
    btn_info.disabled = b


# ---------------------------------------------------------------- buttons
func _on_bet_plus() -> void:
    if busy:
        return
    SoundManager.play("click")
    BetManager.increase()


func _on_bet_minus() -> void:
    if busy:
        return
    SoundManager.play("click")
    BetManager.decrease()


func _on_spin() -> void:
    if busy:
        return
    SoundManager.play("click")
    _round_loop()


func _on_auto() -> void:
    SoundManager.play("click")
    if auto_on:
        auto_on = false
        auto_left = 0
        _update_auto_label()
        return
    auto_on = true
    auto_left = int(SaveManager.data["settings"]["auto_count"])
    _update_auto_label()
    if not busy:
        _round_loop()


func _on_fast() -> void:
    SoundManager.play("click")
    fast = not fast
    SaveManager.data["settings"]["fast"] = fast
    _style_fast()


func _on_stop() -> void:
    SoundManager.play("click")
    stop_req = true
    auto_on = false
    auto_left = 0
    _update_auto_label()


func _on_sound() -> void:
    var s: Dictionary = SaveManager.data["settings"]
    s["sound"] = not bool(s["sound"])
    SaveManager.save_game()
    if bool(s["sound"]):
        SoundManager.play("click")
    _toast("Sound " + ("ON" if bool(s["sound"]) else "OFF"))


func _open_screen(path: String):
    var scr = load(path).instantiate()
    scr.size = Vector2(CW, CH)
    content.add_child(scr)
    return scr


func _open_settings() -> void:
    SoundManager.play("click")
    var scr = _open_screen("res://scenes/settings_screen.tscn")
    scr.closed.connect(_after_popup)


func _open_info() -> void:
    SoundManager.play("click")
    _open_screen("res://scenes/info_screen.tscn")


func _after_popup() -> void:
    fast = bool(SaveManager.data["settings"]["fast"])
    _style_fast()
    _apply_language()
    _on_balance(Wallet.get_balance())


func _open_menu() -> void:
    SoundManager.play("click")
    var ov := Control.new()
    ov.size = Vector2(CW, CH)
    content.add_child(ov)
    var d: ColorRect = UI.dim(ov)
    d.gui_input.connect(_overlay_input.bind(ov))
    var p: Panel = UI.panel(Vector2(110, 380), Vector2(500, 520), Color("2a0d08"), UI.GOLD, 24)
    ov.add_child(p)
    var items: Array = [
        [Lang.t("profile"), "res://scenes/profile_screen.tscn"],
        [Lang.t("history"), "res://scenes/history_screen.tscn"],
        [Lang.t("daily"), "res://scenes/daily_screen.tscn"],
        [Lang.t("main_menu"), "menu"],
    ]
    for i in items.size():
        var b: Button = UI.button(str(items[i][0]), Vector2(50, 40.0 + float(i) * 115.0), Vector2(400, 90), Color("5a2a08"), 30)
        b.pressed.connect(_menu_pick.bind(ov, str(items[i][1])))
        p.add_child(b)


func _overlay_input(e: InputEvent, ov: Control) -> void:
    if e is InputEventMouseButton and e.pressed:
        ov.queue_free()


func _menu_pick(ov: Control, target: String) -> void:
    SoundManager.play("click")
    ov.queue_free()
    if target == "menu":
        _save_all()
        get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
        return
    var scr = _open_screen(target)
    scr.closed.connect(_after_popup)


# ---------------------------------------------------------------- round flow
func _resume_free() -> void:
    await get_tree().create_timer(1.0).timeout
    if not busy and bonus.free_spins > 0:
        _round_loop()


func _round_loop() -> void:
    busy = true
    _set_busy_ui(true)
    while true:
        var cont: bool = await _one_round()
        if not cont:
            break
        await get_tree().create_timer(0.35).timeout
    busy = false
    _set_busy_ui(false)
    _update_auto_label()


func _wait(t: float) -> void:
    var d: float = 0.04 if stop_req else t
    await get_tree().create_timer(d).timeout


func _clear_fx() -> void:
    for r in reels:
        r.set_win(false)
    if wheel != null:
        wheel.clear_highlight()


func _digits_text(digits: Array) -> String:
    var parts: Array = []
    for v in digits:
        parts.append(_sym_name(int(v)))
    return "-".join(parts)


func _sym_name(v: int) -> String:
    return "W" if v == SlotEngine.WILD else str(v)


func _one_round() -> bool:
    var is_free: bool = bonus.free_spins > 0
    var bet: int = BetManager.current_bet
    if not is_free and not Wallet.can_afford(bet):
        _toast(Lang.t("no_balance"))
        auto_on = false
        return false
    BetManager.lock()
    bet = BetManager.round_bet()
    round_win = 0
    detail = {"line": 0, "scatter": 0, "wheel": 0, "bonus": 0, "respin": 0, "jackpot": 0}
    features = 0
    jackpot_hit = false
    stop_req = false
    in_free = is_free
    if is_free:
        bonus.consume_free()
    else:
        Wallet.place_bet(bet)
    _save_all()
    _clear_fx()
    _set_win(0)
    _update_free_label()

    var res: Dictionary = engine.spin(false, _digit_count(bet))
    await _animate_spin(res)
    await _play_outcome(res, bet, "line", true)

    var tier: String = WinCalculator.win_tier(round_win, bet)
    if tier != "" and not is_free:
        SoundManager.play("bigwin")
        SoundManager.vibrate(80)
        _burst_coins()
        await _show_reward(tier, round_win)

    Wallet.register_round(round_win)
    var digits: Array = res["reels"]
    HistoryManager.add_entry({
        "bet": bet,
        "win": round_win,
        "reels": _digits_text(digits) + " | " + str(SPECIAL_NAMES[int(res["special"])]),
        "scatter": int(detail["scatter"]),
        "wheel": int(detail["wheel"]),
        "bonus": int(detail["bonus"]),
        "respin": int(detail["respin"]),
        "jackpot": int(detail["jackpot"]),
        "free": is_free,
    })
    ProfileManager.on_round(bet, round_win, features, jackpot_hit)

    if is_free and bonus.free_spins == 0 and bonus.free_total > 0:
        var tot: int = bonus.free_total
        bonus.free_total = 0
        await _show_reward(Lang.t("free_total"), tot)

    BetManager.unlock()
    _save_all()
    _update_free_label()
    _on_balance(Wallet.get_balance())

    if bonus.free_spins > 0:
        return true
    if auto_on:
        auto_left -= 1
        _update_auto_label()
        if auto_left <= 0:
            auto_on = false
            return false
        if not Wallet.can_afford(BetManager.current_bet):
            auto_on = false
            _toast(Lang.t("no_balance"))
            return false
        return true
    return false


func _save_all() -> void:
    scatter.save_state()
    bonus.save_state()
    SaveManager.save_game()


func _animate_spin(res: Dictionary) -> void:
    _clear_fx()
    SoundManager.play("spin")
    for r in reels:
        r.start_spin()
    var digits: Array = res["reels"]
    var targets: Array = []
    for v in digits:
        targets.append(int(v))
    targets.append(int(res["special"]))
    var first: float = 0.35 if fast else 0.9
    var gap: float = 0.15 if fast else 0.42
    for i in reels.size():
        await _wait(first if i == 0 else gap)
        reels[i].stop_at(int(targets[i]))
        SoundManager.play("stop")
    await reels[reels.size() - 1].stopped


func _award(amount: int, cat: String) -> void:
    if amount <= 0:
        return
    Wallet.add_win(amount, cat)
    round_win += amount
    detail[cat] = int(detail[cat]) + amount
    if in_free:
        bonus.free_total += amount
    _set_win(round_win)


func _play_outcome(res: Dictionary, bet: int, cat: String, allow_bonus: bool) -> void:
    var digits: Array = res["reels"]
    var sp: int = int(res["special"])
    var ev: Dictionary = WinCalculator.evaluate(digits)
    var mult: int = WinCalculator.special_multiplier(sp)
    var line: int = WinCalculator.line_payout(int(ev["mult10"]), bet) * mult
    if line > 0:
        for i in digits.size():
            reels[i].set_win(true)
        if mult > 1:
            reels[reels.size() - 1].set_win(true)
        SoundManager.play("win")
        SoundManager.vibrate(30)
        _award(line, cat)
        await _wait(0.6)
    if sp == SlotEngine.SP_SCATTER:
        reels[reels.size() - 1].set_win(true)
        SoundManager.play("scatter")
        var act: bool = scatter.add_scatter()
        _update_panel()
        await _wait(0.5)
        features += 1
        await _wheel_spin(bet, "scatter")
        if act:
            await _scatter_bonus(bet)
    elif sp == SlotEngine.SP_SUPER:
        reels[reels.size() - 1].set_win(true)
        SoundManager.play("scatter")
        var act2: bool = scatter.add_super()
        _update_panel()
        await _wait(0.5)
        if act2:
            await _super_bonus(bet)
    elif sp == SlotEngine.SP_WHEEL:
        reels[reels.size() - 1].set_win(true)
        await _wheel_respin(bet)
    elif sp == SlotEngine.SP_ALL:
        reels[reels.size() - 1].set_win(true)
        await _all_respin(bet)
    if allow_bonus and bool(ev["bonus"]):
        await _bonus_round(bet)


# ---------------------------------------------------------------- features
func _banner(title: String, sub: String, col: Color) -> void:
    var scr = _open_screen("res://scenes/respin_screen.tscn")
    scr.setup(title, sub, col, 0.8 if (fast or auto_on) else 1.6)
    SoundManager.play("bonus")
    await scr.closed


func _show_reward(title: String, amount: int) -> void:
    var scr = _open_screen("res://scenes/reward_screen.tscn")
    scr.setup(title, amount, 1.0 if (fast or auto_on) else 2.4)
    await scr.closed


func _burst_coins() -> void:
    var q: int = int(SaveManager.data["settings"]["anim_quality"])
    var p := CPUParticles2D.new()
    p.position = Vector2(360, 640)
    p.amount = 15 + q * 15
    p.lifetime = 1.6
    p.one_shot = true
    p.explosiveness = 0.95
    p.direction = Vector2(0, -1)
    p.spread = 80.0
    p.gravity = Vector2(0, 1100)
    p.initial_velocity_min = 450.0
    p.initial_velocity_max = 900.0
    p.scale_amount_min = 8.0
    p.scale_amount_max = 14.0
    p.color = UI.GOLD
    content.add_child(p)
    p.emitting = true
    get_tree().create_timer(2.5).timeout.connect(p.queue_free)


func _wheel_respin(bet: int) -> void:
    features += 1
    await _banner(Lang.t("wheel_respin"), "Spin the Fortune Wheel!", Color("2b6fd6"))
    await _wheel_spin(bet, "wheel")


# Spins the Fortune Wheel; the segment it stops on is the win (scaled to the locked bet).
func _wheel_spin(bet: int, cat: String) -> void:
    var vals: Array = RewardScaling.wheel_rewards_for(bet)
    wheel.set_values(vals)
    var idx: int = engine.pick_wheel()
    SoundManager.play("wheel")
    await wheel.spin_to(idx, 2.2 if fast else 4.2)
    wheel.highlight(idx)
    var prize: int = int(vals[idx])
    _award(prize, cat)
    SoundManager.play("bigwin")
    SoundManager.vibrate(60)
    _burst_coins()
    await _show_reward(Lang.t("wheel_win"), prize)
    wheel.clear_highlight()


func _all_respin(bet: int) -> void:
    features += 1
    var pot: int = RewardScaling.calculate_scaled_reward(RewardScaling.BASE_RESPIN, bet)
    await _banner(Lang.t("all_respin"), "+%s  |  %d RESPINS" % [UI.fmt(pot), RespinManager.RESPINS], Color("2b6fd6"))
    respin.start()
    _award(pot, "respin")
    respin.add_win(pot)
    _update_panel()
    while respin.next():
        _update_panel()
        await _wait(0.3)
        var res: Dictionary = engine.spin(true, _digit_count(bet))
        await _animate_spin(res)
        var before: int = round_win
        await _play_outcome(res, bet, "respin", false)
        respin.add_win(round_win - before)
        _update_panel()
        await _wait(0.4)
    var total: int = respin.total_win
    respin.finish()
    _update_panel()
    await _show_reward(Lang.t("all_respin"), total)


func _scatter_bonus(bet: int) -> void:
    features += 1
    scatter.reset_scatter()
    _update_panel()
    var prize: int = RewardScaling.calculate_scaled_reward(RewardScaling.BASE_SCATTER, bet)
    await _banner(Lang.t("scatter_bonus"), "+%d FREE SPINS" % BonusManager.FREE_SPINS_AWARD, Color("1f9d2b"))
    bonus.add_free_spins(BonusManager.FREE_SPINS_AWARD)
    _update_free_label()
    _award(prize, "scatter")
    SoundManager.play("bigwin")
    _burst_coins()
    await _show_reward(Lang.t("scatter_win"), prize)


func _super_bonus(bet: int) -> void:
    features += 1
    scatter.reset_super()
    panel_mode = 0
    _update_panel()
    var tier: String = engine.pick_jackpot()
    var prize: int = bonus.jackpot_prize(tier, bet)
    await _banner(Lang.t("super_scatter"), tier + " JACKPOT", Color("b3201a"))
    _award(prize, "jackpot")
    jackpot_hit = true
    SoundManager.play("jackpot")
    SoundManager.vibrate(120)
    _burst_coins()
    await _show_reward(tier + " JACKPOT", prize)


func _bonus_round(bet: int) -> void:
    features += 1
    await _banner(Lang.t("bonus_round"), "Pick a gift box!", Color("a8741a"))
    var scr = _open_screen("res://scenes/bonus_screen.tscn")
    scr.setup(RewardScaling.bonus_rewards_for(bet), auto_on or in_free or fast)
    var prize: int = await scr.finished
    _award(prize, "bonus")
    SoundManager.play("bigwin")
    _burst_coins()
    await _show_reward(Lang.t("bonus_round"), prize)


func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        if not busy:
            _save_all()
            get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
