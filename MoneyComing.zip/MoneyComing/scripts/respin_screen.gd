extends Control
# Banner used for feature announcements (ALL RESPIN, WHEEL RESPIN, SCATTER BONUS, ...)
const UI = preload("res://scripts/ui.gd")

signal closed

var _done: bool = false


func setup(title: String, subtitle: String, col: Color, duration: float = 1.6) -> void:
    size = Vector2(720, 1280)
    var d: ColorRect = UI.dim(self)
    d.gui_input.connect(_on_input)
    var band := ColorRect.new()
    band.color = col
    band.position = Vector2(-100, 500)
    band.size = Vector2(920, 250)
    add_child(band)
    var edge1 := ColorRect.new()
    edge1.color = UI.GOLD
    edge1.position = Vector2(-100, 496)
    edge1.size = Vector2(920, 6)
    add_child(edge1)
    var edge2 := ColorRect.new()
    edge2.color = UI.GOLD
    edge2.position = Vector2(-100, 748)
    edge2.size = Vector2(920, 6)
    add_child(edge2)
    add_child(UI.label(title, Vector2(20, 520), Vector2(680, 120), UI.fit_size(title, 78), UI.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_CENTER, 12, Color(0.15, 0.03, 0.0)))
    add_child(UI.label(subtitle, Vector2(20, 640), Vector2(680, 80), 40, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 8, Color(0.1, 0.02, 0.0)))
    modulate.a = 0.0
    var tw: Tween = create_tween()
    tw.tween_property(self, "modulate:a", 1.0, 0.2)
    get_tree().create_timer(duration).timeout.connect(_close)


func _on_input(e: InputEvent) -> void:
    if e is InputEventMouseButton and e.pressed:
        _close()


func _close() -> void:
    if _done:
        return
    _done = true
    closed.emit()
    queue_free()
