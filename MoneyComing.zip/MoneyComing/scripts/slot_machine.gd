extends Control
# Reel group: 3 number reels + 1 special-symbol reel inside a golden frame.
const UI = preload("res://scripts/ui.gd")
const ReelController = preload("res://scripts/reel_controller.gd")

var reels: Array = []


func _ready() -> void:
    size = Vector2(640, 228)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    for i in 3:
        var r = ReelController.new()
        r.setup(0)
        r.position = Vector2(16.0 + float(i) * 146.0, 16)
        r.size = Vector2(146, 196)
        add_child(r)
        reels.append(r)
    var sp = ReelController.new()
    sp.setup(1)
    sp.position = Vector2(476, 16)
    sp.size = Vector2(148, 196)
    add_child(sp)
    reels.append(sp)
    reels[0].show_symbol(1)
    reels[1].show_symbol(5)
    reels[2].show_symbol(0)
    reels[3].show_symbol(1)


func _draw() -> void:
    draw_rect(Rect2(0, 0, 640, 228), Color("6e4208"))
    draw_rect(Rect2(4, 4, 632, 220), UI.GOLD)
    draw_rect(Rect2(10, 10, 620, 208), Color("2a1204"))
    draw_rect(Rect2(454, 10, 22, 208), UI.GOLD)
    draw_rect(Rect2(624, 10, 6, 208), UI.GOLD)
