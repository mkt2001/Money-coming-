extends Control
# Reel group: 3 to 5 number reels (more reels at higher bets) + 1 special-symbol reel in a golden frame.
const UI = preload("res://scripts/ui.gd")
const ReelController = preload("res://scripts/reel_controller.gd")

const DIGIT_AREA_W: float = 438.0

var reels: Array = []
var digit_reels: Array = []
var special = null
var digit_count: int = 0


func _ready() -> void:
    size = Vector2(640, 228)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    special = ReelController.new()
    special.setup(1)
    special.position = Vector2(476, 16)
    special.size = Vector2(148, 196)
    add_child(special)
    special.show_symbol(1)
    set_digit_count(3)


func set_digit_count(n: int) -> void:
    if n == digit_count and digit_reels.size() == n:
        return
    digit_count = n
    for r in digit_reels:
        r.queue_free()
    digit_reels.clear()
    var w: float = DIGIT_AREA_W / float(n)
    var init: Array = [1, 5, 0, 3, 7]
    for i in n:
        var r = ReelController.new()
        r.setup(0)
        r.position = Vector2(16.0 + float(i) * w, 16)
        r.size = Vector2(w, 196)
        add_child(r)
        r.show_symbol(int(init[i]))
        digit_reels.append(r)
    reels = digit_reels.duplicate()
    reels.append(special)


func _draw() -> void:
    draw_rect(Rect2(0, 0, 640, 228), Color("6e4208"))
    draw_rect(Rect2(4, 4, 632, 220), UI.GOLD)
    draw_rect(Rect2(10, 10, 620, 208), Color("2a1204"))
    draw_rect(Rect2(454, 10, 22, 208), UI.GOLD)
    draw_rect(Rect2(624, 10, 6, 208), UI.GOLD)
