extends Control
# SCATTER panel:  [ reward ]  +  [ count ]   (mode 0 scatter, 1 super scatter, 2 respin)
const UI = preload("res://scripts/ui.gd")
const Lang = preload("res://scripts/lang.gd")

var mode: int = 0
var left_val: int = 0
var right_val: int = 0
var lbl_title: Label
var lbl_cap: Label
var caption: String = ""
var lbl_left: Label
var lbl_plus: Label
var lbl_right: Label


func _ready() -> void:
    size = Vector2(640, 100)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    lbl_title = UI.label("SCATTER", Vector2(360, 0), Vector2(270, 30), 26, UI.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_CENTER, 6)
    lbl_left = UI.label("0", Vector2(30, 24), Vector2(280, 70), 54, UI.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_CENTER, 8)
    lbl_plus = UI.label("+", Vector2(300, 22), Vector2(70, 70), 64, UI.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_CENTER, 8)
    lbl_right = UI.label("0", Vector2(380, 24), Vector2(230, 70), 54, UI.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_CENTER, 8)
    lbl_cap = UI.label("REEL WIN", Vector2(14, 0), Vector2(340, 30), 22, UI.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_CENTER, 6)
    add_child(lbl_cap)
    add_child(lbl_title)
    add_child(lbl_left)
    add_child(lbl_plus)
    add_child(lbl_right)
    _refresh()


func set_state(m: int, l: int, r: int, cap: String = "") -> void:
    caption = cap
    mode = m
    left_val = l
    right_val = r
    if lbl_left != null:
        _refresh()


func _refresh() -> void:
    var title: String = Lang.t("scatter")
    if mode == 1:
        title = Lang.t("super_scatter")
    elif mode == 2:
        title = Lang.t("respin")
    lbl_title.text = title
    var lt: String = UI.fmt(left_val)
    lbl_left.text = lt
    lbl_left.add_theme_font_size_override("font_size", UI.fit_size(lt, 54))
    lbl_cap.text = caption if caption != "" else "REEL WIN"
    lbl_right.text = (str(right_val) + "/3") if mode < 2 else str(right_val)
    queue_redraw()


func _draw() -> void:
    var rc: Color = Color("3fb23a")
    if mode == 1:
        rc = Color("c0302a")
    elif mode == 2:
        rc = Color("2f6fe0")
    var dk: Color = Color("3b1a08")
    draw_rect(Rect2(0, 8, 640, 88), Color("6e4208"))
    draw_rect(Rect2(4, 12, 632, 80), UI.GOLD)
    draw_rect(Rect2(10, 18, 620, 68), dk)
    draw_polygon(PackedVector2Array([Vector2(330, 18), Vector2(630, 18), Vector2(630, 86), Vector2(330, 86)]), PackedColorArray([dk, rc, rc, dk]))
    draw_colored_polygon(PackedVector2Array([Vector2(0, 52), Vector2(34, 20), Vector2(34, 84)]), rc)
    draw_colored_polygon(PackedVector2Array([Vector2(640, 52), Vector2(606, 20), Vector2(606, 84)]), rc)
