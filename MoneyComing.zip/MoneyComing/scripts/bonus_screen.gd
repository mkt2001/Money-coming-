extends Control
# BONUS ROUND: pick one of 6 gift boxes. Prizes are scaled to the locked bet.
const UI = preload("res://scripts/ui.gd")
const Lang = preload("res://scripts/lang.gd")

signal finished(prize)

var prizes: Array = []
var buttons: Array = []
var picked: bool = false


func setup(p: Array, auto_pick: bool) -> void:
    size = Vector2(720, 1280)
    prizes = p.duplicate()
    prizes.shuffle()
    UI.dim(self)
    add_child(UI.label(Lang.t("bonus_round"), Vector2(40, 250), Vector2(640, 100), 64, UI.GOLD, HORIZONTAL_ALIGNMENT_CENTER, 12))
    add_child(UI.label("Pick a gift box!", Vector2(40, 350), Vector2(640, 60), 34, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 6))
    for i in 6:
        var col: int = i % 3
        var row: int = int(i / 3)
        var b: Button = UI.button("?", Vector2(60.0 + float(col) * 210.0, 460.0 + float(row) * 220.0), Vector2(190, 190), Color("5a2a08"), 80, 22, UI.GOLD, 6)
        b.pressed.connect(_pick.bind(i))
        add_child(b)
        buttons.append(b)
    if auto_pick:
        get_tree().create_timer(1.2).timeout.connect(_auto)


func _auto() -> void:
    if not picked:
        _pick(randi() % 6)


func _pick(i: int) -> void:
    if picked:
        return
    picked = true
    SoundManager.play("bonus")
    for j in 6:
        var b: Button = buttons[j]
        var t: String = UI.fmt(int(prizes[j]))
        b.text = t
        b.add_theme_font_size_override("font_size", UI.fit_size(t, 40))
        b.disabled = true
        if j == i:
            UI.set_button_color(b, Color("1f9d2b"), Color.WHITE, 22, 8)
            b.add_theme_stylebox_override("disabled", UI.style(Color("1f9d2b"), Color.WHITE, 22, 8))
    await get_tree().create_timer(1.5).timeout
    finished.emit(int(prizes[i]))
    queue_free()
