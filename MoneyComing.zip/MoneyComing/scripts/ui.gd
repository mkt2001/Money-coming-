extends RefCounted
# Shared UI helpers. Used through: const UI = preload("res://scripts/ui.gd")

const GOLD := Color("f6c744")
const GOLD_LIGHT := Color("ffe9a0")
const GOLD_DARK := Color("a8741a")
const BROWN := Color("3b1a08")
const GREEN := Color("1f9d2b")
const GREEN_DARK := Color("0c5a1c")
const RED := Color("b3201a")
const BLUE := Color("1f5fc4")


static func fmt(n: int) -> String:
    var s: String = str(absi(n))
    var out: String = ""
    var cnt: int = 0
    for i in range(s.length() - 1, -1, -1):
        out = s[i] + out
        cnt += 1
        if cnt % 3 == 0 and i > 0:
            out = "," + out
    if n < 0:
        out = "-" + out
    return out


static func fit_size(text: String, base: int) -> int:
    var l: int = text.length()
    if l <= 6:
        return base
    if l <= 8:
        return int(base * 0.78)
    if l <= 11:
        return int(base * 0.6)
    return int(base * 0.48)


static func style(bg: Color, border: Color, radius: int, border_w: int = 4) -> StyleBoxFlat:
    var sb := StyleBoxFlat.new()
    sb.bg_color = bg
    sb.border_color = border
    sb.set_border_width_all(border_w)
    sb.set_corner_radius_all(radius)
    return sb


static func label(text: String, pos: Vector2, sz: Vector2, font_size: int, color: Color = Color.WHITE, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_CENTER, outline: int = 0, outline_color: Color = Color(0.25, 0.05, 0.0)) -> Label:
    var l := Label.new()
    l.text = text
    l.position = pos
    l.size = sz
    l.horizontal_alignment = align
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    l.add_theme_font_size_override("font_size", font_size)
    l.add_theme_color_override("font_color", color)
    if outline > 0:
        l.add_theme_constant_override("outline_size", outline)
        l.add_theme_color_override("font_outline_color", outline_color)
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return l


static func button(text: String, pos: Vector2, sz: Vector2, bg: Color, font_size: int = 24, radius: int = 14, border: Color = GOLD, border_w: int = 4) -> Button:
    var b := Button.new()
    b.text = text
    b.position = pos
    b.size = sz
    b.focus_mode = Control.FOCUS_NONE
    b.add_theme_font_size_override("font_size", font_size)
    b.add_theme_color_override("font_color", Color.WHITE)
    b.add_theme_color_override("font_hover_color", Color.WHITE)
    b.add_theme_color_override("font_pressed_color", GOLD_LIGHT)
    b.add_theme_color_override("font_disabled_color", Color(1, 1, 1, 0.45))
    b.add_theme_stylebox_override("normal", style(bg, border, radius, border_w))
    b.add_theme_stylebox_override("hover", style(bg.lightened(0.08), border, radius, border_w))
    b.add_theme_stylebox_override("pressed", style(bg.darkened(0.25), border, radius, border_w))
    b.add_theme_stylebox_override("disabled", style(bg.darkened(0.5), border.darkened(0.5), radius, border_w))
    return b


static func set_button_color(b: Button, bg: Color, border: Color = GOLD, radius: int = 14, border_w: int = 4) -> void:
    b.add_theme_stylebox_override("normal", style(bg, border, radius, border_w))
    b.add_theme_stylebox_override("hover", style(bg.lightened(0.08), border, radius, border_w))
    b.add_theme_stylebox_override("pressed", style(bg.darkened(0.25), border, radius, border_w))


static func panel(pos: Vector2, sz: Vector2, bg: Color, border: Color, radius: int, border_w: int = 5) -> Panel:
    var p := Panel.new()
    p.position = pos
    p.size = sz
    p.add_theme_stylebox_override("panel", style(bg, border, radius, border_w))
    return p


static func dim(parent: Control) -> ColorRect:
    var d := ColorRect.new()
    d.color = Color(0, 0, 0, 0.74)
    d.position = Vector2(-1500, -2000)
    d.size = Vector2(3720, 5280)
    parent.add_child(d)
    return d


# Standard popup window. Returns the inner Panel (coordinates 660 x 1140).
static func window(parent: Control, title: String) -> Panel:
    dim(parent)
    var p: Panel = panel(Vector2(30, 70), Vector2(660, 1140), Color("2a0d08"), GOLD, 26)
    parent.add_child(p)
    var tl: Label = label(title, Vector2(0, 14), Vector2(660, 70), 44, GOLD, HORIZONTAL_ALIGNMENT_CENTER, 8)
    tl.name = "Title"
    p.add_child(tl)
    return p
