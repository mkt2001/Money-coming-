extends Node
# Procedural sounds (no audio files needed) - autoload: SoundManager

const MIX_RATE: int = 16000

var sounds: Dictionary = {}
var players: Array = []
var music_player: AudioStreamPlayer
var _next: int = 0


func _ready() -> void:
    for i in 8:
        var p := AudioStreamPlayer.new()
        add_child(p)
        players.append(p)
    music_player = AudioStreamPlayer.new()
    music_player.volume_db = -14.0
    add_child(music_player)
    _build()
    apply_settings()


func _make(freqs: Array, note_len: float, vol: float, wave: int = 0, loop: bool = false) -> AudioStreamWAV:
    var per: int = int(float(MIX_RATE) * note_len)
    var total: int = per * freqs.size()
    var bytes := PackedByteArray()
    bytes.resize(total * 2)
    var idx: int = 0
    for n in freqs.size():
        var f: float = float(freqs[n])
        for i in per:
            var t: float = float(i) / float(MIX_RATE)
            var env: float = 1.0 - float(i) / float(per)
            if i < 80:
                env = env * float(i) / 80.0
            var s: float = 0.0
            if f > 0.0:
                if wave == 1:
                    s = 1.0 if fmod(f * t, 1.0) < 0.5 else -1.0
                else:
                    s = sin(TAU * f * t)
            var v: int = int(clampf(s * env * vol, -1.0, 1.0) * 32767.0)
            bytes.encode_s16(idx * 2, v)
            idx += 1
    var st := AudioStreamWAV.new()
    st.format = AudioStreamWAV.FORMAT_16_BITS
    st.mix_rate = MIX_RATE
    st.stereo = false
    st.data = bytes
    if loop:
        st.loop_mode = AudioStreamWAV.LOOP_FORWARD
        st.loop_begin = 0
        st.loop_end = total
    return st


func _build() -> void:
    sounds["click"] = _make([880.0], 0.05, 0.35)
    sounds["spin"] = _make([220.0, 260.0, 300.0, 340.0, 380.0], 0.06, 0.18, 1)
    sounds["stop"] = _make([150.0], 0.12, 0.6)
    sounds["tick"] = _make([1300.0], 0.025, 0.3)
    sounds["win"] = _make([523.0, 659.0, 784.0, 1047.0], 0.1, 0.45)
    sounds["bigwin"] = _make([523.0, 659.0, 784.0, 1047.0, 784.0, 1047.0, 1319.0], 0.12, 0.5)
    sounds["scatter"] = _make([988.0, 1319.0], 0.12, 0.45)
    sounds["bonus"] = _make([392.0, 523.0, 659.0, 784.0], 0.14, 0.45)
    sounds["jackpot"] = _make([523.0, 659.0, 784.0, 1047.0, 1319.0, 1568.0, 2093.0], 0.13, 0.5)
    sounds["wheel"] = _make([180.0, 220.0, 260.0, 300.0, 340.0, 380.0], 0.1, 0.14, 1)
    sounds["music"] = _make([392.0, 440.0, 523.0, 587.0, 659.0, 587.0, 523.0, 440.0], 0.3, 0.2, 0, true)


func play(name: String) -> void:
    if not bool(SaveManager.data["settings"]["sound"]):
        return
    if not sounds.has(name) or players.is_empty():
        return
    var p: AudioStreamPlayer = players[_next]
    _next = (_next + 1) % players.size()
    p.stream = sounds[name]
    p.play()


func vibrate(ms: int) -> void:
    if bool(SaveManager.data["settings"]["vibration"]):
        Input.vibrate_handheld(ms)


func apply_settings() -> void:
    if music_player == null:
        return
    if bool(SaveManager.data["settings"]["music"]):
        if not music_player.playing and sounds.has("music"):
            music_player.stream = sounds["music"]
            music_player.play()
    else:
        music_player.stop()
