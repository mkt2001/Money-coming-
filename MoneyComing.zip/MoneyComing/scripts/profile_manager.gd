extends Node
# Player profile, XP, missions, achievements, daily rewards (autoload: ProfileManager)

signal level_up(level)
signal achievement_unlocked(title)

const DAILY_REWARDS: Array = [50000, 100000, 150000, 200000, 300000, 500000, 1000000]
const MISSIONS: Array = [
    {"id": "d_spin", "title": "Spin 30 times", "kind": "spin", "target": 30, "reward": 100000, "period": "daily"},
    {"id": "d_win", "title": "Win 10 times", "kind": "win", "target": 10, "reward": 150000, "period": "daily"},
    {"id": "d_feature", "title": "Trigger 1 bonus feature", "kind": "feature", "target": 1, "reward": 200000, "period": "daily"},
    {"id": "w_spin", "title": "Spin 300 times", "kind": "spin", "target": 300, "reward": 1000000, "period": "weekly"},
    {"id": "w_win", "title": "Win 100 times", "kind": "win", "target": 100, "reward": 1500000, "period": "weekly"},
    {"id": "w_feature", "title": "Trigger 10 bonus features", "kind": "feature", "target": 10, "reward": 2000000, "period": "weekly"},
]
const ACHIEVEMENTS: Array = [
    {"id": "first_win", "title": "First Win", "reward": 50000},
    {"id": "big_win", "title": "Big Win (10x bet)", "reward": 200000},
    {"id": "spin_100", "title": "100 Spins", "reward": 300000},
    {"id": "level_5", "title": "Reach Level 5", "reward": 500000},
    {"id": "jackpot", "title": "Hit a Jackpot", "reward": 1000000},
]


func day_index() -> int:
    return int(Time.get_unix_time_from_system() / 86400.0)


func level() -> int:
    return int(SaveManager.data["profile"]["level"])


func xp() -> int:
    return int(SaveManager.data["profile"]["xp"])


func xp_needed(lv: int) -> int:
    return 100 + lv * 60


func add_xp(amount: int) -> void:
    var p: Dictionary = SaveManager.data["profile"]
    p["xp"] = int(p["xp"]) + amount
    while int(p["xp"]) >= xp_needed(int(p["level"])):
        p["xp"] = int(p["xp"]) - xp_needed(int(p["level"]))
        p["level"] = int(p["level"]) + 1
        Wallet.add_coins(int(p["level"]) * 20000, "level")
        level_up.emit(int(p["level"]))


func _period_key(period: String) -> int:
    var d: int = day_index()
    if period == "daily":
        return d
    return int(d / 7)


func mission_state(m: Dictionary) -> Dictionary:
    var ms: Dictionary = SaveManager.data["missions"]
    var id: String = str(m["id"])
    var key: int = _period_key(str(m["period"]))
    if not ms.has(id) or int(ms[id]["key"]) != key:
        ms[id] = {"p": 0, "key": key, "claimed": false}
    ms[id]["p"] = int(ms[id]["p"])
    return ms[id]


func add_progress(kind: String, amount: int) -> void:
    for m in MISSIONS:
        if str(m["kind"]) == kind:
            var st: Dictionary = mission_state(m)
            st["p"] = mini(int(st["p"]) + amount, int(m["target"]))


func claim_mission(id: String) -> int:
    for m in MISSIONS:
        if str(m["id"]) == id:
            var st: Dictionary = mission_state(m)
            if int(st["p"]) >= int(m["target"]) and not bool(st["claimed"]):
                st["claimed"] = true
                Wallet.add_coins(int(m["reward"]), "mission")
                SaveManager.save_game()
                return int(m["reward"])
    return 0


func unlock(id: String) -> void:
    var ach: Dictionary = SaveManager.data["achievements"]
    if ach.has(id):
        return
    for a in ACHIEVEMENTS:
        if str(a["id"]) == id:
            ach[id] = true
            Wallet.add_coins(int(a["reward"]), "achievement")
            achievement_unlocked.emit(str(a["title"]))
            return


func has_achievement(id: String) -> bool:
    return SaveManager.data["achievements"].has(id)


@warning_ignore("integer_division")
func on_round(bet: int, win: int, features: int, jackpot: bool) -> void:
    add_xp(10 + mini(bet / 1000, 40))
    add_progress("spin", 1)
    if win > 0:
        add_progress("win", 1)
        unlock("first_win")
    if features > 0:
        add_progress("feature", features)
    if win >= bet * 10:
        unlock("big_win")
    if int(SaveManager.data["total_spins"]) >= 100:
        unlock("spin_100")
    if jackpot:
        unlock("jackpot")
    if level() >= 5:
        unlock("level_5")


func can_claim_daily() -> bool:
    return int(SaveManager.data["daily"]["last_day"]) != day_index()


func next_streak() -> int:
    var d: Dictionary = SaveManager.data["daily"]
    var last: int = int(d["last_day"])
    var streak: int = int(d["streak"])
    if last == day_index() - 1:
        return (streak % 7) + 1
    if last == day_index():
        return streak
    return 1


func claim_daily() -> int:
    if not can_claim_daily():
        return 0
    var d: Dictionary = SaveManager.data["daily"]
    var s: int = next_streak()
    var reward: int = int(DAILY_REWARDS[s - 1])
    d["last_day"] = day_index()
    d["streak"] = s
    Wallet.add_coins(reward, "daily")
    SaveManager.save_game()
    return reward
