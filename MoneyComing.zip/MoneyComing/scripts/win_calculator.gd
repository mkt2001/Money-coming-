extends RefCounted
# Line payout table (values are in tenths of the bet) and win tiers.
const SlotEngine = preload("res://scripts/slot_engine.gd")

const PAIR: int = 10            # any two equal digits   = 1.0x bet
const SEQUENCE: int = 80        # 3-4-5 or 5-4-3         = 8x bet
const TRIPLE: int = 150         # 5-5-5                  = 15x bet
const TRIPLE_ZERO: int = 100    # 0-0-0                  = 10x bet
const TRIPLE_SEVEN: int = 300   # 7-7-7                  = 30x bet


static func score(a: int, b: int, c: int) -> Array:
    if a == b and b == c:
        if a == 7:
            return [TRIPLE_SEVEN, "triple_seven"]
        if a == 0:
            return [TRIPLE_ZERO, "triple_zero"]
        return [TRIPLE, "triple"]
    if (b == a + 1 and c == b + 1) or (b == a - 1 and c == b - 1):
        return [SEQUENCE, "sequence"]
    if a == b or b == c or a == c:
        return [PAIR, "pair"]
    return [0, "none"]


static func _opts(sym: int) -> Array:
    if sym == SlotEngine.WILD:
        return [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    return [sym]


# Wild substitutes with whichever digit gives the best payout.
static func evaluate(reels: Array) -> Dictionary:
    var best: int = 0
    var kind: String = "none"
    for a in _opts(int(reels[0])):
        for b in _opts(int(reels[1])):
            for c in _opts(int(reels[2])):
                var sc: Array = score(int(a), int(b), int(c))
                if int(sc[0]) > best:
                    best = int(sc[0])
                    kind = str(sc[1])
    return {"mult10": best, "kind": kind}


@warning_ignore("integer_division")
static func line_payout(mult10: int, bet: int) -> int:
    return (bet * mult10) / 10


static func special_multiplier(sp: int) -> int:
    if sp == SlotEngine.SP_X2:
        return 2
    if sp == SlotEngine.SP_X3:
        return 3
    if sp == SlotEngine.SP_X5:
        return 5
    if sp == SlotEngine.SP_X10:
        return 10
    return 1


static func win_tier(total: int, bet: int) -> String:
    if total >= bet * 50:
        return "SUPER WIN"
    if total >= bet * 25:
        return "MEGA WIN"
    if total >= bet * 10:
        return "BIG WIN"
    return ""
