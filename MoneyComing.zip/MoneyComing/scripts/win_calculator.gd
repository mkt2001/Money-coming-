extends RefCounted
# Line payout table (values are in tenths of the bet) and win tiers.
const SlotEngine = preload("res://scripts/slot_engine.gd")

const PAIR: int = 10            # any two equal digits   = 1.0x bet
const SEQUENCE: int = 80        # 3-4-5 or 5-4-3         = 8x bet
const TRIPLE: int = 150         # 5-5-5                  = 15x bet
const TRIPLE_ZERO: int = 100    # 0-0-0                  = 10x bet
const TRIPLE_SEVEN: int = 300   # 7-7-7                  = 30x bet


static func score(a: int, b: int, c: int) -> Array:
    if a == b and b == c:
        if a == 7:
            return [TRIPLE_SEVEN, "triple_seven"]
        if a == 0:
            return [TRIPLE_ZERO, "triple_zero"]
        return [TRIPLE, "triple"]
    if (b == a + 1 and c == b + 1) or (b == a - 1 and c == b - 1):
        return [SEQUENCE, "sequence"]
    if a == b or b == c or a == c:
        return [PAIR, "pair"]
    return [0, "none"]


static func _opts(sym: int) -> Array:
    if sym == SlotEngine.WILD:
        return [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    return [sym]


# Payouts (tenths of bet) when 4 or 5 number reels are shown (higher bets show more reels)
const TABLE4: Dictionary = {"pair": 5, "two_pair": 20, "triple": 50, "quad": 500, "seq3": 50, "seq4": 150}
const TABLE5: Dictionary = {"pair": 3, "two_pair": 10, "triple": 30, "full": 60, "quad": 200, "five": 2000, "seq3": 30, "seq4": 100, "seq5": 400}


static func _score_digits(d: Array) -> Array:
    var n: int = d.size()
    if n == 3:
        var s3: Array = score(int(d[0]), int(d[1]), int(d[2]))
        return [int(s3[0]), str(s3[1]), str(s3[1]).begins_with("triple")]
    var t: Dictionary = TABLE4 if n == 4 else TABLE5
    var cnt: Dictionary = {}
    for v in d:
        cnt[v] = int(cnt.get(v, 0)) + 1
    var maxg: int = 0
    var pairs: int = 0
    for k in cnt.keys():
        var c: int = int(cnt[k])
        maxg = maxi(maxg, c)
        if c == 2:
            pairs += 1
    var run: int = 1
    var best_run: int = 1
    var dir: int = 0
    for i in range(1, n):
        var diff: int = int(d[i]) - int(d[i - 1])
        if diff == 1 or diff == -1:
            if diff == dir:
                run += 1
            else:
                run = 2
            dir = diff
        else:
            run = 1
            dir = 0
        best_run = maxi(best_run, run)
    var cands: Array = []
    if maxg >= 5:
        cands.append("five")
    elif maxg == 4:
        cands.append("quad")
    elif maxg == 3:
        cands.append("full" if pairs >= 1 else "triple")
    if pairs >= 2:
        cands.append("two_pair")
    elif pairs == 1:
        cands.append("pair")
    if best_run >= 5:
        cands.append("seq5")
    elif best_run == 4:
        cands.append("seq4")
    elif best_run == 3:
        cands.append("seq3")
    var best: int = 0
    var kind: String = "none"
    for nm in cands:
        var val: int = int(t.get(nm, 0))
        if val > best:
            best = val
            kind = str(nm)
    return [best, kind, maxg >= 4]


# Wild substitutes with whichever digit gives the best payout.
static func evaluate(reels: Array) -> Dictionary:
    var combos: Array = [[]]
    for sym in reels:
        var nxt: Array = []
        for c in combos:
            for o in _opts(int(sym)):
                var cc: Array = c.duplicate()
                cc.append(o)
                nxt.append(cc)
        combos = nxt
    var best: int = 0
    var kind: String = "none"
    var bonus: bool = false
    for c in combos:
        var sc: Array = _score_digits(c)
        if int(sc[0]) > best:
            best = int(sc[0])
            kind = str(sc[1])
            bonus = bool(sc[2])
    return {"mult10": best, "kind": kind, "bonus": bonus}


@warning_ignore("integer_division")
static func line_payout(mult10: int, bet: int) -> int:
    return (bet * mult10) / 10


static func special_multiplier(sp: int) -> int:
    if sp == SlotEngine.SP_X2:
        return 2
    if sp == SlotEngine.SP_X3:
        return 3
    if sp == SlotEngine.SP_X5:
        return 5
    if sp == SlotEngine.SP_X10:
        return 10
    return 1


static func win_tier(total: int, bet: int) -> String:
    if total >= bet * 50:
        return "SUPER WIN"
    if total >= bet * 25:
        return "MEGA WIN"
    if total >= bet * 10:
        return "BIG WIN"
    return ""
