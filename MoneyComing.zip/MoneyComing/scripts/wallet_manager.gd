extends Node
# Virtual coin wallet (autoload: Wallet). Fictional coins only - no real money.

signal balance_changed(new_balance)

const MAX_LOG: int = 100

var session_spins: int = 0
var session_bet: int = 0
var session_win: int = 0
var session_best: int = 0


func get_balance() -> int:
    return int(SaveManager.data["balance"])


func can_afford(amount: int) -> bool:
    return amount >= 0 and get_balance() >= amount


func _log(kind: String, amount: int) -> void:
    var arr: Array = SaveManager.data["wallet_history"]
    arr.insert(0, {"t": Time.get_datetime_string_from_system(false, true), "type": kind, "amount": amount, "balance": get_balance()})
    while arr.size() > MAX_LOG:
        arr.pop_back()


func place_bet(amount: int) -> bool:
    if not can_afford(amount):
        return false
    SaveManager.data["balance"] = get_balance() - amount
    SaveManager.data["total_bets"] = int(SaveManager.data["total_bets"]) + amount
    session_bet += amount
    _log("bet", -amount)
    balance_changed.emit(get_balance())
    return true


func add_win(amount: int, kind: String) -> void:
    if amount <= 0:
        return
    SaveManager.data["balance"] = get_balance() + amount
    SaveManager.data["total_wins"] = int(SaveManager.data["total_wins"]) + amount
    session_win += amount
    _log(kind, amount)
    balance_changed.emit(get_balance())


func add_coins(amount: int, reason: String) -> void:
    if amount <= 0:
        return
    SaveManager.data["balance"] = get_balance() + amount
    _log(reason, amount)
    balance_changed.emit(get_balance())


func register_round(win: int) -> void:
    SaveManager.data["total_spins"] = int(SaveManager.data["total_spins"]) + 1
    session_spins += 1
    if win > 0:
        SaveManager.data["win_count"] = int(SaveManager.data["win_count"]) + 1
        if win > int(SaveManager.data["highest_win"]):
            SaveManager.data["highest_win"] = win
        if win > session_best:
            session_best = win
