extends Node
# Bet selection + bet lock (autoload: BetManager)

signal bet_changed(bet)
signal lock_changed(locked)

const BET_STEPS: Array = [100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000]

var current_bet: int = 100
var locked_bet: int = 0
var locked: bool = false


func _ready() -> void:
    reload()


func reload() -> void:
    current_bet = _nearest(int(SaveManager.data["bet"]))
    locked = false
    RewardScaling.set_current_bet(current_bet)


func _nearest(v: int) -> int:
    if BET_STEPS.has(v):
        return v
    return 100


func _apply(new_bet: int) -> void:
    current_bet = new_bet
    SaveManager.data["bet"] = new_bet
    RewardScaling.set_current_bet(new_bet)   # instantly refreshes all reward displays
    bet_changed.emit(new_bet)


func increase() -> void:
    if locked:
        return
    var i: int = BET_STEPS.find(current_bet)
    if i < BET_STEPS.size() - 1:
        _apply(int(BET_STEPS[i + 1]))


func decrease() -> void:
    if locked:
        return
    var i: int = BET_STEPS.find(current_bet)
    if i > 0:
        _apply(int(BET_STEPS[i - 1]))


func lock() -> void:
    locked = true
    locked_bet = current_bet
    lock_changed.emit(true)


func unlock() -> void:
    locked = false
    lock_changed.emit(false)


func round_bet() -> int:
    return locked_bet if locked else current_bet
