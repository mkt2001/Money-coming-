extends Control
# Rules + payout table (values scaled with the current BET)
const UI = preload("res://scripts/ui.gd")
const Lang = preload("res://scripts/lang.gd")
const WinCalculator = preload("res://scripts/win_calculator.gd")

signal closed


func _ready() -> void:
    size = Vector2(720, 1280)
    var win: Panel = UI.window(self, Lang.t("info"))
    var bet: int = BetManager.current_bet
    var t: String = ""
    t += "CURRENT BET: %s\n\n" % UI.fmt(bet)
    t += "LINE PAYS (3 reels; BET 1,000+ = 4 reels, BET 10,000+ = 5 reels; W = Wild)\n"
    t += "Any pair: %s\n" % UI.fmt(WinCalculator.line_payout(WinCalculator.PAIR, bet))
    t += "Sequence (3-4-5 / 5-4-3): %s\n" % UI.fmt(WinCalculator.line_payout(WinCalculator.SEQUENCE, bet))
    t += "Triple: %s\n" % UI.fmt(WinCalculator.line_payout(WinCalculator.TRIPLE, bet))
    t += "Triple 0: %s\n" % UI.fmt(WinCalculator.line_payout(WinCalculator.TRIPLE_ZERO, bet))
    t += "Triple 7: %s\n" % UI.fmt(WinCalculator.line_payout(WinCalculator.TRIPLE_SEVEN, bet))
    t += "Any triple also opens the BONUS ROUND (pick a gift box).\n\n"
    t += "SPECIAL REEL\n"
    t += "2X / 3X / 5X / 10X multiply the line win of that spin.\n"
    t += "SCATTER: every scatter spins the Fortune Wheel - the amount it stops on is your win. Collect 3 = %s + 5 FREE SPINS\n" % UI.fmt(RewardScaling.scatter_reward)
    t += "SUPER SCATTER: collect 3 = a JACKPOT (base %s)\n" % UI.fmt(RewardScaling.super_scatter_reward)
    t += "WHEEL: Wheel Respin - spin the Fortune Wheel\n"
    t += "ALL RESPIN: bonus %s + 3 free respins of all reels\n\n" % UI.fmt(RewardScaling.respin_reward)
    t += "FORTUNE WHEEL\n"
    var parts: Array = []
    for v in RewardScaling.wheel_rewards:
        parts.append(UI.fmt(int(v)))
    t += ", ".join(parts) + "\n\n"
    t += "JACKPOTS\n"
    for k in RewardScaling.jackpot_rewards.keys():
        t += "%s: %s\n" % [str(k), UI.fmt(int(RewardScaling.jackpot_rewards[k]))]
    t += "\nAll values scale with your BET. Virtual coins only."
    var sc := ScrollContainer.new()
    sc.position = Vector2(20, 96)
    sc.size = Vector2(620, 930)
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    win.add_child(sc)
    var l := Label.new()
    l.text = t
    l.custom_minimum_size = Vector2(600, 0)
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    l.add_theme_font_size_override("font_size", 26)
    l.add_theme_color_override("font_color", Color.WHITE)
    sc.add_child(l)
    var back: Button = UI.button(Lang.t("back"), Vector2(230, 1050), Vector2(200, 64), UI.RED, 28)
    back.pressed.connect(_close)
    win.add_child(back)


func _close() -> void:
    SoundManager.play("click")
    closed.emit()
    queue_free()
