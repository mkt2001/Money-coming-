extends Node
# Central reward scaling (autoload: RewardScaling)
# Scaled Reward = Base Reward x (Current BET / Base BET)  -- integer-safe.
# Every displayed reward AND every actual payout uses these functions.

signal rewards_changed

const BASE_BET: int = 100
# Order = clockwise from the top pointer (index 2 is the red special segment)
const BASE_WHEEL: Array = [50, 200, 2000, 500, 100, 300, 150, 1000]
const BASE_SCATTER: int = 150
const BASE_SUPER_SCATTER: int = 1000
const BASE_RESPIN: int = 110
const BASE_JACKPOTS: Dictionary = {"MINI": 500, "MINOR": 2000, "MAJOR": 10000, "GRAND": 50000}
const BASE_BONUS: Array = [100, 150, 200, 300, 500, 1000]

var current_bet: int = 100
var wheel_rewards: Array = []
var scatter_reward: int = 0
var super_scatter_reward: int = 0
var respin_reward: int = 0
var jackpot_rewards: Dictionary = {}
var bonus_rewards: Array = []


func _ready() -> void:
    refresh_all_reward_displays()


func set_current_bet(bet: int) -> void:
    current_bet = clampi(bet, 100, 100000)
    refresh_all_reward_displays()


@warning_ignore("integer_division")
func calculate_scaled_reward(base: int, bet: int = -1) -> int:
    var b: int = current_bet if bet < 0 else bet
    return (base * b) / BASE_BET


func wheel_rewards_for(bet: int) -> Array:
    var out: Array = []
    for v in BASE_WHEEL:
        out.append(calculate_scaled_reward(int(v), bet))
    return out


func jackpots_for(bet: int) -> Dictionary:
    var out: Dictionary = {}
    for k in BASE_JACKPOTS.keys():
        out[k] = calculate_scaled_reward(int(BASE_JACKPOTS[k]), bet)
    return out


func bonus_rewards_for(bet: int) -> Array:
    var out: Array = []
    for v in BASE_BONUS:
        out.append(calculate_scaled_reward(int(v), bet))
    return out


func update_wheel_rewards() -> void:
    wheel_rewards = wheel_rewards_for(current_bet)


func update_scatter_rewards() -> void:
    scatter_reward = calculate_scaled_reward(BASE_SCATTER, current_bet)
    super_scatter_reward = calculate_scaled_reward(BASE_SUPER_SCATTER, current_bet)


func update_respin_rewards() -> void:
    respin_reward = calculate_scaled_reward(BASE_RESPIN, current_bet)


func update_jackpot_rewards() -> void:
    jackpot_rewards = jackpots_for(current_bet)


func update_bonus_rewards() -> void:
    bonus_rewards = bonus_rewards_for(current_bet)


func refresh_all_reward_displays() -> void:
    update_wheel_rewards()
    update_scatter_rewards()
    update_respin_rewards()
    update_jackpot_rewards()
    update_bonus_rewards()
    rewards_changed.emit()
