extends RefCounted
# Tiny translation helper (English / Hindi). Use: const Lang = preload("res://scripts/lang.gd")

const TEXT := {
    "spin": ["SPIN", "स्पिन"],
    "auto": ["AUTO", "ऑटो"],
    "fast": ["FAST", "तेज़"],
    "stop": ["STOP", "रुकें"],
    "win": ["WIN", "जीत"],
    "bet": ["BET", "बेट"],
    "balance": ["BALANCE", "बैलेंस"],
    "settings": ["SETTINGS", "सेटिंग्स"],
    "sound": ["SOUND", "साउंड"],
    "info": ["INFO", "जानकारी"],
    "more": ["MENU", "मेनू"],
    "scatter": ["SCATTER", "स्कैटर"],
    "super_scatter": ["SUPER SCATTER", "सुपर स्कैटर"],
    "respin": ["RESPIN", "रीस्पिन"],
    "no_balance": ["Not enough coins", "कॉइन कम हैं"],
    "play": ["PLAY", "खेलें"],
    "profile": ["PROFILE", "प्रोफ़ाइल"],
    "history": ["HISTORY", "हिस्ट्री"],
    "daily": ["DAILY REWARDS", "डेली रिवॉर्ड"],
    "back": ["BACK", "वापस"],
    "claim": ["CLAIM", "लें"],
    "main_menu": ["MAIN MENU", "मुख्य मेनू"],
    "wheel_respin": ["WHEEL RESPIN", "व्हील रीस्पिन"],
    "all_respin": ["ALL RESPIN", "ऑल रीस्पिन"],
    "wheel_win": ["WHEEL WIN", "व्हील जीत"],
    "free": ["FREE", "फ्री"],
    "free_total": ["FREE SPINS TOTAL", "फ्री स्पिन कुल"],
    "bonus_round": ["BONUS ROUND", "बोनस राउंड"],
    "scatter_bonus": ["SCATTER BONUS", "स्कैटर बोनस"],
    "scatter_win": ["SCATTER WIN", "स्कैटर जीत"],
    "tap": ["TAP TO CONTINUE", "जारी रखने के लिए टैप करें"],
    "sound_on": ["SOUND", "साउंड"],
    "music": ["Music", "म्यूज़िक"],
    "vibration": ["Vibration", "वाइब्रेशन"],
    "anim_q": ["Animation quality", "एनिमेशन क्वालिटी"],
    "gfx_q": ["Graphics quality", "ग्राफिक्स क्वालिटी"],
    "spin_speed": ["Spin speed", "स्पिन स्पीड"],
    "auto_n": ["Auto spin count", "ऑटो स्पिन संख्या"],
    "language": ["Language", "भाषा"],
    "reset": ["Reset game", "गेम रीसेट"],
    "about": ["About", "के बारे में"],
    "privacy": ["Privacy Policy", "प्राइवेसी पॉलिसी"],
    "on": ["ON", "चालू"],
    "off": ["OFF", "बंद"],
    "low": ["Low", "कम"],
    "medium": ["Medium", "मध्यम"],
    "high": ["High", "ज्यादा"],
    "normal": ["Normal", "सामान्य"],
    "close": ["CLOSE", "बंद करें"],
    "vip": ["VIP", "वीआईपी"],
}


static func is_hindi() -> bool:
    return str(SaveManager.data["settings"]["language"]) == "hi"


static func t(key: String) -> String:
    var idx: int = 1 if is_hindi() else 0
    if TEXT.has(key):
        return str(TEXT[key][idx])
    return key
