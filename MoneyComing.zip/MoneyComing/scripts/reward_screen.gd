extends Control
# Reward popup with count-up + coin burst. Closes on tap or automatically.
const UI = preload("res://scripts/ui.gd")
const Lang = preload("res://scripts/lang.gd")

signal closed

var _lbl_amt: Label
var _done: bool = false


func setup(title: String, amount: int, duration: float = 2.4) -> void:
    size = Vector2(720, 1280)
    var d: ColorRect = UI.dim(self)
    d.gui_input.connect(_on_input)
    add_child(UI.label(title, Vector2(40, 430), Vector2(640, 120), 64, UI.GOLD, HORIZONTAL_ALIGNMENT_CENTER, 14))
    var at: String = UI.fmt(amount)
    _lbl_amt = UI.label("0", Vector2(40, 560), Vector2(640, 150), UI.fit_size(at, 100), Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 14)
    add_child(_lbl_amt)
    add_child(UI.label(Lang.t("tap"), Vector2(40, 740), Vector2(640, 40), 24, Color(1, 1, 1, 0.65)))
    var q: int = int(SaveManager.data["settings"]["anim_quality"])
    var p := CPUParticles2D.new()
    p.position = Vector2(360, 640)
    p.amount = 20 + q * 15
    p.lifetime = 1.8
    p.one_shot = true
    p.explosiveness = 0.95
    p.direction = Vector2(0, -1)
    p.spread = 75.0
    p.gravity = Vector2(0, 1100)
    p.initial_velocity_min = 450.0
    p.initial_velocity_max = 950.0
    p.scale_amount_min = 8.0
    p.scale_amount_max = 15.0
    p.color = UI.GOLD
    add_child(p)
    p.emitting = true
    var tw: Tween = create_tween()
    tw.tween_method(_set_amt, 0.0, float(amount), 0.9 if duration < 1.5 else 1.4)
    get_tree().create_timer(duration).timeout.connect(_close)


func _set_amt(v: float) -> void:
    var t: String = UI.fmt(int(v))
    _lbl_amt.text = t


func _on_input(e: InputEvent) -> void:
    if e is InputEventMouseButton and e.pressed:
        _close()


func _close() -> void:
    if _done:
        return
    _done = true
    closed.emit()
    queue_free()
