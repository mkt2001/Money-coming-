extends Control
# Main menu
const UI = preload("res://scripts/ui.gd")
const Lang = preload("res://scripts/lang.gd")

var content: Control
var daily_btn: Button
var bal_lbl: Label


func _ready() -> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)
    var base := ColorRect.new()
    base.color = Color("2b0b07")
    base.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(base)
    var pat := Control.new()
    pat.set_anchors_preset(Control.PRESET_FULL_RECT)
    pat.mouse_filter = Control.MOUSE_FILTER_IGNORE
    pat.draw.connect(_draw_pattern.bind(pat))
    add_child(pat)
    content = Control.new()
    content.size = Vector2(720, 1280)
    add_child(content)
    get_viewport().size_changed.connect(_relayout)
    _relayout()
    var deco := Control.new()
    deco.size = Vector2(720, 700)
    deco.mouse_filter = Control.MOUSE_FILTER_IGNORE
    deco.draw.connect(_draw_deco.bind(deco))
    content.add_child(deco)
    content.add_child(UI.label("Money", Vector2(40, 380), Vector2(640, 110), 104, Color("e5301f"), HORIZONTAL_ALIGNMENT_CENTER, 16, UI.GOLD_LIGHT))
    content.add_child(UI.label("Coming", Vector2(40, 490), Vector2(640, 110), 104, Color("e5301f"), HORIZONTAL_ALIGNMENT_CENTER, 16, UI.GOLD_LIGHT))
    content.add_child(UI.label("CLASSIC FORTUNE WHEEL SLOT", Vector2(40, 610), Vector2(640, 44), 26, UI.GOLD, HORIZONTAL_ALIGNMENT_CENTER, 6))
    var play: Button = UI.button(Lang.t("play"), Vector2(210, 720), Vector2(300, 110), Color("22b53a"), 54, 55, UI.GOLD, 8)
    play.pressed.connect(_on_play)
    content.add_child(play)
    daily_btn = UI.button(Lang.t("daily"), Vector2(150, 860), Vector2(420, 70), Color("a8741a"), 28)
    daily_btn.pressed.connect(_on_daily)
    content.add_child(daily_btn)
    var prof: Button = UI.button(Lang.t("profile"), Vector2(150, 950), Vector2(200, 64), Color("3b1a08"), 24)
    prof.pressed.connect(_open.bind("res://scenes/profile_screen.tscn"))
    content.add_child(prof)
    var setb: Button = UI.button(Lang.t("settings"), Vector2(370, 950), Vector2(200, 64), Color("3b1a08"), 24)
    setb.pressed.connect(_open.bind("res://scenes/settings_screen.tscn"))
    content.add_child(setb)
    bal_lbl = UI.label("", Vector2(40, 1090), Vector2(640, 60), 36, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 6)
    content.add_child(bal_lbl)
    _refresh()
    SoundManager.apply_settings()


func _refresh() -> void:
    bal_lbl.text = Lang.t("balance") + "  " + UI.fmt(Wallet.get_balance())
    if ProfileManager.can_claim_daily():
        daily_btn.text = Lang.t("daily") + "  !"
    else:
        daily_btn.text = Lang.t("daily")


func _relayout() -> void:
    var vs: Vector2 = get_viewport_rect().size
    content.position = Vector2((vs.x - 720.0) / 2.0, (vs.y - 1280.0) / 2.0)


func _draw_pattern(pat: Control) -> void:
    var step: float = 36.0
    var cols: int = int(pat.size.x / step) + 1
    var rows: int = int(pat.size.y / step) + 1
    for y in rows:
        for x in cols:
            if (x + y) % 2 == 0:
                pat.draw_rect(Rect2(float(x) * step + 4.0, float(y) * step + 4.0, step - 8.0, step - 8.0), Color(0.55, 0.12, 0.05, 0.22))


func _draw_deco(d: Control) -> void:
    var c: Vector2 = Vector2(360, 200)
    d.draw_circle(c, 170, Color("6e4208"))
    d.draw_circle(c, 164, UI.GOLD)
    d.draw_circle(c, 150, Color("1f9d2b"))
    for i in 8:
        var a0: float = float(i) * TAU / 8.0 - PI / 2.0 - PI / 8.0
        if i % 2 == 1:
            var pts := PackedVector2Array([c])
            for s in 11:
                pts.append(c + Vector2.from_angle(a0 + (TAU / 8.0) * float(s) / 10.0) * 150.0)
            d.draw_colored_polygon(pts, Color("f5d742") if i != 3 else Color("c8201a"))
    d.draw_circle(c, 52, Color("7a4a08"))
    d.draw_circle(c, 46, UI.GOLD)
    d.draw_string(d.get_theme_default_font(), Vector2(c.x - 40.0, c.y + 24.0), "$", HORIZONTAL_ALIGNMENT_CENTER, 80.0, 70, Color("7a4a08"))


func _on_play() -> void:
    SoundManager.play("click")
    get_tree().change_scene_to_file("res://scenes/game_screen.tscn")


func _on_daily() -> void:
    _open("res://scenes/daily_screen.tscn")


func _open(path: String) -> void:
    SoundManager.play("click")
    var scr = load(path).instantiate()
    content.add_child(scr)
    scr.closed.connect(_refresh)


func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        get_tree().quit()
