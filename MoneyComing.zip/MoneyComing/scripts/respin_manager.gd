extends RefCounted
# ALL RESPIN state (free respins on the locked bet)

const RESPINS: int = 3

var active: bool = false
var left: int = 0
var total_win: int = 0


func start() -> void:
    active = true
    left = RESPINS
    total_win = 0


func next() -> bool:
    if left <= 0:
        return false
    left -= 1
    return true


func add_win(amount: int) -> void:
    total_win += amount


func finish() -> void:
    active = false
    left = 0
