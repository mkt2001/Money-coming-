extends Control
# Daily login calendar + missions
const UI = preload("res://scripts/ui.gd")
const Lang = preload("res://scripts/lang.gd")

signal closed

var win: Panel
var vb: VBoxContainer
var claim_btn: Button
var msg: Label


func _ready() -> void:
    size = Vector2(720, 1280)
    win = UI.window(self, Lang.t("daily"))
    _build()


func _build() -> void:
    for c in win.get_children():
        if c.name != "Title":
            c.queue_free()
    var can: bool = ProfileManager.can_claim_daily()
    var d: Dictionary = SaveManager.data["daily"]
    var today: int = ProfileManager.next_streak() if can else int(d["streak"])
    for i in 7:
        var x: float = 14.0 + float(i) * 90.0
        var done: bool = (i + 1) < today or ((i + 1) == today and not can)
        var is_today: bool = (i + 1) == today and can
        var bg: Color = Color("1f6b2a") if done else (Color("a8741a") if is_today else Color("3b1a08"))
        var pnl: Panel = UI.panel(Vector2(x, 100), Vector2(82, 120), bg, UI.GOLD if is_today else UI.GOLD_DARK, 12, 3)
        win.add_child(pnl)
        pnl.add_child(UI.label("Day %d" % (i + 1), Vector2(0, 6), Vector2(82, 28), 18, UI.GOLD_LIGHT))
        var rt: String = UI.fmt(int(ProfileManager.DAILY_REWARDS[i]))
        pnl.add_child(UI.label(rt, Vector2(0, 40), Vector2(82, 40), UI.fit_size(rt, 24), Color.WHITE))
        if done:
            pnl.add_child(UI.label("OK", Vector2(0, 84), Vector2(82, 30), 22, UI.GOLD))
    claim_btn = UI.button(Lang.t("claim"), Vector2(210, 236), Vector2(240, 64), Color("22b53a") if can else Color("444444"), 30)
    claim_btn.disabled = not can
    claim_btn.pressed.connect(_claim_daily)
    win.add_child(claim_btn)
    msg = UI.label("", Vector2(0, 306), Vector2(660, 36), 24, UI.GOLD_LIGHT)
    win.add_child(msg)
    win.add_child(UI.label("MISSIONS", Vector2(0, 340), Vector2(660, 44), 32, UI.GOLD, HORIZONTAL_ALIGNMENT_CENTER, 6))
    var sc := ScrollContainer.new()
    sc.position = Vector2(20, 390)
    sc.size = Vector2(620, 640)
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    win.add_child(sc)
    vb = VBoxContainer.new()
    vb.custom_minimum_size = Vector2(600, 0)
    sc.add_child(vb)
    for m in ProfileManager.MISSIONS:
        var st: Dictionary = ProfileManager.mission_state(m)
        var row := Control.new()
        row.custom_minimum_size = Vector2(600, 104)
        row.mouse_filter = Control.MOUSE_FILTER_PASS
        var bgp: Panel = UI.panel(Vector2(0, 4), Vector2(600, 96), Color("1a0805"), UI.GOLD_DARK, 10, 2)
        bgp.mouse_filter = Control.MOUSE_FILTER_PASS
        row.add_child(bgp)
        var tag: String = "[D] " if str(m["period"]) == "daily" else "[W] "
        row.add_child(UI.label(tag + str(m["title"]), Vector2(12, 8), Vector2(400, 40), 22, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT))
        row.add_child(UI.label("%d / %d    +%s" % [int(st["p"]), int(m["target"]), UI.fmt(int(m["reward"]))], Vector2(12, 52), Vector2(400, 40), 22, UI.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_LEFT))
        var ready: bool = int(st["p"]) >= int(m["target"]) and not bool(st["claimed"])
        var txt: String = "DONE" if bool(st["claimed"]) else Lang.t("claim")
        var cb: Button = UI.button(txt, Vector2(440, 26), Vector2(144, 52), Color("22b53a") if ready else Color("444444"), 22)
        cb.disabled = not ready
        cb.pressed.connect(_claim_mission.bind(str(m["id"])))
        row.add_child(cb)
        vb.add_child(row)
    var back: Button = UI.button(Lang.t("back"), Vector2(230, 1050), Vector2(200, 64), UI.RED, 28)
    back.pressed.connect(_close)
    win.add_child(back)


func _claim_daily() -> void:
    var r: int = ProfileManager.claim_daily()
    if r > 0:
        SoundManager.play("jackpot")
    _build()
    if r > 0:
        msg.text = "+" + UI.fmt(r) + " coins!"


func _claim_mission(id: String) -> void:
    var r: int = ProfileManager.claim_mission(id)
    if r > 0:
        SoundManager.play("bigwin")
    _build()
    if r > 0:
        msg.text = "+" + UI.fmt(r) + " coins!"


func _close() -> void:
    SoundManager.play("click")
    SaveManager.save_game()
    closed.emit()
    queue_free()
