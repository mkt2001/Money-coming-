# Money Coming - Classic Fortune Wheel Slot (Godot 4.3, Android)

Original-art classic slot: Fortune Wheel, 3 number reels + special reel, Scatter / Super Scatter,
Wheel Respin, All Respin, Free Spins, Multipliers, Jackpots, Bonus Round, Wild, daily rewards, missions,
profile, history, settings (English/Hindi). Virtual coins only - no real money. Works fully offline.

## Build APK with GitHub (no PC needed)
1. Create a GitHub repo. Upload `MoneyComing.zip` (zip as-is is fine; the workflow extracts it).
2. In the repo: Add file > Create new file > name `.github/workflows/android-build.yml`, paste the
   contents of `android-build.yml`, commit. (GitHub does not unpack zips, so this file must be in the repo itself.)
3. Open the Actions tab - the build runs automatically (or press "Run workflow").
4. Download `MoneyComing.apk` from the repo's **Releases** page (also saved as a workflow artifact).

## Key design
- `reward_scaling_manager.gd`: Scaled Reward = Base x (BET / 100). Wheel, scatter, respin, jackpot, bonus
  values all refresh instantly on BET +/- via the `rewards_changed` signal. Payouts use the same functions.
- Bet lock: bet is locked at spin start and unlocked after the round.
- Outcomes: weighted pseudo-random (RandomNumberGenerator), see `slot_engine.gd`. Tables are configurable
  constants. No outcome manipulation. Return-to-player is approximate and not guaranteed.
- Saves: versioned + checksummed local file with backup.
